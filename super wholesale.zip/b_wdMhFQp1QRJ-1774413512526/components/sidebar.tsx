"use client"

import { useState, memo } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  LayoutDashboard,
  Package,
  Receipt,
  ShoppingCart,
  Users,
  BookOpen,
  Calendar,
  Wallet,
  Building2,
  FileSpreadsheet,
  TrendingUp,
  FileText,
  BarChart3,
  AlertCircle,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Scale,
  IndianRupee,
  Landmark,
  CreditCard,
  Keyboard,
  Search,
  Calculator,
  Briefcase,
  Shield,
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { PageType } from "@/app/page"

interface SidebarProps {
  currentPage: PageType
  onPageChange: (page: PageType) => void
  onLogout: () => void
  user: string
  collapsed: boolean
  onToggleCollapse: () => void
  companyName: string
  onOpenSearch?: () => void
  onOpenCalculator?: () => void
}

type MenuItem = {
  key: PageType
  label: string
  icon: React.ComponentType<{ className?: string }>
  shortcut?: string
}

type MenuSection = {
  title: string
  items: MenuItem[]
}

const menuSections: MenuSection[] = [
  {
    title: "Main",
    items: [
      { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, shortcut: "F1" },
    ],
  },
  {
    title: "Transactions",
    items: [
      { key: "sales", label: "Sales / Billing", icon: Receipt, shortcut: "F2" },
      { key: "purchase", label: "Purchase Entry", icon: ShoppingCart, shortcut: "F3" },
      { key: "voucher", label: "Voucher Entry", icon: CreditCard, shortcut: "F4" },
      { key: "expense", label: "Expense Manager", icon: IndianRupee, shortcut: "F5" },
    ],
  },
  {
    title: "Masters",
    items: [
      { key: "inventory", label: "Item / Stock", icon: Package, shortcut: "F6" },
      { key: "party", label: "Party Master", icon: Users, shortcut: "F7" },
    ],
  },
  {
    title: "Books",
    items: [
      { key: "ledger", label: "Party Ledger", icon: BookOpen, shortcut: "F8" },
      { key: "daybook", label: "Day Book", icon: Calendar, shortcut: "Alt+D" },
      { key: "cashbook", label: "Cash Book", icon: Wallet, shortcut: "Alt+C" },
      { key: "bankbook", label: "Bank Book", icon: Landmark, shortcut: "Alt+B" },
    ],
  },
  {
    title: "Accounts",
    items: [
      { key: "trialbalance", label: "Trial Balance", icon: Scale, shortcut: "Alt+T" },
      { key: "balancesheet", label: "Balance Sheet", icon: FileSpreadsheet, shortcut: "F9" },
      { key: "profitloss", label: "Profit & Loss", icon: TrendingUp, shortcut: "F10" },
    ],
  },
  {
    title: "Reports",
    items: [
      { key: "gstreports", label: "GST Reports", icon: FileText, shortcut: "F11" },
      { key: "stockreport", label: "Stock Report", icon: BarChart3, shortcut: "Alt+S" },
      { key: "outstanding", label: "Outstanding", icon: AlertCircle, shortcut: "Alt+O" },
    ],
  },
  {
    title: "HR & Compliance",
    items: [
      { key: "payroll", label: "Payroll", icon: Briefcase, shortcut: "Alt+P" },
      { key: "compliance", label: "Compliance", icon: Shield, shortcut: "Alt+X" },
    ],
  },
  {
    title: "System",
    items: [
      { key: "settings", label: "Settings", icon: Settings, shortcut: "F12" },
    ],
  },
]

// Memoized menu item for performance
const MenuItem = memo(function MenuItem({
  item,
  isActive,
  collapsed,
  onClick,
}: {
  item: MenuItem
  isActive: boolean
  collapsed: boolean
  onClick: () => void
}) {
  const button = (
    <Button
      variant="ghost"
      onClick={onClick}
      className={cn(
        "w-full text-slate-300 hover:text-white hover:bg-slate-800 h-9 transition-colors",
        collapsed ? "justify-center px-2" : "justify-start gap-3 px-3",
        isActive && "bg-slate-800 text-amber-500 border-l-2 border-amber-500 rounded-l-none"
      )}
    >
      <item.icon className="h-4 w-4 shrink-0" />
      {!collapsed && (
        <>
          <span className="flex-1 text-left text-sm truncate">
            {item.label}
          </span>
          {item.shortcut && (
            <span className="text-[10px] text-slate-600 font-mono bg-slate-800/80 px-1.5 py-0.5 rounded">
              {item.shortcut}
            </span>
          )}
        </>
      )}
    </Button>
  )

  if (collapsed) {
    return (
      <Tooltip delayDuration={100}>
        <TooltipTrigger asChild>{button}</TooltipTrigger>
        <TooltipContent side="right" className="flex items-center gap-2">
          {item.label}
          {item.shortcut && (
            <kbd className="text-[10px] font-mono bg-slate-700 px-1 py-0.5 rounded">
              {item.shortcut}
            </kbd>
          )}
        </TooltipContent>
      </Tooltip>
    )
  }

  return button
})

export function Sidebar({
  currentPage,
  onPageChange,
  onLogout,
  user,
  collapsed,
  onToggleCollapse,
  companyName,
  onOpenSearch,
  onOpenCalculator,
}: SidebarProps) {
  const [expandedSections, setExpandedSections] = useState<string[]>(
    menuSections.map((s) => s.title)
  )

  const toggleSection = (title: string) => {
    setExpandedSections((prev) =>
      prev.includes(title)
        ? prev.filter((t) => t !== title)
        : [...prev, title]
    )
  }

  return (
    <TooltipProvider>
      <aside
        className={cn(
          "bg-slate-900 text-white flex flex-col transition-all duration-200",
          collapsed ? "w-16" : "w-64"
        )}
      >
        {/* Company Header */}
        <div className="p-3 border-b border-slate-800 flex items-center justify-between">
          {!collapsed && (
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-amber-500 flex items-center justify-center shrink-0">
                  <Building2 className="h-4 w-4 text-slate-900" />
                </div>
                <div className="min-w-0">
                  <h1 className="text-sm font-bold text-amber-500 truncate">
                    {companyName}
                  </h1>
                  <p className="text-[10px] text-slate-500">VyaparERP</p>
                </div>
              </div>
            </div>
          )}
          {collapsed && (
            <div className="h-8 w-8 rounded-lg bg-amber-500 flex items-center justify-center mx-auto">
              <Building2 className="h-4 w-4 text-slate-900" />
            </div>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className={cn(
              "h-7 w-7 text-slate-400 hover:text-white hover:bg-slate-800 shrink-0",
              collapsed && "hidden"
            )}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>

        {/* Quick Actions */}
        {!collapsed && (
          <div className="px-3 py-2 border-b border-slate-800 flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={onOpenSearch}
              className="flex-1 h-8 text-xs text-slate-400 hover:text-white hover:bg-slate-800 justify-start gap-2"
            >
              <Search className="h-3.5 w-3.5" />
              Search
              <kbd className="ml-auto text-[9px] font-mono bg-slate-800 px-1 py-0.5 rounded">Ctrl+F</kbd>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onOpenCalculator}
              className="h-8 w-8 text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <Calculator className="h-3.5 w-3.5" />
            </Button>
          </div>
        )}

        {/* User Info */}
        {!collapsed && (
          <div className="px-3 py-2 border-b border-slate-800 bg-slate-800/30">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0">
                <span className="text-xs font-bold text-amber-500">
                  {user.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs font-medium text-white truncate">{user}</p>
                <p className="text-[10px] text-slate-500">Administrator</p>
              </div>
            </div>
          </div>
        )}

        {/* Navigation */}
        <ScrollArea className="flex-1">
          <nav className="p-2">
            {menuSections.map((section) => (
              <div key={section.title} className="mb-1">
                {!collapsed && (
                  <button
                    onClick={() => toggleSection(section.title)}
                    className="w-full flex items-center justify-between px-2 py-1.5 text-[10px] font-semibold text-slate-500 uppercase tracking-wider hover:text-slate-300 rounded transition-colors"
                  >
                    {section.title}
                    <ChevronDown
                      className={cn(
                        "h-3 w-3 transition-transform",
                        expandedSections.includes(section.title) && "rotate-180"
                      )}
                    />
                  </button>
                )}
                {(collapsed || expandedSections.includes(section.title)) && (
                  <ul className="space-y-0.5">
                    {section.items.map((item) => (
                      <li key={item.key}>
                        <MenuItem
                          item={item}
                          isActive={currentPage === item.key}
                          collapsed={collapsed}
                          onClick={() => onPageChange(item.key)}
                        />
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </nav>
        </ScrollArea>

        {/* Footer */}
        <div className="p-2 border-t border-slate-800 space-y-1">
          {!collapsed && (
            <div className="px-2 py-1 text-[10px] text-slate-600 flex items-center gap-1">
              <Keyboard className="h-3 w-3" />
              Press <kbd className="px-1 bg-slate-800 rounded">?</kbd> for shortcuts
            </div>
          )}
          
          {collapsed ? (
            <Tooltip delayDuration={100}>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onToggleCollapse}
                  className="w-full h-8 text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right">Expand sidebar</TooltipContent>
            </Tooltip>
          ) : null}

          <Tooltip delayDuration={100}>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                onClick={onLogout}
                className={cn(
                  "w-full text-slate-400 hover:text-red-400 hover:bg-red-900/20 h-9",
                  collapsed ? "justify-center px-2" : "justify-start gap-3"
                )}
              >
                <LogOut className="h-4 w-4" />
                {!collapsed && (
                  <>
                    <span className="flex-1 text-left">Logout</span>
                    <span className="text-[10px] font-mono text-slate-600">Alt+Q</span>
                  </>
                )}
              </Button>
            </TooltipTrigger>
            {collapsed && <TooltipContent side="right">Logout (Alt+Q)</TooltipContent>}
          </Tooltip>
        </div>

        {/* Version */}
        {!collapsed && (
          <div className="px-3 py-1.5 text-[9px] text-slate-600 text-center border-t border-slate-800 bg-slate-900/50">
            VyaparERP v2.0 | Made in India
          </div>
        )}
      </aside>
    </TooltipProvider>
  )
}
