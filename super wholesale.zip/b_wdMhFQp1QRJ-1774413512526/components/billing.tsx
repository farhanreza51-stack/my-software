"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Plus,
  Receipt,
  Printer,
  Save,
  Trash2,
  FileText,
  Eye,
} from "lucide-react"
import type { BillItem, InventoryItem, Party, Invoice, CompanySettings } from "@/app/page"

interface BillingProps {
  inventory: InventoryItem[]
  parties: Party[]
  invoices: Invoice[]
  onCreateInvoice: (invoice: Omit<Invoice, "id" | "invoiceNo" | "type">) => Invoice
  companySettings: CompanySettings
  onDeleteInvoice: (id: string) => void
}

export function Billing({
  inventory,
  parties,
  invoices,
  onCreateInvoice,
  companySettings,
  onDeleteInvoice,
}: BillingProps) {
  const [selectedParty, setSelectedParty] = useState<string>("")
  const [billItems, setBillItems] = useState<BillItem[]>([])
  const [currentItem, setCurrentItem] = useState({
    itemId: "",
    name: "",
    hsn: "",
    qty: "",
    price: "",
    discount: "0",
    gstRate: "18",
  })
  const [paymentMode, setPaymentMode] = useState<"cash" | "bank" | "credit">("credit")
  const [notes, setNotes] = useState("")
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null)
  const printRef = useRef<HTMLDivElement>(null)

  const party = parties.find((p) => p.id === selectedParty)

  const addToBill = () => {
    if (!currentItem.itemId || !currentItem.qty || !currentItem.price) return

    const qty = Number(currentItem.qty)
    const price = Number(currentItem.price)
    const discount = Number(currentItem.discount) || 0
    const gstRate = Number(currentItem.gstRate)

    const baseAmount = qty * price
    const discountAmount = (baseAmount * discount) / 100
    const taxableAmount = baseAmount - discountAmount
    const gstAmount = (taxableAmount * gstRate) / 100
    const amount = taxableAmount + gstAmount

    setBillItems([
      ...billItems,
      {
        itemId: currentItem.itemId,
        name: currentItem.name,
        hsn: currentItem.hsn,
        qty,
        price,
        discount,
        gstRate,
        amount,
      },
    ])
    setCurrentItem({
      itemId: "",
      name: "",
      hsn: "",
      qty: "",
      price: "",
      discount: "0",
      gstRate: "18",
    })
  }

  const removeItem = (index: number) => {
    setBillItems(billItems.filter((_, i) => i !== index))
  }

  const handleSelectItem = (itemId: string) => {
    const item = inventory.find((i) => i.id === itemId)
    if (item) {
      setCurrentItem({
        itemId: item.id,
        name: item.name,
        hsn: item.hsn,
        qty: "1",
        price: String(item.price),
        discount: "0",
        gstRate: String(item.gstRate),
      })
    }
  }

  const subtotal = billItems.reduce((a, b) => a + b.qty * b.price, 0)
  const totalDiscount = billItems.reduce(
    (a, b) => a + (b.qty * b.price * b.discount) / 100,
    0
  )
  const totalGst = billItems.reduce(
    (a, b) =>
      a + ((b.qty * b.price - (b.qty * b.price * b.discount) / 100) * b.gstRate) / 100,
    0
  )
  const grandTotal = subtotal - totalDiscount + totalGst

  const saveBill = () => {
    if (!selectedParty || billItems.length === 0) return

    const invoice = onCreateInvoice({
      partyId: selectedParty,
      partyName: party?.name || "",
      items: billItems,
      subtotal,
      discount: totalDiscount,
      gstAmount: totalGst,
      total: Math.round(grandTotal),
      paidAmount: paymentMode === "credit" ? 0 : Math.round(grandTotal),
      paymentMode,
      date: new Date().toISOString().split("T")[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0],
      status: paymentMode === "credit" ? "unpaid" : "paid",
      notes,
    })

    setViewInvoice(invoice)
    setSelectedParty("")
    setBillItems([])
    setNotes("")
  }

  const handlePrint = () => {
    window.print()
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Sales / Billing</h2>
        <p className="text-muted-foreground">
          Create GST compliant sales invoices
        </p>
      </div>

      <Tabs defaultValue="create">
        <TabsList>
          <TabsTrigger value="create">Create Invoice</TabsTrigger>
          <TabsTrigger value="history">Invoice History ({invoices.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-5">
            {/* Left Panel - Item Selection */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  Add Items
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Select Customer *</label>
                  <Select value={selectedParty} onValueChange={setSelectedParty}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select customer..." />
                    </SelectTrigger>
                    <SelectContent>
                      {parties.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name} {p.gstin && `(${p.gstin})`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="border-t pt-4 space-y-3">
                  <label className="text-sm font-medium">Select Item from Inventory</label>
                  <Select onValueChange={handleSelectItem} value={currentItem.itemId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select item..." />
                    </SelectTrigger>
                    <SelectContent>
                      {inventory
                        .filter((i) => i.qty > 0)
                        .map((item) => (
                          <SelectItem key={item.id} value={item.id}>
                            {item.name} (Stock: {item.qty} {item.unit})
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>

                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="number"
                      placeholder="Qty"
                      value={currentItem.qty}
                      onChange={(e) =>
                        setCurrentItem({ ...currentItem, qty: e.target.value })
                      }
                    />
                    <Input
                      type="number"
                      placeholder="Rate (₹)"
                      value={currentItem.price}
                      onChange={(e) =>
                        setCurrentItem({ ...currentItem, price: e.target.value })
                      }
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="number"
                      placeholder="Discount %"
                      value={currentItem.discount}
                      onChange={(e) =>
                        setCurrentItem({ ...currentItem, discount: e.target.value })
                      }
                    />
                    <Select
                      value={currentItem.gstRate}
                      onValueChange={(v) =>
                        setCurrentItem({ ...currentItem, gstRate: v })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="GST %" />
                      </SelectTrigger>
                      <SelectContent>
                        {[0, 5, 12, 18, 28].map((rate) => (
                          <SelectItem key={rate} value={String(rate)}>
                            {rate}% GST
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button onClick={addToBill} className="w-full" variant="secondary">
                    <Plus className="h-4 w-4 mr-2" />
                    Add to Bill
                  </Button>
                </div>

                <div className="border-t pt-4 space-y-3">
                  <label className="text-sm font-medium">Payment Mode</label>
                  <Select
                    value={paymentMode}
                    onValueChange={(v) => setPaymentMode(v as "cash" | "bank" | "credit")}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="bank">Bank Transfer</SelectItem>
                      <SelectItem value="credit">Credit (On Account)</SelectItem>
                    </SelectContent>
                  </Select>

                  <Textarea
                    placeholder="Notes (optional)"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={2}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Right Panel - Invoice Preview */}
            <Card className="lg:col-span-3 print:shadow-none" ref={printRef}>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  Invoice Preview
                </CardTitle>
                {party && (
                  <div className="text-right text-sm">
                    <p className="font-medium">{party.name}</p>
                    {party.gstin && (
                      <p className="text-muted-foreground">GSTIN: {party.gstin}</p>
                    )}
                  </div>
                )}
              </CardHeader>
              <CardContent>
                {billItems.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    No items added. Select items from the left panel.
                  </p>
                ) : (
                  <>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Item</TableHead>
                          <TableHead>HSN</TableHead>
                          <TableHead className="text-right">Qty</TableHead>
                          <TableHead className="text-right">Rate</TableHead>
                          <TableHead className="text-right">Disc%</TableHead>
                          <TableHead className="text-right">GST%</TableHead>
                          <TableHead className="text-right">Amount</TableHead>
                          <TableHead className="w-10 print:hidden"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {billItems.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell className="text-muted-foreground">
                              {item.hsn || "-"}
                            </TableCell>
                            <TableCell className="text-right">{item.qty}</TableCell>
                            <TableCell className="text-right">₹{item.price}</TableCell>
                            <TableCell className="text-right">{item.discount}%</TableCell>
                            <TableCell className="text-right">{item.gstRate}%</TableCell>
                            <TableCell className="text-right font-medium">
                              ₹{item.amount.toLocaleString("en-IN", {
                                maximumFractionDigits: 2,
                              })}
                            </TableCell>
                            <TableCell className="print:hidden">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeItem(index)}
                                className="h-8 w-8 text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    <div className="mt-4 pt-4 border-t border-border space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Subtotal</span>
                        <span>₹{subtotal.toLocaleString("en-IN")}</span>
                      </div>
                      {totalDiscount > 0 && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Discount</span>
                          <span className="text-red-500">
                            -₹{totalDiscount.toLocaleString("en-IN")}
                          </span>
                        </div>
                      )}
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">GST</span>
                        <span>
                          ₹{totalGst.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="flex justify-between text-lg font-bold pt-2 border-t">
                        <span>Grand Total</span>
                        <span className="text-emerald-600">
                          ₹{Math.round(grandTotal).toLocaleString("en-IN")}
                        </span>
                      </div>
                    </div>

                    <div className="mt-6 flex gap-3 print:hidden">
                      <Button
                        onClick={saveBill}
                        disabled={!selectedParty}
                        className="flex-1 bg-amber-500 hover:bg-amber-600 text-slate-900"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Save Invoice
                      </Button>
                      <Button onClick={handlePrint} variant="outline">
                        <Printer className="h-4 w-4 mr-2" />
                        Print
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Sales Invoice History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {invoices.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No invoices created yet.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead className="text-right">Paid</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invoices
                      .slice()
                      .reverse()
                      .map((invoice) => (
                        <TableRow key={invoice.id}>
                          <TableCell className="font-mono font-medium">
                            {invoice.invoiceNo}
                          </TableCell>
                          <TableCell>{invoice.date}</TableCell>
                          <TableCell>{invoice.partyName}</TableCell>
                          <TableCell className="text-right font-medium">
                            ₹{invoice.total.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{invoice.paidAmount.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                invoice.status === "paid"
                                  ? "default"
                                  : invoice.status === "partial"
                                  ? "secondary"
                                  : "destructive"
                              }
                            >
                              {invoice.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setViewInvoice(invoice)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => onDeleteInvoice(invoice.id)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Invoice View Dialog */}
      <Dialog open={!!viewInvoice} onOpenChange={() => setViewInvoice(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Invoice {viewInvoice?.invoiceNo}</DialogTitle>
          </DialogHeader>
          {viewInvoice && (
            <div className="space-y-4">
              <div className="flex justify-between border-b pb-4">
                <div>
                  <h3 className="font-bold text-lg">{companySettings.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {companySettings.address}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    GSTIN: {companySettings.gstin}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{viewInvoice.invoiceNo}</p>
                  <p className="text-sm text-muted-foreground">
                    Date: {viewInvoice.date}
                  </p>
                </div>
              </div>

              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Bill To:</p>
                <p className="font-medium">{viewInvoice.partyName}</p>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Rate</TableHead>
                    <TableHead className="text-right">GST</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {viewInvoice.items.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{item.name}</TableCell>
                      <TableCell className="text-right">{item.qty}</TableCell>
                      <TableCell className="text-right">₹{item.price}</TableCell>
                      <TableCell className="text-right">{item.gstRate}%</TableCell>
                      <TableCell className="text-right">
                        ₹{item.amount.toLocaleString("en-IN")}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>₹{viewInvoice.subtotal.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">GST</span>
                  <span>₹{viewInvoice.gstAmount.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between text-lg font-bold border-t pt-2">
                  <span>Total</span>
                  <span>₹{viewInvoice.total.toLocaleString("en-IN")}</span>
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={handlePrint}>
                  <Printer className="h-4 w-4 mr-2" />
                  Print
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
