"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus, Package, Search, Pencil, Trash2, AlertTriangle } from "lucide-react"
import type { InventoryItem } from "@/app/page"

interface InventoryProps {
  inventory: InventoryItem[]
  onAddItem: (item: Omit<InventoryItem, "id">) => void
  onUpdateItem: (id: string, item: Partial<InventoryItem>) => void
  onDeleteItem: (id: string) => void
}

const categories = [
  "Electronics",
  "Clothing",
  "Food & Beverages",
  "Home & Kitchen",
  "Sports",
  "Toys",
  "Automotive",
  "Health & Beauty",
  "Office Supplies",
  "Other",
]

const units = ["Pcs", "Kg", "Ltr", "Mtr", "Box", "Dozen", "Pair", "Set", "Pack"]

const gstRates = [0, 5, 12, 18, 28]

const emptyForm = {
  name: "",
  hsn: "",
  category: "",
  qty: "",
  price: "",
  purchasePrice: "",
  gstRate: "18",
  unit: "Pcs",
  minStock: "",
  location: "",
}

export function Inventory({
  inventory,
  onAddItem,
  onUpdateItem,
  onDeleteItem,
}: InventoryProps) {
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [search, setSearch] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.qty || !form.price || !form.purchasePrice) return

    const itemData = {
      name: form.name,
      hsn: form.hsn,
      category: form.category,
      qty: Number(form.qty),
      price: Number(form.price),
      purchasePrice: Number(form.purchasePrice),
      gstRate: Number(form.gstRate),
      unit: form.unit,
      minStock: Number(form.minStock) || 0,
      location: form.location,
    }

    if (editingId) {
      onUpdateItem(editingId, itemData)
    } else {
      onAddItem(itemData)
    }

    setForm(emptyForm)
    setEditingId(null)
    setDialogOpen(false)
  }

  const handleEdit = (item: InventoryItem) => {
    setForm({
      name: item.name,
      hsn: item.hsn,
      category: item.category,
      qty: String(item.qty),
      price: String(item.price),
      purchasePrice: String(item.purchasePrice),
      gstRate: String(item.gstRate),
      unit: item.unit,
      minStock: String(item.minStock),
      location: item.location,
    })
    setEditingId(item.id)
    setDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      onDeleteItem(id)
    }
  }

  const filteredInventory = inventory.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.hsn.toLowerCase().includes(search.toLowerCase())
    const matchesCategory =
      categoryFilter === "all" || item.category === categoryFilter
    return matchesSearch && matchesCategory
  })

  const totalValue = inventory.reduce(
    (sum, item) => sum + item.qty * item.purchasePrice,
    0
  )
  const totalSaleValue = inventory.reduce(
    (sum, item) => sum + item.qty * item.price,
    0
  )
  const lowStockCount = inventory.filter((i) => i.qty <= i.minStock).length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Inventory Master</h2>
          <p className="text-muted-foreground">
            Manage your product inventory and stock levels
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button
              className="bg-amber-500 hover:bg-amber-600 text-slate-900"
              onClick={() => {
                setForm(emptyForm)
                setEditingId(null)
              }}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add New Item
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingId ? "Edit Item" : "Add New Item"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Item Name *</label>
                  <Input
                    placeholder="Enter item name"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">HSN Code</label>
                  <Input
                    placeholder="HSN/SAC code"
                    value={form.hsn}
                    onChange={(e) => setForm({ ...form, hsn: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Category</label>
                  <Select
                    value={form.category}
                    onValueChange={(v) => setForm({ ...form, category: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Unit</label>
                  <Select
                    value={form.unit}
                    onValueChange={(v) => setForm({ ...form, unit: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Opening Qty *</label>
                  <Input
                    type="number"
                    placeholder="Quantity"
                    value={form.qty}
                    onChange={(e) => setForm({ ...form, qty: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Min Stock Level</label>
                  <Input
                    type="number"
                    placeholder="Min stock for alert"
                    value={form.minStock}
                    onChange={(e) => setForm({ ...form, minStock: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Purchase Price *</label>
                  <Input
                    type="number"
                    placeholder="Cost price (₹)"
                    value={form.purchasePrice}
                    onChange={(e) =>
                      setForm({ ...form, purchasePrice: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Sale Price *</label>
                  <Input
                    type="number"
                    placeholder="Selling price (₹)"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">GST Rate (%)</label>
                  <Select
                    value={form.gstRate}
                    onValueChange={(v) => setForm({ ...form, gstRate: v })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {gstRates.map((rate) => (
                        <SelectItem key={rate} value={String(rate)}>
                          {rate}%
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Location</label>
                  <Input
                    placeholder="Warehouse/Shelf location"
                    value={form.location}
                    onChange={(e) =>
                      setForm({ ...form, location: e.target.value })
                    }
                  />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-600 text-slate-900"
                >
                  {editingId ? "Update Item" : "Add Item"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{inventory.length}</div>
            <p className="text-sm text-muted-foreground">Total Items</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">
              ₹{totalValue.toLocaleString("en-IN")}
            </div>
            <p className="text-sm text-muted-foreground">Stock Value (Cost)</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">
              ₹{totalSaleValue.toLocaleString("en-IN")}
            </div>
            <p className="text-sm text-muted-foreground">Stock Value (Sale)</p>
          </CardContent>
        </Card>
        <Card className={lowStockCount > 0 ? "border-amber-500" : ""}>
          <CardContent className="pt-6">
            <div
              className={`text-2xl font-bold ${
                lowStockCount > 0 ? "text-amber-600" : ""
              }`}
            >
              {lowStockCount}
            </div>
            <p className="text-sm text-muted-foreground">Low Stock Items</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search items by name or HSN..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Inventory Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Stock List ({filteredInventory.length} items)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredInventory.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              {inventory.length === 0
                ? 'No items in inventory. Click "Add New Item" to get started.'
                : "No items match your search criteria."}
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    <TableHead>Item Name</TableHead>
                    <TableHead>HSN</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Purchase</TableHead>
                    <TableHead className="text-right">Sale</TableHead>
                    <TableHead className="text-right">GST</TableHead>
                    <TableHead className="text-right">Value</TableHead>
                    <TableHead className="text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInventory.map((item, index) => (
                    <TableRow
                      key={item.id}
                      className={
                        item.qty <= item.minStock ? "bg-amber-500/5" : ""
                      }
                    >
                      <TableCell className="font-medium text-muted-foreground">
                        {index + 1}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{item.name}</span>
                          {item.qty <= item.minStock && (
                            <AlertTriangle className="h-4 w-4 text-amber-500" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {item.hsn || "-"}
                      </TableCell>
                      <TableCell>
                        {item.category && (
                          <Badge variant="secondary">{item.category}</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        {item.qty} {item.unit}
                      </TableCell>
                      <TableCell className="text-right">
                        ₹{item.purchasePrice}
                      </TableCell>
                      <TableCell className="text-right">₹{item.price}</TableCell>
                      <TableCell className="text-right">{item.gstRate}%</TableCell>
                      <TableCell className="text-right font-semibold">
                        ₹{(item.qty * item.purchasePrice).toLocaleString("en-IN")}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(item)}
                            className="h-8 w-8"
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(item.id)}
                            className="h-8 w-8 text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
