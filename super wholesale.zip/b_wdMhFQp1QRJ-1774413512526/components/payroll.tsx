"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  Printer,
  Download,
  IndianRupee,
  Calendar,
  FileText,
  Calculator,
  UserPlus,
  Briefcase,
} from "lucide-react"
import type { Employee, SalarySlip } from "@/app/page"

interface PayrollProps {
  employees: Employee[]
  salarySlips: SalarySlip[]
  onAddEmployee: (employee: Omit<Employee, "id">) => void
  onUpdateEmployee: (id: string, employee: Partial<Employee>) => void
  onDeleteEmployee: (id: string) => void
  onProcessSalary: (slip: Omit<SalarySlip, "id">) => void
  onUpdateSalarySlip: (id: string, slip: Partial<SalarySlip>) => void
}

const departments = [
  "Administration",
  "Sales",
  "Accounts",
  "Warehouse",
  "Logistics",
  "IT",
  "HR",
  "Production",
]

const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
]

export function Payroll({
  employees,
  salarySlips,
  onAddEmployee,
  onUpdateEmployee,
  onDeleteEmployee,
  onProcessSalary,
  onUpdateSalarySlip,
}: PayrollProps) {
  const [search, setSearch] = useState("")
  const [showAddEmployee, setShowAddEmployee] = useState(false)
  const [showProcessSalary, setShowProcessSalary] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  const [selectedMonth, setSelectedMonth] = useState(String(new Date().getMonth()))
  const [selectedYear, setSelectedYear] = useState(String(new Date().getFullYear()))
  const [viewSlip, setViewSlip] = useState<SalarySlip | null>(null)

  const [form, setForm] = useState({
    employeeCode: "",
    name: "",
    department: "",
    designation: "",
    dateOfJoining: new Date().toISOString().split("T")[0],
    basicSalary: "",
    hra: "",
    da: "",
    ta: "",
    otherAllowances: "0",
    pf: "",
    esi: "",
    tds: "0",
    bankAccount: "",
    bankName: "",
    ifsc: "",
    pan: "",
    aadhaar: "",
    phone: "",
    email: "",
    address: "",
  })

  const [salaryForm, setSalaryForm] = useState({
    employeeId: "",
    workingDays: "26",
    presentDays: "26",
    otherDeductions: "0",
  })

  const filteredEmployees = useMemo(() => 
    employees.filter(
      (e) =>
        e.name.toLowerCase().includes(search.toLowerCase()) ||
        e.employeeCode.toLowerCase().includes(search.toLowerCase()) ||
        e.department.toLowerCase().includes(search.toLowerCase())
    ), [employees, search]
  )

  const monthSlips = useMemo(() => 
    salarySlips.filter(
      (s) => s.month === months[Number(selectedMonth)] && s.year === Number(selectedYear)
    ), [salarySlips, selectedMonth, selectedYear]
  )

  const resetForm = () => {
    setForm({
      employeeCode: "",
      name: "",
      department: "",
      designation: "",
      dateOfJoining: new Date().toISOString().split("T")[0],
      basicSalary: "",
      hra: "",
      da: "",
      ta: "",
      otherAllowances: "0",
      pf: "",
      esi: "",
      tds: "0",
      bankAccount: "",
      bankName: "",
      ifsc: "",
      pan: "",
      aadhaar: "",
      phone: "",
      email: "",
      address: "",
    })
    setEditingEmployee(null)
  }

  const handleSubmitEmployee = () => {
    const employeeData = {
      employeeCode: form.employeeCode,
      name: form.name,
      department: form.department,
      designation: form.designation,
      dateOfJoining: form.dateOfJoining,
      basicSalary: parseFloat(form.basicSalary) || 0,
      hra: parseFloat(form.hra) || 0,
      da: parseFloat(form.da) || 0,
      ta: parseFloat(form.ta) || 0,
      otherAllowances: parseFloat(form.otherAllowances) || 0,
      pf: parseFloat(form.pf) || 0,
      esi: parseFloat(form.esi) || 0,
      tds: parseFloat(form.tds) || 0,
      bankAccount: form.bankAccount,
      bankName: form.bankName,
      ifsc: form.ifsc,
      pan: form.pan,
      aadhaar: form.aadhaar,
      phone: form.phone,
      email: form.email,
      address: form.address,
      status: "active" as const,
    }

    if (editingEmployee) {
      onUpdateEmployee(editingEmployee.id, employeeData)
    } else {
      onAddEmployee(employeeData)
    }

    resetForm()
    setShowAddEmployee(false)
  }

  const handleProcessSalary = () => {
    const employee = employees.find((e) => e.id === salaryForm.employeeId)
    if (!employee) return

    const workingDays = parseFloat(salaryForm.workingDays) || 26
    const presentDays = parseFloat(salaryForm.presentDays) || 26
    const ratio = presentDays / workingDays

    const basicSalary = Math.round(employee.basicSalary * ratio)
    const hra = Math.round(employee.hra * ratio)
    const da = Math.round(employee.da * ratio)
    const ta = Math.round(employee.ta * ratio)
    const otherAllowances = Math.round(employee.otherAllowances * ratio)
    const grossSalary = basicSalary + hra + da + ta + otherAllowances

    const pf = Math.round(employee.pf * ratio)
    const esi = Math.round(employee.esi * ratio)
    const tds = Math.round(employee.tds * ratio)
    const otherDeductions = parseFloat(salaryForm.otherDeductions) || 0
    const totalDeductions = pf + esi + tds + otherDeductions

    const netSalary = grossSalary - totalDeductions

    onProcessSalary({
      employeeId: employee.id,
      employeeName: employee.name,
      month: months[Number(selectedMonth)],
      year: Number(selectedYear),
      workingDays,
      presentDays,
      basicSalary,
      hra,
      da,
      ta,
      otherAllowances,
      grossSalary,
      pf,
      esi,
      tds,
      otherDeductions,
      totalDeductions,
      netSalary,
      status: "processed",
    })

    setSalaryForm({
      employeeId: "",
      workingDays: "26",
      presentDays: "26",
      otherDeductions: "0",
    })
    setShowProcessSalary(false)
  }

  const editEmployee = (employee: Employee) => {
    setEditingEmployee(employee)
    setForm({
      employeeCode: employee.employeeCode,
      name: employee.name,
      department: employee.department,
      designation: employee.designation,
      dateOfJoining: employee.dateOfJoining,
      basicSalary: String(employee.basicSalary),
      hra: String(employee.hra),
      da: String(employee.da),
      ta: String(employee.ta),
      otherAllowances: String(employee.otherAllowances),
      pf: String(employee.pf),
      esi: String(employee.esi),
      tds: String(employee.tds),
      bankAccount: employee.bankAccount,
      bankName: employee.bankName,
      ifsc: employee.ifsc,
      pan: employee.pan,
      aadhaar: employee.aadhaar,
      phone: employee.phone,
      email: employee.email,
      address: employee.address,
    })
    setShowAddEmployee(true)
  }

  const totalGrossSalary = monthSlips.reduce((a, b) => a + b.grossSalary, 0)
  const totalDeductions = monthSlips.reduce((a, b) => a + b.totalDeductions, 0)
  const totalNetSalary = monthSlips.reduce((a, b) => a + b.netSalary, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Briefcase className="h-6 w-6" />
            Payroll Management
          </h2>
          <p className="text-muted-foreground">
            Manage employees and process salary
          </p>
        </div>
      </div>

      <Tabs defaultValue="employees">
        <TabsList>
          <TabsTrigger value="employees" className="gap-2">
            <Users className="h-4 w-4" />
            Employees ({employees.length})
          </TabsTrigger>
          <TabsTrigger value="salary" className="gap-2">
            <IndianRupee className="h-4 w-4" />
            Salary Processing
          </TabsTrigger>
          <TabsTrigger value="reports" className="gap-2">
            <FileText className="h-4 w-4" />
            Payroll Reports
          </TabsTrigger>
        </TabsList>

        {/* Employees Tab */}
        <TabsContent value="employees" className="space-y-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search employees..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Dialog open={showAddEmployee} onOpenChange={setShowAddEmployee}>
                  <DialogTrigger asChild>
                    <Button className="bg-amber-500 hover:bg-amber-600 text-slate-900 gap-2">
                      <UserPlus className="h-4 w-4" />
                      Add Employee
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {editingEmployee ? "Edit Employee" : "Add New Employee"}
                      </DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4">
                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label>Employee Code *</Label>
                          <Input
                            value={form.employeeCode}
                            onChange={(e) => setForm({ ...form, employeeCode: e.target.value })}
                            placeholder="EMP001"
                          />
                        </div>
                        <div className="space-y-2 col-span-2">
                          <Label>Full Name *</Label>
                          <Input
                            value={form.name}
                            onChange={(e) => setForm({ ...form, name: e.target.value })}
                            placeholder="Employee name"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label>Department *</Label>
                          <Select
                            value={form.department}
                            onValueChange={(v) => setForm({ ...form, department: v })}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select" />
                            </SelectTrigger>
                            <SelectContent>
                              {departments.map((d) => (
                                <SelectItem key={d} value={d}>{d}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Designation *</Label>
                          <Input
                            value={form.designation}
                            onChange={(e) => setForm({ ...form, designation: e.target.value })}
                            placeholder="Job title"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Date of Joining</Label>
                          <Input
                            type="date"
                            value={form.dateOfJoining}
                            onChange={(e) => setForm({ ...form, dateOfJoining: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-3">Salary Components (Monthly)</h4>
                        <div className="grid grid-cols-4 gap-3">
                          <div className="space-y-2">
                            <Label>Basic Salary</Label>
                            <Input
                              type="number"
                              value={form.basicSalary}
                              onChange={(e) => setForm({ ...form, basicSalary: e.target.value })}
                              placeholder="0"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>HRA</Label>
                            <Input
                              type="number"
                              value={form.hra}
                              onChange={(e) => setForm({ ...form, hra: e.target.value })}
                              placeholder="0"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>DA</Label>
                            <Input
                              type="number"
                              value={form.da}
                              onChange={(e) => setForm({ ...form, da: e.target.value })}
                              placeholder="0"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>TA</Label>
                            <Input
                              type="number"
                              value={form.ta}
                              onChange={(e) => setForm({ ...form, ta: e.target.value })}
                              placeholder="0"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-3">Deductions (Monthly)</h4>
                        <div className="grid grid-cols-3 gap-3">
                          <div className="space-y-2">
                            <Label>PF (Employee)</Label>
                            <Input
                              type="number"
                              value={form.pf}
                              onChange={(e) => setForm({ ...form, pf: e.target.value })}
                              placeholder="0"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>ESI</Label>
                            <Input
                              type="number"
                              value={form.esi}
                              onChange={(e) => setForm({ ...form, esi: e.target.value })}
                              placeholder="0"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>TDS</Label>
                            <Input
                              type="number"
                              value={form.tds}
                              onChange={(e) => setForm({ ...form, tds: e.target.value })}
                              placeholder="0"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-3">Bank Details</h4>
                        <div className="grid grid-cols-3 gap-3">
                          <div className="space-y-2">
                            <Label>Bank Name</Label>
                            <Input
                              value={form.bankName}
                              onChange={(e) => setForm({ ...form, bankName: e.target.value })}
                              placeholder="Bank name"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Account Number</Label>
                            <Input
                              value={form.bankAccount}
                              onChange={(e) => setForm({ ...form, bankAccount: e.target.value })}
                              placeholder="Account number"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>IFSC Code</Label>
                            <Input
                              value={form.ifsc}
                              onChange={(e) => setForm({ ...form, ifsc: e.target.value })}
                              placeholder="IFSC"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="border-t pt-4">
                        <h4 className="font-semibold mb-3">Personal Details</h4>
                        <div className="grid grid-cols-3 gap-3">
                          <div className="space-y-2">
                            <Label>PAN</Label>
                            <Input
                              value={form.pan}
                              onChange={(e) => setForm({ ...form, pan: e.target.value })}
                              placeholder="ABCDE1234F"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Aadhaar</Label>
                            <Input
                              value={form.aadhaar}
                              onChange={(e) => setForm({ ...form, aadhaar: e.target.value })}
                              placeholder="1234 5678 9012"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Phone</Label>
                            <Input
                              value={form.phone}
                              onChange={(e) => setForm({ ...form, phone: e.target.value })}
                              placeholder="9876543210"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end gap-3 pt-4">
                        <Button variant="outline" onClick={() => { resetForm(); setShowAddEmployee(false); }}>
                          Cancel
                        </Button>
                        <Button onClick={handleSubmitEmployee} className="bg-amber-500 hover:bg-amber-600 text-slate-900">
                          {editingEmployee ? "Update Employee" : "Add Employee"}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Employee Directory
              </CardTitle>
            </CardHeader>
            <CardContent>
              {filteredEmployees.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No employees found. Add your first employee.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Code</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Designation</TableHead>
                      <TableHead className="text-right">Gross Salary</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEmployees.map((employee) => {
                      const gross = employee.basicSalary + employee.hra + employee.da + employee.ta + employee.otherAllowances
                      return (
                        <TableRow key={employee.id}>
                          <TableCell className="font-mono text-xs">
                            {employee.employeeCode}
                          </TableCell>
                          <TableCell className="font-medium">{employee.name}</TableCell>
                          <TableCell>{employee.department}</TableCell>
                          <TableCell>{employee.designation}</TableCell>
                          <TableCell className="text-right">
                            ₹{gross.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell>
                            <Badge variant={employee.status === "active" ? "default" : "secondary"}>
                              {employee.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex justify-center gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => editEmployee(employee)}
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => onDeleteEmployee(employee.id)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Salary Processing Tab */}
        <TabsContent value="salary" className="space-y-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Label>Month:</Label>
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger className="w-36">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {months.map((m, i) => (
                        <SelectItem key={m} value={String(i)}>{m}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2">
                  <Label>Year:</Label>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[2024, 2025, 2026].map((y) => (
                        <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Dialog open={showProcessSalary} onOpenChange={setShowProcessSalary}>
                  <DialogTrigger asChild>
                    <Button className="bg-amber-500 hover:bg-amber-600 text-slate-900 gap-2 ml-auto">
                      <Calculator className="h-4 w-4" />
                      Process Salary
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Process Salary for {months[Number(selectedMonth)]} {selectedYear}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label>Select Employee *</Label>
                        <Select
                          value={salaryForm.employeeId}
                          onValueChange={(v) => setSalaryForm({ ...salaryForm, employeeId: v })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select employee" />
                          </SelectTrigger>
                          <SelectContent>
                            {employees.filter(e => e.status === "active").map((e) => (
                              <SelectItem key={e.id} value={e.id}>
                                {e.employeeCode} - {e.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Working Days</Label>
                          <Input
                            type="number"
                            value={salaryForm.workingDays}
                            onChange={(e) => setSalaryForm({ ...salaryForm, workingDays: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Present Days</Label>
                          <Input
                            type="number"
                            value={salaryForm.presentDays}
                            onChange={(e) => setSalaryForm({ ...salaryForm, presentDays: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Other Deductions</Label>
                        <Input
                          type="number"
                          value={salaryForm.otherDeductions}
                          onChange={(e) => setSalaryForm({ ...salaryForm, otherDeductions: e.target.value })}
                        />
                      </div>
                      <div className="flex justify-end gap-3">
                        <Button variant="outline" onClick={() => setShowProcessSalary(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleProcessSalary} className="bg-amber-500 hover:bg-amber-600 text-slate-900">
                          Process
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>

          {/* Summary Cards */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground">Total Employees</p>
                <p className="text-2xl font-bold">{monthSlips.length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground">Gross Salary</p>
                <p className="text-2xl font-bold text-blue-600">
                  ₹{totalGrossSalary.toLocaleString("en-IN")}
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground">Total Deductions</p>
                <p className="text-2xl font-bold text-red-600">
                  ₹{totalDeductions.toLocaleString("en-IN")}
                </p>
              </CardContent>
            </Card>
            <Card className="border-emerald-500">
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground">Net Payable</p>
                <p className="text-2xl font-bold text-emerald-600">
                  ₹{totalNetSalary.toLocaleString("en-IN")}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>
                Salary Slips - {months[Number(selectedMonth)]} {selectedYear}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {monthSlips.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No salary processed for this month.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead className="text-center">Days</TableHead>
                      <TableHead className="text-right">Gross</TableHead>
                      <TableHead className="text-right">Deductions</TableHead>
                      <TableHead className="text-right">Net Salary</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {monthSlips.map((slip) => (
                      <TableRow key={slip.id}>
                        <TableCell className="font-medium">{slip.employeeName}</TableCell>
                        <TableCell className="text-center">
                          {slip.presentDays}/{slip.workingDays}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹{slip.grossSalary.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right text-red-600">
                          ₹{slip.totalDeductions.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right font-bold text-emerald-600">
                          ₹{slip.netSalary.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell>
                          <Badge variant={slip.status === "paid" ? "default" : "secondary"}>
                            {slip.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex justify-center gap-2">
                            <Button variant="ghost" size="icon" onClick={() => setViewSlip(slip)}>
                              <FileText className="h-4 w-4" />
                            </Button>
                            {slip.status !== "paid" && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => onUpdateSalarySlip(slip.id, { status: "paid", paymentDate: new Date().toISOString().split("T")[0] })}
                              >
                                <IndianRupee className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="cursor-pointer hover:border-amber-500 transition-colors">
              <CardContent className="pt-6 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <FileText className="h-6 w-6 text-blue-500" />
                </div>
                <div>
                  <h4 className="font-semibold">Monthly Payroll Summary</h4>
                  <p className="text-sm text-muted-foreground">
                    Department-wise salary report
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card className="cursor-pointer hover:border-amber-500 transition-colors">
              <CardContent className="pt-6 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-emerald-500/10 flex items-center justify-center">
                  <Download className="h-6 w-6 text-emerald-500" />
                </div>
                <div>
                  <h4 className="font-semibold">Bank Statement</h4>
                  <p className="text-sm text-muted-foreground">
                    For salary transfer
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card className="cursor-pointer hover:border-amber-500 transition-colors">
              <CardContent className="pt-6 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-amber-500/10 flex items-center justify-center">
                  <Calculator className="h-6 w-6 text-amber-500" />
                </div>
                <div>
                  <h4 className="font-semibold">PF/ESI Report</h4>
                  <p className="text-sm text-muted-foreground">
                    Statutory compliance report
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card className="cursor-pointer hover:border-amber-500 transition-colors">
              <CardContent className="pt-6 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-red-500/10 flex items-center justify-center">
                  <IndianRupee className="h-6 w-6 text-red-500" />
                </div>
                <div>
                  <h4 className="font-semibold">TDS Report</h4>
                  <p className="text-sm text-muted-foreground">
                    Tax deducted at source
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Salary Slip View Dialog */}
      <Dialog open={!!viewSlip} onOpenChange={() => setViewSlip(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Salary Slip</DialogTitle>
          </DialogHeader>
          {viewSlip && (
            <div className="space-y-4">
              <div className="text-center border-b pb-3">
                <h4 className="font-bold">{viewSlip.employeeName}</h4>
                <p className="text-sm text-muted-foreground">
                  {viewSlip.month} {viewSlip.year}
                </p>
              </div>

              <div className="space-y-2">
                <h5 className="font-semibold text-sm">Earnings</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Basic Salary</span>
                    <span>₹{viewSlip.basicSalary.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>HRA</span>
                    <span>₹{viewSlip.hra.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>DA</span>
                    <span>₹{viewSlip.da.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>TA</span>
                    <span>₹{viewSlip.ta.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between font-semibold border-t pt-1">
                    <span>Gross Salary</span>
                    <span className="text-blue-600">₹{viewSlip.grossSalary.toLocaleString("en-IN")}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h5 className="font-semibold text-sm">Deductions</h5>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>PF</span>
                    <span>₹{viewSlip.pf.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ESI</span>
                    <span>₹{viewSlip.esi.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>TDS</span>
                    <span>₹{viewSlip.tds.toLocaleString("en-IN")}</span>
                  </div>
                  <div className="flex justify-between font-semibold border-t pt-1">
                    <span>Total Deductions</span>
                    <span className="text-red-600">₹{viewSlip.totalDeductions.toLocaleString("en-IN")}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-between font-bold text-lg border-t pt-3">
                <span>Net Salary</span>
                <span className="text-emerald-600">₹{viewSlip.netSalary.toLocaleString("en-IN")}</span>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => window.print()}>
                  <Printer className="h-4 w-4 mr-2" />
                  Print
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
