"use client"

import { memo } from "react"
import { Building2, Calendar, Clock, User, IndianRupee, Keyboard } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import type { CompanySettings, PageType } from "@/app/page"

interface TopBarProps {
  companySettings: CompanySettings
  currentPage: PageType
  user: string
  cashBalance: number
  bankBalance: number
}

const pageLabels: Record<PageType, string> = {
  dashboard: "Gateway of VyaparERP",
  inventory: "Item / Stock Master",
  sales: "Sales Voucher",
  purchase: "Purchase Voucher",
  party: "Party Master",
  ledger: "Party Ledger",
  daybook: "Day Book",
  cashbook: "Cash Book",
  bankbook: "Bank Book",
  voucher: "Voucher Entry",
  expense: "Expense Manager",
  trialbalance: "Trial Balance",
  balancesheet: "Balance Sheet",
  profitloss: "Profit & Loss A/c",
  gstreports: "GST Reports",
  stockreport: "Stock Summary",
  outstanding: "Outstanding Report",
  payroll: "Payroll Management",
  compliance: "Compliance Center",
  settings: "Company Settings",
}

export const TopBar = memo(function TopBar({
  companySettings,
  currentPage,
  user,
  cashBalance,
  bankBalance,
}: TopBarProps) {
  const currentDate = new Date()
  const formattedDate = currentDate.toLocaleDateString("en-IN", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
  })
  const formattedTime = currentDate.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
  })

  return (
    <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-b border-slate-700 px-4 py-2">
      <div className="flex items-center justify-between">
        {/* Left - Company Info */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Building2 className="h-5 w-5 text-slate-900" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">
                {companySettings.name || "My Company"}
              </h1>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                {companySettings.gstin && (
                  <span className="font-mono">GSTIN: {companySettings.gstin}</span>
                )}
              </div>
            </div>
          </div>
          
          <div className="h-8 w-px bg-slate-700 mx-2" />
          
          {/* Current Page Title */}
          <div className="flex items-center gap-2">
            <span className="text-amber-400 font-semibold text-lg">
              {pageLabels[currentPage] || currentPage}
            </span>
          </div>
        </div>

        {/* Center - Quick Balances */}
        <div className="hidden lg:flex items-center gap-6">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
            <IndianRupee className="h-3.5 w-3.5 text-emerald-400" />
            <span className="text-xs text-slate-400">Cash:</span>
            <span className="text-sm font-semibold text-emerald-400">
              {cashBalance.toLocaleString("en-IN")}
            </span>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <IndianRupee className="h-3.5 w-3.5 text-blue-400" />
            <span className="text-xs text-slate-400">Bank:</span>
            <span className="text-sm font-semibold text-blue-400">
              {bankBalance.toLocaleString("en-IN")}
            </span>
          </div>
        </div>

        {/* Right - Date, Time, User */}
        <div className="flex items-center gap-4">
          {/* Financial Year Badge */}
          <Badge className="fy-badge hidden md:flex">
            FY {companySettings.financialYearStart?.split("-")[0] || "2024"}-{companySettings.financialYearEnd?.split("-")[0]?.slice(-2) || "25"}
          </Badge>
          
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Calendar className="h-3.5 w-3.5" />
            <span>{formattedDate}</span>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Clock className="h-3.5 w-3.5" />
            <span>{formattedTime}</span>
          </div>
          
          <div className="h-6 w-px bg-slate-700" />
          
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-full bg-amber-500/20 flex items-center justify-center">
              <User className="h-3.5 w-3.5 text-amber-400" />
            </div>
            <span className="text-sm font-medium text-white">{user}</span>
          </div>
          
          <div className="hidden md:flex items-center gap-1 text-xs text-slate-600 bg-slate-800/50 px-2 py-1 rounded">
            <Keyboard className="h-3 w-3" />
            <span>Press</span>
            <kbd className="px-1 bg-slate-700 rounded text-amber-400 text-[10px]">?</kbd>
          </div>
        </div>
      </div>
    </header>
  )
})
