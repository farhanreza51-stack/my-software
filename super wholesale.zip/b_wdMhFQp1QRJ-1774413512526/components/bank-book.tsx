"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Building2 } from "lucide-react"
import type { Transaction } from "@/app/page"

interface BankBookProps {
  transactions: Transaction[]
}

export function BankBook({ transactions }: BankBookProps) {
  const [dateFrom, setDateFrom] = useState(
    new Date(new Date().getFullYear(), new Date().getMonth(), 1)
      .toISOString()
      .split("T")[0]
  )
  const [dateTo, setDateTo] = useState(new Date().toISOString().split("T")[0])

  const bankTransactions = transactions
    .filter((txn) => txn.paymentMode === "bank")
    .filter((txn) => {
      const txnDate = new Date(txn.date)
      return txnDate >= new Date(dateFrom) && txnDate <= new Date(dateTo)
    })
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  // Calculate running balance
  let runningBalance = 0
  const entriesWithBalance = bankTransactions.map((txn) => {
    runningBalance += txn.debit - txn.credit
    return { ...txn, balance: runningBalance }
  })

  const totalDeposits = bankTransactions.reduce((a, b) => a + b.debit, 0)
  const totalWithdrawals = bankTransactions.reduce((a, b) => a + b.credit, 0)
  const closingBalance = totalDeposits - totalWithdrawals

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Bank Book</h2>
        <p className="text-muted-foreground">Track all bank transactions</p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">From:</span>
              <Input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-40"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">To:</span>
              <Input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-40"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Total Deposits</p>
            <p className="text-2xl font-bold text-emerald-600">
              ₹{totalDeposits.toLocaleString("en-IN")}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Total Withdrawals</p>
            <p className="text-2xl font-bold text-red-600">
              ₹{totalWithdrawals.toLocaleString("en-IN")}
            </p>
          </CardContent>
        </Card>
        <Card
          className={
            closingBalance >= 0 ? "border-emerald-500" : "border-red-500"
          }
        >
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Bank Balance</p>
            <p
              className={`text-2xl font-bold ${
                closingBalance >= 0 ? "text-emerald-600" : "text-red-600"
              }`}
            >
              ₹{Math.abs(closingBalance).toLocaleString("en-IN")}{" "}
              {closingBalance >= 0 ? "Dr" : "Cr"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Bank Book Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5" />
            Bank Transactions
          </CardTitle>
        </CardHeader>
        <CardContent>
          {entriesWithBalance.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No bank transactions found for the selected period.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Particulars</TableHead>
                  <TableHead>Voucher No</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead className="text-right">Deposits (Dr)</TableHead>
                  <TableHead className="text-right">Withdrawals (Cr)</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {entriesWithBalance.map((txn) => (
                  <TableRow key={txn.id}>
                    <TableCell>{txn.date}</TableCell>
                    <TableCell>
                      {txn.partyName && (
                        <span className="font-medium">{txn.partyName} - </span>
                      )}
                      {txn.description}
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {txn.voucherNo}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {txn.reference || "-"}
                    </TableCell>
                    <TableCell className="text-right text-emerald-600">
                      {txn.debit > 0
                        ? `₹${txn.debit.toLocaleString("en-IN")}`
                        : "-"}
                    </TableCell>
                    <TableCell className="text-right text-red-600">
                      {txn.credit > 0
                        ? `₹${txn.credit.toLocaleString("en-IN")}`
                        : "-"}
                    </TableCell>
                    <TableCell
                      className={`text-right font-medium ${
                        txn.balance >= 0 ? "text-emerald-600" : "text-red-600"
                      }`}
                    >
                      ₹{Math.abs(txn.balance).toLocaleString("en-IN")}{" "}
                      {txn.balance >= 0 ? "Dr" : "Cr"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
