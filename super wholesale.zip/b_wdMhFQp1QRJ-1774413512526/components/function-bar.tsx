"use client"

import { memo } from "react"
import { cn } from "@/lib/utils"
import type { PageType } from "@/app/page"

interface FunctionBarProps {
  currentPage: PageType
  onPageChange: (page: PageType) => void
  onOpenSearch: () => void
  onOpenCalculator: () => void
  onLogout: () => void
}

type FunctionKey = {
  key: string
  label: string
  action: "page" | "action"
  page?: PageType
  actionFn?: () => void
  color?: string
}

const functionKeys: FunctionKey[] = [
  { key: "F1", label: "Dashboard", action: "page", page: "dashboard", color: "text-emerald-400" },
  { key: "F2", label: "Sales", action: "page", page: "sales", color: "text-blue-400" },
  { key: "F3", label: "Purchase", action: "page", page: "purchase", color: "text-orange-400" },
  { key: "F4", label: "Voucher", action: "page", page: "voucher", color: "text-purple-400" },
  { key: "F5", label: "Expense", action: "page", page: "expense", color: "text-red-400" },
  { key: "F6", label: "Items", action: "page", page: "inventory", color: "text-cyan-400" },
  { key: "F7", label: "Party", action: "page", page: "party", color: "text-yellow-400" },
  { key: "F8", label: "Ledger", action: "page", page: "ledger", color: "text-indigo-400" },
  { key: "F9", label: "Balance", action: "page", page: "balancesheet", color: "text-teal-400" },
  { key: "F10", label: "P&L", action: "page", page: "profitloss", color: "text-lime-400" },
  { key: "F11", label: "GST", action: "page", page: "gstreports", color: "text-pink-400" },
  { key: "F12", label: "Settings", action: "page", page: "settings", color: "text-slate-400" },
]

export const FunctionBar = memo(function FunctionBar({
  currentPage,
  onPageChange,
  onOpenSearch,
  onOpenCalculator,
  onLogout,
}: FunctionBarProps) {
  const handleClick = (fKey: FunctionKey) => {
    if (fKey.action === "page" && fKey.page) {
      onPageChange(fKey.page)
    } else if (fKey.actionFn) {
      fKey.actionFn()
    }
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-slate-900 border-t border-slate-700 shadow-lg">
      {/* Main Function Keys */}
      <div className="flex items-stretch">
        {functionKeys.map((fKey) => (
          <button
            key={fKey.key}
            onClick={() => handleClick(fKey)}
            className={cn(
              "flex-1 flex flex-col items-center justify-center py-1.5 px-1 border-r border-slate-700 last:border-r-0 transition-all hover:bg-slate-800 active:bg-slate-700",
              currentPage === fKey.page && "bg-slate-800"
            )}
          >
            <span className={cn("text-[10px] font-bold", fKey.color || "text-amber-400")}>
              {fKey.key}
            </span>
            <span className={cn(
              "text-[9px] truncate max-w-full",
              currentPage === fKey.page ? "text-white font-medium" : "text-slate-400"
            )}>
              {fKey.label}
            </span>
          </button>
        ))}
      </div>
      
      {/* Quick Actions Row */}
      <div className="flex items-center justify-between px-2 py-1 bg-slate-950 border-t border-slate-800 text-[9px]">
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenSearch}
            className="flex items-center gap-1 text-slate-500 hover:text-white transition-colors"
          >
            <kbd className="px-1 bg-slate-800 rounded text-amber-400">Ctrl+F</kbd>
            <span>Search</span>
          </button>
          <button
            onClick={onOpenCalculator}
            className="flex items-center gap-1 text-slate-500 hover:text-white transition-colors"
          >
            <kbd className="px-1 bg-slate-800 rounded text-amber-400">Ctrl+K</kbd>
            <span>Calculator</span>
          </button>
          <span className="flex items-center gap-1 text-slate-600">
            <kbd className="px-1 bg-slate-800 rounded text-amber-400">?</kbd>
            <span>All Shortcuts</span>
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-slate-600">VyaparERP v2.0</span>
          <button
            onClick={onLogout}
            className="flex items-center gap-1 text-slate-500 hover:text-red-400 transition-colors"
          >
            <kbd className="px-1 bg-slate-800 rounded text-amber-400">Alt+Q</kbd>
            <span>Logout</span>
          </button>
        </div>
      </div>
    </div>
  )
})
