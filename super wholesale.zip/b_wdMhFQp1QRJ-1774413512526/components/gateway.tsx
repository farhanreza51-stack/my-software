"use client"

import { memo } from "react"
import { Card } from "@/components/ui/card"
import {
  Receipt,
  ShoppingCart,
  CreditCard,
  IndianRupee,
  Package,
  Users,
  BookOpen,
  Calendar,
  Wallet,
  Landmark,
  Scale,
  FileSpreadsheet,
  TrendingUp,
  FileText,
  BarChart3,
  AlertCircle,
  Briefcase,
  Shield,
  Settings,
  ArrowRight,
} from "lucide-react"
import type { PageType } from "@/app/page"

interface GatewayProps {
  onPageChange: (page: PageType) => void
  stats: {
    totalSales: number
    totalPurchases: number
    totalReceivables: number
    totalPayables: number
    cashBalance: number
    bankBalance: number
    inventoryValue: number
    lowStockCount: number
    pendingInvoices: number
  }
}

type QuickAction = {
  key: PageType
  label: string
  description: string
  icon: React.ComponentType<{ className?: string }>
  shortcut: string
  color: string
  bgColor: string
}

const transactionActions: QuickAction[] = [
  {
    key: "sales",
    label: "Sales Voucher",
    description: "Create sales invoice",
    icon: Receipt,
    shortcut: "F2",
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/10",
  },
  {
    key: "purchase",
    label: "Purchase Voucher",
    description: "Record purchase",
    icon: ShoppingCart,
    shortcut: "F3",
    color: "text-orange-400",
    bgColor: "bg-orange-500/10",
  },
  {
    key: "voucher",
    label: "Accounting Voucher",
    description: "Receipt, Payment, Journal",
    icon: CreditCard,
    shortcut: "F4",
    color: "text-purple-400",
    bgColor: "bg-purple-500/10",
  },
  {
    key: "expense",
    label: "Expense Entry",
    description: "Track expenses",
    icon: IndianRupee,
    shortcut: "F5",
    color: "text-red-400",
    bgColor: "bg-red-500/10",
  },
]

const masterActions: QuickAction[] = [
  {
    key: "inventory",
    label: "Stock Items",
    description: "Manage inventory",
    icon: Package,
    shortcut: "F6",
    color: "text-cyan-400",
    bgColor: "bg-cyan-500/10",
  },
  {
    key: "party",
    label: "Parties",
    description: "Customers & Suppliers",
    icon: Users,
    shortcut: "F7",
    color: "text-yellow-400",
    bgColor: "bg-yellow-500/10",
  },
]

const bookActions: QuickAction[] = [
  {
    key: "ledger",
    label: "Ledger",
    description: "Party accounts",
    icon: BookOpen,
    shortcut: "F8",
    color: "text-indigo-400",
    bgColor: "bg-indigo-500/10",
  },
  {
    key: "daybook",
    label: "Day Book",
    description: "Daily transactions",
    icon: Calendar,
    shortcut: "Alt+D",
    color: "text-slate-400",
    bgColor: "bg-slate-500/10",
  },
  {
    key: "cashbook",
    label: "Cash Book",
    description: "Cash transactions",
    icon: Wallet,
    shortcut: "Alt+C",
    color: "text-green-400",
    bgColor: "bg-green-500/10",
  },
  {
    key: "bankbook",
    label: "Bank Book",
    description: "Bank transactions",
    icon: Landmark,
    shortcut: "Alt+B",
    color: "text-blue-400",
    bgColor: "bg-blue-500/10",
  },
]

const reportActions: QuickAction[] = [
  {
    key: "trialbalance",
    label: "Trial Balance",
    description: "Account summary",
    icon: Scale,
    shortcut: "Alt+T",
    color: "text-teal-400",
    bgColor: "bg-teal-500/10",
  },
  {
    key: "balancesheet",
    label: "Balance Sheet",
    description: "Assets & Liabilities",
    icon: FileSpreadsheet,
    shortcut: "F9",
    color: "text-emerald-400",
    bgColor: "bg-emerald-500/10",
  },
  {
    key: "profitloss",
    label: "Profit & Loss",
    description: "Income statement",
    icon: TrendingUp,
    shortcut: "F10",
    color: "text-lime-400",
    bgColor: "bg-lime-500/10",
  },
  {
    key: "gstreports",
    label: "GST Reports",
    description: "GSTR-1, 2A, 3B",
    icon: FileText,
    shortcut: "F11",
    color: "text-pink-400",
    bgColor: "bg-pink-500/10",
  },
  {
    key: "stockreport",
    label: "Stock Summary",
    description: "Inventory status",
    icon: BarChart3,
    shortcut: "Alt+S",
    color: "text-cyan-400",
    bgColor: "bg-cyan-500/10",
  },
  {
    key: "outstanding",
    label: "Outstanding",
    description: "Receivables & Payables",
    icon: AlertCircle,
    shortcut: "Alt+O",
    color: "text-amber-400",
    bgColor: "bg-amber-500/10",
  },
]

const ActionCard = memo(function ActionCard({
  action,
  onClick,
}: {
  action: QuickAction
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left group"
    >
      <Card className="p-3 hover:border-amber-500/30 transition-all group-hover:bg-slate-800/50">
        <div className="flex items-start gap-3">
          <div className={`p-2 rounded-lg ${action.bgColor}`}>
            <action.icon className={`h-4 w-4 ${action.color}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="font-medium text-sm text-white group-hover:text-amber-400 transition-colors">
                {action.label}
              </span>
              <kbd className="text-[9px] font-mono bg-slate-800 px-1.5 py-0.5 rounded text-amber-400">
                {action.shortcut}
              </kbd>
            </div>
            <p className="text-xs text-slate-500 truncate">{action.description}</p>
          </div>
          <ArrowRight className="h-4 w-4 text-slate-600 group-hover:text-amber-400 transition-colors opacity-0 group-hover:opacity-100" />
        </div>
      </Card>
    </button>
  )
})

export const Gateway = memo(function Gateway({ onPageChange, stats }: GatewayProps) {
  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <Card className="p-3 bg-emerald-500/10 border-emerald-500/20">
          <div className="text-xs text-slate-400">Total Sales</div>
          <div className="text-lg font-bold text-emerald-400">
            {stats.totalSales.toLocaleString("en-IN")}
          </div>
        </Card>
        <Card className="p-3 bg-orange-500/10 border-orange-500/20">
          <div className="text-xs text-slate-400">Total Purchase</div>
          <div className="text-lg font-bold text-orange-400">
            {stats.totalPurchases.toLocaleString("en-IN")}
          </div>
        </Card>
        <Card className="p-3 bg-blue-500/10 border-blue-500/20">
          <div className="text-xs text-slate-400">Receivables</div>
          <div className="text-lg font-bold text-blue-400">
            {stats.totalReceivables.toLocaleString("en-IN")}
          </div>
        </Card>
        <Card className="p-3 bg-red-500/10 border-red-500/20">
          <div className="text-xs text-slate-400">Payables</div>
          <div className="text-lg font-bold text-red-400">
            {stats.totalPayables.toLocaleString("en-IN")}
          </div>
        </Card>
        <Card className="p-3 bg-green-500/10 border-green-500/20">
          <div className="text-xs text-slate-400">Cash Balance</div>
          <div className="text-lg font-bold text-green-400">
            {stats.cashBalance.toLocaleString("en-IN")}
          </div>
        </Card>
        <Card className="p-3 bg-cyan-500/10 border-cyan-500/20">
          <div className="text-xs text-slate-400">Bank Balance</div>
          <div className="text-lg font-bold text-cyan-400">
            {stats.bankBalance.toLocaleString("en-IN")}
          </div>
        </Card>
      </div>

      {/* Main Action Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Transactions */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            Transactions
          </h3>
          <div className="space-y-2">
            {transactionActions.map((action) => (
              <ActionCard
                key={action.key}
                action={action}
                onClick={() => onPageChange(action.key)}
              />
            ))}
          </div>
        </div>

        {/* Masters & Books */}
        <div className="space-y-6">
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <Package className="h-4 w-4" />
              Masters
            </h3>
            <div className="space-y-2">
              {masterActions.map((action) => (
                <ActionCard
                  key={action.key}
                  action={action}
                  onClick={() => onPageChange(action.key)}
                />
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Books
            </h3>
            <div className="space-y-2">
              {bookActions.map((action) => (
                <ActionCard
                  key={action.key}
                  action={action}
                  onClick={() => onPageChange(action.key)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Reports */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Reports
          </h3>
          <div className="space-y-2">
            {reportActions.map((action) => (
              <ActionCard
                key={action.key}
                action={action}
                onClick={() => onPageChange(action.key)}
              />
            ))}
          </div>
          
          {/* HR & System */}
          <div className="pt-3 border-t border-slate-800">
            <div className="space-y-2">
              <ActionCard
                action={{
                  key: "payroll",
                  label: "Payroll",
                  description: "Employee salaries",
                  icon: Briefcase,
                  shortcut: "Alt+P",
                  color: "text-violet-400",
                  bgColor: "bg-violet-500/10",
                }}
                onClick={() => onPageChange("payroll")}
              />
              <ActionCard
                action={{
                  key: "compliance",
                  label: "Compliance",
                  description: "GST, TDS, PF, ESI",
                  icon: Shield,
                  shortcut: "Alt+X",
                  color: "text-rose-400",
                  bgColor: "bg-rose-500/10",
                }}
                onClick={() => onPageChange("compliance")}
              />
              <ActionCard
                action={{
                  key: "settings",
                  label: "Settings",
                  description: "Company configuration",
                  icon: Settings,
                  shortcut: "F12",
                  color: "text-slate-400",
                  bgColor: "bg-slate-500/10",
                }}
                onClick={() => onPageChange("settings")}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Alerts */}
      {(stats.lowStockCount > 0 || stats.pendingInvoices > 0) && (
        <div className="grid md:grid-cols-2 gap-4">
          {stats.lowStockCount > 0 && (
            <Card className="p-4 border-amber-500/30 bg-amber-500/5">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-amber-500/20">
                  <AlertCircle className="h-5 w-5 text-amber-400" />
                </div>
                <div>
                  <div className="font-medium text-amber-400">Low Stock Alert</div>
                  <div className="text-sm text-slate-400">
                    {stats.lowStockCount} items are running low
                  </div>
                </div>
                <button
                  onClick={() => onPageChange("stockreport")}
                  className="ml-auto text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1"
                >
                  View Report <ArrowRight className="h-3 w-3" />
                </button>
              </div>
            </Card>
          )}
          {stats.pendingInvoices > 0 && (
            <Card className="p-4 border-red-500/30 bg-red-500/5">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-500/20">
                  <Receipt className="h-5 w-5 text-red-400" />
                </div>
                <div>
                  <div className="font-medium text-red-400">Pending Invoices</div>
                  <div className="text-sm text-slate-400">
                    {stats.pendingInvoices} invoices awaiting payment
                  </div>
                </div>
                <button
                  onClick={() => onPageChange("outstanding")}
                  className="ml-auto text-xs text-red-400 hover:text-red-300 flex items-center gap-1"
                >
                  View Report <ArrowRight className="h-3 w-3" />
                </button>
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  )
})
