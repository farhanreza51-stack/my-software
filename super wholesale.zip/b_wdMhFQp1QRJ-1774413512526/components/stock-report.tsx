"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Package,
  Search,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
} from "lucide-react"
import type { InventoryItem, Invoice } from "@/app/page"

interface StockReportProps {
  inventory: InventoryItem[]
  invoices: Invoice[]
}

export function StockReport({ inventory, invoices }: StockReportProps) {
  const [search, setSearch] = useState("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("name")

  const categories = [...new Set(inventory.map((i) => i.category).filter(Boolean))]

  // Calculate stock movement for each item
  const getStockMovement = (itemId: string) => {
    let totalSold = 0
    let totalPurchased = 0

    invoices.forEach((inv) => {
      inv.items.forEach((item) => {
        if (item.itemId === itemId) {
          if (inv.type === "sale") {
            totalSold += item.qty
          } else {
            totalPurchased += item.qty
          }
        }
      })
    })

    return { sold: totalSold, purchased: totalPurchased }
  }

  const inventoryWithMovement = inventory.map((item) => {
    const movement = getStockMovement(item.id)
    return {
      ...item,
      soldQty: movement.sold,
      purchasedQty: movement.purchased,
      stockValue: item.qty * item.purchasePrice,
      saleValue: item.qty * item.price,
      isLowStock: item.qty <= item.minStock,
    }
  })

  const filteredInventory = inventoryWithMovement
    .filter(
      (item) =>
        item.name.toLowerCase().includes(search.toLowerCase()) ||
        item.hsn.toLowerCase().includes(search.toLowerCase())
    )
    .filter((item) => categoryFilter === "all" || item.category === categoryFilter)
    .sort((a, b) => {
      switch (sortBy) {
        case "name":
          return a.name.localeCompare(b.name)
        case "qty-asc":
          return a.qty - b.qty
        case "qty-desc":
          return b.qty - a.qty
        case "value-asc":
          return a.stockValue - b.stockValue
        case "value-desc":
          return b.stockValue - a.stockValue
        default:
          return 0
      }
    })

  const lowStockItems = inventoryWithMovement.filter((i) => i.isLowStock)
  const totalStockValue = inventoryWithMovement.reduce(
    (a, b) => a + b.stockValue,
    0
  )
  const totalSaleValue = inventoryWithMovement.reduce(
    (a, b) => a + b.saleValue,
    0
  )
  const totalItems = inventory.reduce((a, b) => a + b.qty, 0)

  // Fast moving items (most sold)
  const fastMovingItems = [...inventoryWithMovement]
    .sort((a, b) => b.soldQty - a.soldQty)
    .slice(0, 10)

  // Slow moving items (least sold but have stock)
  const slowMovingItems = [...inventoryWithMovement]
    .filter((i) => i.qty > 0)
    .sort((a, b) => a.soldQty - b.soldQty)
    .slice(0, 10)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Stock Report</h2>
        <p className="text-muted-foreground">
          Analyze your inventory and stock movements
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Package className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Items</p>
                <p className="text-xl font-bold">
                  {totalItems.toLocaleString("en-IN")} units
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">
                  Stock Value (Cost)
                </p>
                <p className="text-xl font-bold text-emerald-600">
                  ₹{totalStockValue.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">
                  Stock Value (Sale)
                </p>
                <p className="text-xl font-bold text-amber-600">
                  ₹{totalSaleValue.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className={lowStockItems.length > 0 ? "border-red-500" : ""}>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div
                className={`h-10 w-10 rounded-full flex items-center justify-center ${
                  lowStockItems.length > 0
                    ? "bg-red-500/10"
                    : "bg-emerald-500/10"
                }`}
              >
                <AlertTriangle
                  className={`h-5 w-5 ${
                    lowStockItems.length > 0
                      ? "text-red-500"
                      : "text-emerald-500"
                  }`}
                />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Low Stock Items</p>
                <p
                  className={`text-xl font-bold ${
                    lowStockItems.length > 0 ? "text-red-600" : ""
                  }`}
                >
                  {lowStockItems.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Stock</TabsTrigger>
          <TabsTrigger value="lowstock">
            Low Stock ({lowStockItems.length})
          </TabsTrigger>
          <TabsTrigger value="fast">Fast Moving</TabsTrigger>
          <TabsTrigger value="slow">Slow Moving</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-wrap gap-4">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search items..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Name</SelectItem>
                    <SelectItem value="qty-asc">Qty (Low to High)</SelectItem>
                    <SelectItem value="qty-desc">Qty (High to Low)</SelectItem>
                    <SelectItem value="value-asc">Value (Low to High)</SelectItem>
                    <SelectItem value="value-desc">Value (High to Low)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Stock Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <StockTable items={filteredInventory} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lowstock">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <AlertTriangle className="h-5 w-5" />
                Low Stock Alert
              </CardTitle>
            </CardHeader>
            <CardContent>
              {lowStockItems.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  All items are well stocked!
                </p>
              ) : (
                <StockTable items={lowStockItems} showAlert />
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fast">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-emerald-600">
                <TrendingUp className="h-5 w-5" />
                Fast Moving Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              {fastMovingItems.every((i) => i.soldQty === 0) ? (
                <p className="text-muted-foreground text-center py-8">
                  No sales recorded yet.
                </p>
              ) : (
                <StockTable items={fastMovingItems} showMovement />
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="slow">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-600">
                <TrendingDown className="h-5 w-5" />
                Slow Moving Items
              </CardTitle>
            </CardHeader>
            <CardContent>
              {slowMovingItems.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No items with stock.
                </p>
              ) : (
                <StockTable items={slowMovingItems} showMovement />
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function StockTable({
  items,
  showAlert = false,
  showMovement = false,
}: {
  items: (InventoryItem & {
    soldQty: number
    purchasedQty: number
    stockValue: number
    saleValue: number
    isLowStock: boolean
  })[]
  showAlert?: boolean
  showMovement?: boolean
}) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="w-12">#</TableHead>
          <TableHead>Item Name</TableHead>
          <TableHead>Category</TableHead>
          <TableHead className="text-right">Current Qty</TableHead>
          {showMovement && (
            <>
              <TableHead className="text-right">Sold</TableHead>
              <TableHead className="text-right">Purchased</TableHead>
            </>
          )}
          {showAlert && <TableHead className="text-right">Min Stock</TableHead>}
          <TableHead className="text-right">Stock Value</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {items.map((item, index) => (
          <TableRow key={item.id}>
            <TableCell className="text-muted-foreground">{index + 1}</TableCell>
            <TableCell>
              <div>
                <p className="font-medium">{item.name}</p>
                {item.hsn && (
                  <p className="text-xs text-muted-foreground">HSN: {item.hsn}</p>
                )}
              </div>
            </TableCell>
            <TableCell>
              {item.category ? (
                <Badge variant="outline">{item.category}</Badge>
              ) : (
                "-"
              )}
            </TableCell>
            <TableCell className="text-right font-medium">
              {item.qty} {item.unit}
            </TableCell>
            {showMovement && (
              <>
                <TableCell className="text-right text-emerald-600">
                  {item.soldQty}
                </TableCell>
                <TableCell className="text-right text-blue-600">
                  {item.purchasedQty}
                </TableCell>
              </>
            )}
            {showAlert && (
              <TableCell className="text-right text-muted-foreground">
                {item.minStock}
              </TableCell>
            )}
            <TableCell className="text-right">
              ₹{item.stockValue.toLocaleString("en-IN")}
            </TableCell>
            <TableCell>
              {item.isLowStock ? (
                <Badge variant="destructive">Low Stock</Badge>
              ) : item.qty === 0 ? (
                <Badge variant="secondary">Out of Stock</Badge>
              ) : (
                <Badge variant="default">In Stock</Badge>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  )
}
