"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { 
  Receipt, 
  CreditCard, 
  ArrowUpRight, 
  ArrowDownLeft, 
  FileText,
  Save,
  Printer,
  Plus,
  Trash2,
  Calendar
} from "lucide-react"
import type { Party, Transaction } from "@/app/page"

interface VoucherEntryProps {
  parties: Party[]
  transactions: Transaction[]
  onAddTransaction: (txn: Omit<Transaction, "id" | "balance">) => void
  onDeleteTransaction: (id: string) => void
}

type VoucherType = "receipt" | "payment" | "journal" | "contra"

interface JournalEntry {
  id: string
  accountName: string
  debit: number
  credit: number
}

export function VoucherEntry({ parties, transactions, onAddTransaction, onDeleteTransaction }: VoucherEntryProps) {
  const [voucherType, setVoucherType] = useState<VoucherType>("receipt")
  const [date, setDate] = useState(new Date().toISOString().split("T")[0])
  const [partyId, setPartyId] = useState("")
  const [amount, setAmount] = useState("")
  const [paymentMode, setPaymentMode] = useState<"cash" | "bank">("cash")
  const [reference, setReference] = useState("")
  const [narration, setNarration] = useState("")
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([
    { id: "1", accountName: "", debit: 0, credit: 0 }
  ])

  const getVoucherNo = () => {
    const prefix = voucherType === "receipt" ? "RCP" : 
                   voucherType === "payment" ? "PAY" : 
                   voucherType === "journal" ? "JRN" : "CNT"
    const count = transactions.filter(t => t.type === voucherType).length + 1
    return `${prefix}-${String(count).padStart(5, "0")}`
  }

  const handleSubmit = () => {
    const party = parties.find(p => p.id === partyId)
    
    if (voucherType === "journal") {
      const totalDebit = journalEntries.reduce((a, b) => a + b.debit, 0)
      const totalCredit = journalEntries.reduce((a, b) => a + b.credit, 0)
      
      if (totalDebit !== totalCredit) {
        alert("Debit and Credit must be equal!")
        return
      }

      journalEntries.forEach(entry => {
        if (entry.accountName && (entry.debit > 0 || entry.credit > 0)) {
          onAddTransaction({
            date,
            type: "journal",
            voucherNo: getVoucherNo(),
            description: `Journal Entry - ${entry.accountName}`,
            debit: entry.debit,
            credit: entry.credit,
            paymentMode: "cash",
            reference: narration
          })
        }
      })
    } else {
      onAddTransaction({
        date,
        type: voucherType,
        voucherNo: getVoucherNo(),
        partyId: partyId || undefined,
        partyName: party?.name || undefined,
        description: `${voucherType.charAt(0).toUpperCase() + voucherType.slice(1)} ${party ? `- ${party.name}` : ""}`,
        debit: voucherType === "receipt" || voucherType === "contra" ? parseFloat(amount) || 0 : 0,
        credit: voucherType === "payment" || voucherType === "contra" ? parseFloat(amount) || 0 : 0,
        paymentMode,
        reference
      })
    }

    // Reset form
    setPartyId("")
    setAmount("")
    setReference("")
    setNarration("")
    setJournalEntries([{ id: "1", accountName: "", debit: 0, credit: 0 }])
  }

  const addJournalEntry = () => {
    setJournalEntries([
      ...journalEntries,
      { id: Math.random().toString(36).substr(2, 9), accountName: "", debit: 0, credit: 0 }
    ])
  }

  const removeJournalEntry = (id: string) => {
    if (journalEntries.length > 1) {
      setJournalEntries(journalEntries.filter(e => e.id !== id))
    }
  }

  const updateJournalEntry = (id: string, field: keyof JournalEntry, value: string | number) => {
    setJournalEntries(journalEntries.map(e => 
      e.id === id ? { ...e, [field]: value } : e
    ))
  }

  const getVoucherIcon = () => {
    switch (voucherType) {
      case "receipt": return <ArrowDownLeft className="h-5 w-5 text-green-500" />
      case "payment": return <ArrowUpRight className="h-5 w-5 text-red-500" />
      case "journal": return <FileText className="h-5 w-5 text-blue-500" />
      case "contra": return <CreditCard className="h-5 w-5 text-purple-500" />
    }
  }

  const recentVouchers = transactions
    .filter(t => ["receipt", "payment", "journal", "contra"].includes(t.type))
    .slice(-10)
    .reverse()

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Receipt className="h-6 w-6" />
          Voucher Entry
        </h1>
        <Badge variant="outline" className="text-sm">
          Voucher No: {getVoucherNo()}
        </Badge>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-6">
          <Tabs value={voucherType} onValueChange={(v) => setVoucherType(v as VoucherType)}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="receipt" className="gap-2">
            <ArrowDownLeft className="h-4 w-4" />
            Receipt
          </TabsTrigger>
          <TabsTrigger value="payment" className="gap-2">
            <ArrowUpRight className="h-4 w-4" />
            Payment
          </TabsTrigger>
          <TabsTrigger value="journal" className="gap-2">
            <FileText className="h-4 w-4" />
            Journal
          </TabsTrigger>
          <TabsTrigger value="contra" className="gap-2">
            <CreditCard className="h-4 w-4" />
            Contra
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <FileText className="h-4 w-4" />
            History
            </TabsList>

            <TabsContent value="receipt" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ArrowDownLeft className="h-5 w-5 text-green-500" />
                    Receipt Voucher
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Payment Mode</Label>
                      <Select value={paymentMode} onValueChange={(v) => setPaymentMode(v as "cash" | "bank")}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="bank">Bank</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Received From (Party)</Label>
                    <Select value={partyId} onValueChange={setPartyId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select party" />
                      </SelectTrigger>
                      <SelectContent>
                        {parties.map((party) => (
                          <SelectItem key={party.id} value={party.id}>
                            {party.name} ({party.type})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Amount</Label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Reference / Cheque No</Label>
                      <Input
                        placeholder="Reference number"
                        value={reference}
                        onChange={(e) => setReference(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Narration</Label>
                    <Textarea
                      placeholder="Enter narration..."
                      value={narration}
                      onChange={(e) => setNarration(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payment" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ArrowUpRight className="h-5 w-5 text-red-500" />
                    Payment Voucher
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Payment Mode</Label>
                      <Select value={paymentMode} onValueChange={(v) => setPaymentMode(v as "cash" | "bank")}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="bank">Bank</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Paid To (Party)</Label>
                    <Select value={partyId} onValueChange={setPartyId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select party" />
                      </SelectTrigger>
                      <SelectContent>
                        {parties.map((party) => (
                          <SelectItem key={party.id} value={party.id}>
                            {party.name} ({party.type})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Amount</Label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Reference / Cheque No</Label>
                      <Input
                        placeholder="Reference number"
                        value={reference}
                        onChange={(e) => setReference(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Narration</Label>
                    <Textarea
                      placeholder="Enter narration..."
                      value={narration}
                      onChange={(e) => setNarration(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="journal" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <FileText className="h-5 w-5 text-blue-500" />
                      Journal Voucher
                    </span>
                    <Button size="sm" onClick={addJournalEntry}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Row
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-48"
                    />
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Account Name</TableHead>
                        <TableHead className="text-right">Debit</TableHead>
                        <TableHead className="text-right">Credit</TableHead>
                        <TableHead className="w-12"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {journalEntries.map((entry) => (
                        <TableRow key={entry.id}>
                          <TableCell>
                            <Input
                              placeholder="Account name"
                              value={entry.accountName}
                              onChange={(e) => updateJournalEntry(entry.id, "accountName", e.target.value)}
                            />
                          </TableCell>
                          <TableCell>
                            <Input
                              type="number"
                              placeholder="0.00"
                              value={entry.debit || ""}
                              onChange={(e) => updateJournalEntry(entry.id, "debit", parseFloat(e.target.value) || 0)}
                              className="text-right"
                            />
                          </TableCell>
                          <TableCell>
                            <Input
                              type="number"
                              placeholder="0.00"
                              value={entry.credit || ""}
                              onChange={(e) => updateJournalEntry(entry.id, "credit", parseFloat(e.target.value) || 0)}
                              className="text-right"
                            />
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeJournalEntry(entry.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                      <TableRow className="bg-muted/50">
                        <TableCell className="font-semibold">Total</TableCell>
                        <TableCell className="text-right font-semibold">
                          {journalEntries.reduce((a, b) => a + b.debit, 0).toLocaleString("en-IN", {
                            style: "currency",
                            currency: "INR"
                          })}
                        </TableCell>
                        <TableCell className="text-right font-semibold">
                          {journalEntries.reduce((a, b) => a + b.credit, 0).toLocaleString("en-IN", {
                            style: "currency",
                            currency: "INR"
                          })}
                        </TableCell>
                        <TableCell></TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                  <div className="space-y-2">
                    <Label>Narration</Label>
                    <Textarea
                      placeholder="Enter narration..."
                      value={narration}
                      onChange={(e) => setNarration(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="contra" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5 text-purple-500" />
                    Contra Voucher (Cash to Bank / Bank to Cash)
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Date</Label>
                      <Input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Transfer Type</Label>
                      <Select value={paymentMode} onValueChange={(v) => setPaymentMode(v as "cash" | "bank")}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cash">Cash Deposited to Bank</SelectItem>
                          <SelectItem value="bank">Cash Withdrawn from Bank</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Amount</Label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Reference</Label>
                      <Input
                        placeholder="Reference number"
                        value={reference}
                        onChange={(e) => setReference(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Narration</Label>
                    <Textarea
                      placeholder="Enter narration..."
                      value={narration}
                      onChange={(e) => setNarration(e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <TabsContent value="history" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Voucher History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {transactions.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    No vouchers created yet.
                  </p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Voucher No</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Party</TableHead>
                        <TableHead className="text-right">Debit</TableHead>
                        <TableHead className="text-right">Credit</TableHead>
                        <TableHead className="text-center">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transactions
                        .slice()
                        .reverse()
                        .map((txn) => (
                          <TableRow key={txn.id}>
                            <TableCell className="font-mono font-medium">
                              {txn.voucherNo}
                            </TableCell>
                            <TableCell>{txn.date}</TableCell>
                            <TableCell>
                              <Badge variant="outline">
                                {txn.type}
                              </Badge>
                            </TableCell>
                            <TableCell>{txn.partyName || "-"}</TableCell>
                            <TableCell className="text-right">
                              {txn.debit > 0 ? `₹${txn.debit.toLocaleString("en-IN")}` : "-"}
                            </TableCell>
                            <TableCell className="text-right">
                              {txn.credit > 0 ? `₹${txn.credit.toLocaleString("en-IN")}` : "-"}
                            </TableCell>
                            <TableCell className="text-center">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => onDeleteTransaction(txn.id)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <div className="flex gap-4">
            <Button onClick={handleSubmit} className="gap-2">
              <Save className="h-4 w-4" />
              Save Voucher
            </Button>
            <Button variant="outline" className="gap-2">
              <Printer className="h-4 w-4" />
              Save & Print
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4" />
                Recent Vouchers
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 max-h-96 overflow-auto">
              {recentVouchers.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No vouchers yet
                </p>
              ) : (
                recentVouchers.map((voucher) => (
                  <div
                    key={voucher.id}
                    className="flex items-center justify-between p-2 bg-muted rounded text-sm"
                  >
                    <div>
                      <p className="font-medium">{voucher.voucherNo}</p>
                      <p className="text-xs text-muted-foreground">
                        {voucher.partyName || voucher.description}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={voucher.debit > 0 ? "text-green-600" : "text-red-600"}>
                        {(voucher.debit || voucher.credit).toLocaleString("en-IN", {
                          style: "currency",
                          currency: "INR"
                        })}
                      </p>
                      <p className="text-xs text-muted-foreground">{voucher.date}</p>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Quick Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Today&apos;s Receipts</span>
                <span className="font-medium text-green-600">
                  {transactions
                    .filter(t => t.type === "receipt" && t.date === new Date().toISOString().split("T")[0])
                    .reduce((a, b) => a + b.debit, 0)
                    .toLocaleString("en-IN", { style: "currency", currency: "INR" })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Today&apos;s Payments</span>
                <span className="font-medium text-red-600">
                  {transactions
                    .filter(t => t.type === "payment" && t.date === new Date().toISOString().split("T")[0])
                    .reduce((a, b) => a + b.credit, 0)
                    .toLocaleString("en-IN", { style: "currency", currency: "INR" })}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
