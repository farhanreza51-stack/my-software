"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Shield,
  FileText,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Download,
  ExternalLink,
  Bell,
  IndianRupee,
  Building2,
  FileCheck,
  Scale,
} from "lucide-react"
import type { Invoice, CompanySettings, SalarySlip } from "@/app/page"

interface ComplianceProps {
  invoices: Invoice[]
  settings: CompanySettings
  salarySlips?: SalarySlip[]
}

type ComplianceItem = {
  id: string
  name: string
  category: "gst" | "tds" | "pf" | "esi" | "income-tax" | "other"
  frequency: "monthly" | "quarterly" | "annually"
  dueDate: string
  status: "pending" | "completed" | "overdue"
  amount?: number
  description: string
  filingUrl?: string
}

const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
]

export function Compliance({ invoices, settings, salarySlips = [] }: ComplianceProps) {
  const [selectedYear, setSelectedYear] = useState(String(new Date().getFullYear()))
  const [selectedQuarter, setSelectedQuarter] = useState("Q1")

  const currentDate = new Date()
  const currentMonth = currentDate.getMonth()
  const currentYear = currentDate.getFullYear()

  // Calculate GST data
  const gstData = useMemo(() => {
    const salesByMonth: Record<number, { taxable: number; gst: number }> = {}
    const purchasesByMonth: Record<number, { taxable: number; gst: number }> = {}

    invoices.forEach((inv) => {
      const date = new Date(inv.date)
      if (date.getFullYear() === Number(selectedYear)) {
        const month = date.getMonth()
        if (inv.type === "sale") {
          if (!salesByMonth[month]) salesByMonth[month] = { taxable: 0, gst: 0 }
          salesByMonth[month].taxable += inv.subtotal
          salesByMonth[month].gst += inv.gstAmount
        } else {
          if (!purchasesByMonth[month]) purchasesByMonth[month] = { taxable: 0, gst: 0 }
          purchasesByMonth[month].taxable += inv.subtotal
          purchasesByMonth[month].gst += inv.gstAmount
        }
      }
    })

    return { salesByMonth, purchasesByMonth }
  }, [invoices, selectedYear])

  // Generate compliance calendar
  const complianceCalendar: ComplianceItem[] = useMemo(() => {
    const items: ComplianceItem[] = []

    // GSTR-1 (Monthly - 11th of next month)
    for (let m = 0; m < 12; m++) {
      const dueDate = new Date(Number(selectedYear), m + 1, 11)
      const isPast = dueDate < currentDate
      items.push({
        id: `gstr1-${m}`,
        name: `GSTR-1 (${months[m]})`,
        category: "gst",
        frequency: "monthly",
        dueDate: dueDate.toISOString().split("T")[0],
        status: isPast ? (m <= currentMonth - 1 ? "completed" : "overdue") : "pending",
        amount: gstData.salesByMonth[m]?.gst || 0,
        description: "Outward supplies return",
        filingUrl: "https://www.gst.gov.in/",
      })
    }

    // GSTR-3B (Monthly - 20th of next month)
    for (let m = 0; m < 12; m++) {
      const dueDate = new Date(Number(selectedYear), m + 1, 20)
      const isPast = dueDate < currentDate
      const outputGst = gstData.salesByMonth[m]?.gst || 0
      const inputGst = gstData.purchasesByMonth[m]?.gst || 0
      items.push({
        id: `gstr3b-${m}`,
        name: `GSTR-3B (${months[m]})`,
        category: "gst",
        frequency: "monthly",
        dueDate: dueDate.toISOString().split("T")[0],
        status: isPast ? (m <= currentMonth - 1 ? "completed" : "overdue") : "pending",
        amount: Math.max(outputGst - inputGst, 0),
        description: "Summary return with tax payment",
        filingUrl: "https://www.gst.gov.in/",
      })
    }

    // TDS Returns (Quarterly)
    const quarters = [
      { name: "Q1", months: [3, 4, 5], dueMonth: 6, dueDay: 31 },
      { name: "Q2", months: [6, 7, 8], dueMonth: 9, dueDay: 31 },
      { name: "Q3", months: [9, 10, 11], dueMonth: 0, dueDay: 31 },
      { name: "Q4", months: [0, 1, 2], dueMonth: 4, dueDay: 31 },
    ]

    quarters.forEach((q) => {
      const year = q.name === "Q4" ? Number(selectedYear) + 1 : Number(selectedYear)
      const dueDate = new Date(year, q.dueMonth, q.dueDay)
      const isPast = dueDate < currentDate
      items.push({
        id: `tds-${q.name}`,
        name: `TDS Return - ${q.name}`,
        category: "tds",
        frequency: "quarterly",
        dueDate: dueDate.toISOString().split("T")[0],
        status: isPast ? "completed" : "pending",
        description: "Form 24Q/26Q filing",
        filingUrl: "https://www.incometax.gov.in/",
      })
    })

    // PF (Monthly - 15th of next month)
    for (let m = 0; m < 12; m++) {
      const dueDate = new Date(Number(selectedYear), m + 1, 15)
      const isPast = dueDate < currentDate
      const monthSlips = salarySlips.filter(
        (s) => s.month === months[m] && s.year === Number(selectedYear)
      )
      const pfAmount = monthSlips.reduce((a, b) => a + b.pf * 2, 0) // Employee + Employer
      items.push({
        id: `pf-${m}`,
        name: `PF Challan (${months[m]})`,
        category: "pf",
        frequency: "monthly",
        dueDate: dueDate.toISOString().split("T")[0],
        status: isPast ? (m <= currentMonth - 1 ? "completed" : "overdue") : "pending",
        amount: pfAmount,
        description: "Employee Provident Fund",
        filingUrl: "https://www.epfindia.gov.in/",
      })
    }

    // ESI (Monthly - 15th of next month)
    for (let m = 0; m < 12; m++) {
      const dueDate = new Date(Number(selectedYear), m + 1, 15)
      const isPast = dueDate < currentDate
      const monthSlips = salarySlips.filter(
        (s) => s.month === months[m] && s.year === Number(selectedYear)
      )
      const esiAmount = monthSlips.reduce((a, b) => a + b.esi, 0)
      items.push({
        id: `esi-${m}`,
        name: `ESI Challan (${months[m]})`,
        category: "esi",
        frequency: "monthly",
        dueDate: dueDate.toISOString().split("T")[0],
        status: isPast ? (m <= currentMonth - 1 ? "completed" : "overdue") : "pending",
        amount: esiAmount,
        description: "Employee State Insurance",
        filingUrl: "https://www.esic.nic.in/",
      })
    }

    // Annual Returns
    items.push({
      id: `gstr9`,
      name: "GSTR-9 Annual Return",
      category: "gst",
      frequency: "annually",
      dueDate: `${Number(selectedYear) + 1}-12-31`,
      status: "pending",
      description: "Annual GST return",
      filingUrl: "https://www.gst.gov.in/",
    })

    items.push({
      id: `itr`,
      name: "Income Tax Return",
      category: "income-tax",
      frequency: "annually",
      dueDate: `${Number(selectedYear) + 1}-07-31`,
      status: "pending",
      description: "Company ITR filing",
      filingUrl: "https://www.incometax.gov.in/",
    })

    return items.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
  }, [selectedYear, gstData, salarySlips, currentDate, currentMonth])

  // Filter items
  const upcomingItems = complianceCalendar.filter(
    (item) => item.status === "pending" && new Date(item.dueDate) <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  )
  const overdueItems = complianceCalendar.filter((item) => item.status === "overdue")
  const completedItems = complianceCalendar.filter((item) => item.status === "completed")

  // Summary stats
  const totalCompliance = complianceCalendar.length
  const completedCount = completedItems.length
  const complianceScore = Math.round((completedCount / Math.max(totalCompliance, 1)) * 100)

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "gst": return <FileText className="h-4 w-4 text-blue-500" />
      case "tds": return <IndianRupee className="h-4 w-4 text-amber-500" />
      case "pf": return <Building2 className="h-4 w-4 text-emerald-500" />
      case "esi": return <Shield className="h-4 w-4 text-purple-500" />
      case "income-tax": return <Scale className="h-4 w-4 text-red-500" />
      default: return <FileCheck className="h-4 w-4 text-slate-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Completed</Badge>
      case "overdue":
        return <Badge variant="destructive">Overdue</Badge>
      case "pending":
        return <Badge variant="secondary">Pending</Badge>
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Shield className="h-6 w-6" />
            Compliance & Statutory
          </h2>
          <p className="text-muted-foreground">
            Track and manage all statutory compliance requirements
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-28">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[2024, 2025, 2026].map((y) => (
                <SelectItem key={y} value={String(y)}>FY {y}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Compliance Score</p>
                <p className="text-3xl font-bold">{complianceScore}%</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <CheckCircle2 className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
            <Progress value={complianceScore} className="mt-3 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Upcoming (30 days)</p>
                <p className="text-3xl font-bold">{upcomingItems.length}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-amber-500/10 flex items-center justify-center">
                <Clock className="h-6 w-6 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className={overdueItems.length > 0 ? "border-red-500" : ""}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Overdue</p>
                <p className={`text-3xl font-bold ${overdueItems.length > 0 ? "text-red-600" : ""}`}>
                  {overdueItems.length}
                </p>
              </div>
              <div className={`h-12 w-12 rounded-full flex items-center justify-center ${overdueItems.length > 0 ? "bg-red-500/10" : "bg-muted"}`}>
                <AlertTriangle className={`h-6 w-6 ${overdueItems.length > 0 ? "text-red-500" : "text-muted-foreground"}`} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-3xl font-bold text-emerald-600">{completedCount}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <FileCheck className="h-6 w-6 text-emerald-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      {overdueItems.length > 0 && (
        <Card className="border-red-500 bg-red-500/5">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              <div>
                <p className="font-semibold text-red-600">
                  {overdueItems.length} compliance item(s) are overdue!
                </p>
                <p className="text-sm text-muted-foreground">
                  Please complete them immediately to avoid penalties.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="calendar">
        <TabsList>
          <TabsTrigger value="calendar" className="gap-2">
            <Calendar className="h-4 w-4" />
            Compliance Calendar
          </TabsTrigger>
          <TabsTrigger value="gst" className="gap-2">
            <FileText className="h-4 w-4" />
            GST Summary
          </TabsTrigger>
          <TabsTrigger value="statutory" className="gap-2">
            <Building2 className="h-4 w-4" />
            Statutory (PF/ESI)
          </TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Compliance Calendar - FY {selectedYear}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Compliance</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-center">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {complianceCalendar.slice(0, 20).map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getCategoryIcon(item.category)}
                          <div>
                            <p className="font-medium">{item.name}</p>
                            <p className="text-xs text-muted-foreground">{item.description}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {item.category.replace("-", " ")}
                        </Badge>
                      </TableCell>
                      <TableCell>{item.dueDate}</TableCell>
                      <TableCell className="text-right">
                        {item.amount !== undefined ? `₹${item.amount.toLocaleString("en-IN")}` : "-"}
                      </TableCell>
                      <TableCell>{getStatusBadge(item.status)}</TableCell>
                      <TableCell className="text-center">
                        {item.filingUrl && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => window.open(item.filingUrl, "_blank")}
                          >
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gst" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Monthly GST Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Month</TableHead>
                      <TableHead className="text-right">Output GST</TableHead>
                      <TableHead className="text-right">Input GST</TableHead>
                      <TableHead className="text-right">Payable/Credit</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {months.map((month, index) => {
                      const output = gstData.salesByMonth[index]?.gst || 0
                      const input = gstData.purchasesByMonth[index]?.gst || 0
                      const net = output - input
                      return (
                        <TableRow key={month}>
                          <TableCell>{month.substring(0, 3)}</TableCell>
                          <TableCell className="text-right">
                            ₹{output.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{input.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className={`text-right font-medium ${net >= 0 ? "text-amber-600" : "text-emerald-600"}`}>
                            {net >= 0 ? "" : "-"}₹{Math.abs(net).toLocaleString("en-IN")}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>GST Filing Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {["GSTR-1", "GSTR-3B"].map((form) => {
                    const items = complianceCalendar.filter((c) => c.name.startsWith(form))
                    const completed = items.filter((c) => c.status === "completed").length
                    const total = items.length
                    return (
                      <div key={form} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{form}</span>
                          <span>{completed}/{total} filed</span>
                        </div>
                        <Progress value={(completed / total) * 100} className="h-2" />
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="statutory" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  PF (Provident Fund)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground">PF Registration No.</p>
                    <p className="font-mono font-semibold">DL/DLI/0123456/000</p>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Month</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {complianceCalendar
                        .filter((c) => c.category === "pf")
                        .slice(0, 6)
                        .map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>{item.name.replace("PF Challan (", "").replace(")", "")}</TableCell>
                            <TableCell className="text-right">
                              ₹{(item.amount || 0).toLocaleString("en-IN")}
                            </TableCell>
                            <TableCell>{getStatusBadge(item.status)}</TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  ESI (Employee State Insurance)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground">ESI Code</p>
                    <p className="font-mono font-semibold">11-00-123456-000-0001</p>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Month</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {complianceCalendar
                        .filter((c) => c.category === "esi")
                        .slice(0, 6)
                        .map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>{item.name.replace("ESI Challan (", "").replace(")", "")}</TableCell>
                            <TableCell className="text-right">
                              ₹{(item.amount || 0).toLocaleString("en-IN")}
                            </TableCell>
                            <TableCell>{getStatusBadge(item.status)}</TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
