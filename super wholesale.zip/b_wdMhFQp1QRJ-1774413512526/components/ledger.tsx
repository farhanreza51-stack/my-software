"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Search, TrendingUp, TrendingDown } from "lucide-react"
import type { Party, Invoice, Transaction } from "@/app/page"

interface LedgerProps {
  parties: Party[]
  invoices: Invoice[]
  transactions: Transaction[]
}

export function Ledger({ parties, invoices, transactions }: LedgerProps) {
  const [selectedParty, setSelectedParty] = useState<string>("all")
  const [search, setSearch] = useState("")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")

  const getPartyLedger = (partyId: string) => {
    const party = parties.find((p) => p.id === partyId)
    if (!party) return []

    const entries: {
      date: string
      description: string
      voucherNo: string
      debit: number
      credit: number
      balance: number
    }[] = []

    let runningBalance = party.openingBalance * (party.balanceType === "debit" ? 1 : -1)

    // Add opening balance entry
    if (party.openingBalance > 0) {
      entries.push({
        date: "Opening",
        description: "Opening Balance",
        voucherNo: "-",
        debit: party.balanceType === "debit" ? party.openingBalance : 0,
        credit: party.balanceType === "credit" ? party.openingBalance : 0,
        balance: runningBalance,
      })
    }

    // Get all invoices for this party
    const partyInvoices = invoices
      .filter((inv) => inv.partyId === partyId)
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

    // Get all transactions for this party
    const partyTransactions = transactions
      .filter((txn) => txn.partyId === partyId && txn.type === "receipt")
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

    // Combine and sort by date
    const allEntries = [
      ...partyInvoices.map((inv) => ({
        date: inv.date,
        type: inv.type as string,
        data: inv,
      })),
      ...partyTransactions.map((txn) => ({
        date: txn.date,
        type: "receipt" as string,
        data: txn,
      })),
    ].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

    for (const entry of allEntries) {
      if (entry.type === "sale") {
        const inv = entry.data as Invoice
        runningBalance += inv.total
        entries.push({
          date: inv.date,
          description: `Sale - ${inv.items.length} item(s)`,
          voucherNo: inv.invoiceNo,
          debit: inv.total,
          credit: 0,
          balance: runningBalance,
        })
      } else if (entry.type === "purchase") {
        const inv = entry.data as Invoice
        runningBalance -= inv.total
        entries.push({
          date: inv.date,
          description: `Purchase - ${inv.items.length} item(s)`,
          voucherNo: inv.invoiceNo,
          debit: 0,
          credit: inv.total,
          balance: runningBalance,
        })
      } else if (entry.type === "receipt") {
        const txn = entry.data as Transaction
        runningBalance -= txn.debit
        entries.push({
          date: txn.date,
          description: txn.description,
          voucherNo: txn.voucherNo,
          debit: 0,
          credit: txn.debit,
          balance: runningBalance,
        })
      }
    }

    return entries
  }

  const getAllPartiesBalance = () => {
    return parties.map((party) => {
      const ledger = getPartyLedger(party.id)
      const lastEntry = ledger[ledger.length - 1]
      return {
        ...party,
        currentBalance: lastEntry?.balance || 0,
      }
    })
  }

  const partiesWithBalance = getAllPartiesBalance()

  const filteredParties = partiesWithBalance.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase())
  )

  const selectedPartyLedger =
    selectedParty !== "all"
      ? getPartyLedger(selectedParty).filter((entry) => {
          if (!dateFrom && !dateTo) return true
          const entryDate = new Date(entry.date)
          if (entry.date === "Opening") return true
          if (dateFrom && entryDate < new Date(dateFrom)) return false
          if (dateTo && entryDate > new Date(dateTo)) return false
          return true
        })
      : []

  const totalDebit = selectedPartyLedger.reduce((a, b) => a + b.debit, 0)
  const totalCredit = selectedPartyLedger.reduce((a, b) => a + b.credit, 0)
  const closingBalance =
    selectedPartyLedger[selectedPartyLedger.length - 1]?.balance || 0

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Party Ledger</h2>
        <p className="text-muted-foreground">
          View detailed account statements for each party
        </p>
      </div>

      {selectedParty === "all" ? (
        <>
          {/* Party List View */}
          <Card>
            <CardContent className="pt-6">
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search parties..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredParties.map((party) => (
              <Card
                key={party.id}
                className="cursor-pointer hover:border-amber-500 transition-colors"
                onClick={() => setSelectedParty(party.id)}
              >
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{party.name}</p>
                      <Badge variant="outline" className="mt-1">
                        {party.type}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <p
                        className={`text-lg font-bold ${
                          party.currentBalance >= 0
                            ? "text-emerald-600"
                            : "text-red-600"
                        }`}
                      >
                        ₹{Math.abs(party.currentBalance).toLocaleString("en-IN")}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {party.currentBalance >= 0 ? (
                          <span className="flex items-center gap-1 justify-end">
                            <TrendingUp className="h-3 w-3" /> Receivable
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 justify-end">
                            <TrendingDown className="h-3 w-3" /> Payable
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredParties.length === 0 && (
            <Card>
              <CardContent className="py-8">
                <p className="text-muted-foreground text-center">
                  No parties found. Add parties from the Party Master section.
                </p>
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <>
          {/* Single Party Ledger View */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-wrap items-center gap-4">
                <Select value={selectedParty} onValueChange={setSelectedParty}>
                  <SelectTrigger className="w-[250px]">
                    <SelectValue placeholder="Select party" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Parties</SelectItem>
                    {parties.map((party) => (
                      <SelectItem key={party.id} value={party.id}>
                        {party.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">From:</span>
                  <Input
                    type="date"
                    value={dateFrom}
                    onChange={(e) => setDateFrom(e.target.value)}
                    className="w-40"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">To:</span>
                  <Input
                    type="date"
                    value={dateTo}
                    onChange={(e) => setDateTo(e.target.value)}
                    className="w-40"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Ledger Account -{" "}
                {parties.find((p) => p.id === selectedParty)?.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedPartyLedger.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No transactions found for this party.
                </p>
              ) : (
                <>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Particulars</TableHead>
                        <TableHead>Voucher No</TableHead>
                        <TableHead className="text-right">Debit</TableHead>
                        <TableHead className="text-right">Credit</TableHead>
                        <TableHead className="text-right">Balance</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedPartyLedger.map((entry, index) => (
                        <TableRow key={index}>
                          <TableCell>{entry.date}</TableCell>
                          <TableCell>{entry.description}</TableCell>
                          <TableCell className="font-mono text-sm">
                            {entry.voucherNo}
                          </TableCell>
                          <TableCell className="text-right">
                            {entry.debit > 0
                              ? `₹${entry.debit.toLocaleString("en-IN")}`
                              : "-"}
                          </TableCell>
                          <TableCell className="text-right">
                            {entry.credit > 0
                              ? `₹${entry.credit.toLocaleString("en-IN")}`
                              : "-"}
                          </TableCell>
                          <TableCell
                            className={`text-right font-medium ${
                              entry.balance >= 0
                                ? "text-emerald-600"
                                : "text-red-600"
                            }`}
                          >
                            ₹{Math.abs(entry.balance).toLocaleString("en-IN")}{" "}
                            {entry.balance >= 0 ? "Dr" : "Cr"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  <div className="mt-4 pt-4 border-t grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Total Debit</p>
                      <p className="text-lg font-bold">
                        ₹{totalDebit.toLocaleString("en-IN")}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Total Credit</p>
                      <p className="text-lg font-bold">
                        ₹{totalCredit.toLocaleString("en-IN")}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Closing Balance</p>
                      <p
                        className={`text-lg font-bold ${
                          closingBalance >= 0
                            ? "text-emerald-600"
                            : "text-red-600"
                        }`}
                      >
                        ₹{Math.abs(closingBalance).toLocaleString("en-IN")}{" "}
                        {closingBalance >= 0 ? "Dr" : "Cr"}
                      </p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
