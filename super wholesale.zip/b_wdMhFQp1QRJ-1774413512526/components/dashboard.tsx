"use client"

import { memo, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  IndianRupee,
  Package,
  Users,
  TrendingUp,
  TrendingDown,
  ShoppingCart,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Truck,
  Keyboard,
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import type { Invoice } from "@/app/page"

interface DashboardProps {
  totalSales: number
  totalPurchases: number
  totalReceivables: number
  totalPayables: number
  totalItems: number
  lowStockItems: number
  totalCustomers: number
  totalSuppliers: number
  recentInvoices: Invoice[]
  inventoryValue: number
  monthlyData: Invoice[]
}

// Memoized stat card component
const StatCard = memo(function StatCard({
  title,
  value,
  icon: Icon,
  iconColor,
  valueColor,
  subtitle,
  subtitleIcon: SubtitleIcon,
}: {
  title: string
  value: string
  icon: React.ComponentType<{ className?: string }>
  iconColor: string
  valueColor?: string
  subtitle: string
  subtitleIcon?: React.ComponentType<{ className?: string }>
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className={`h-4 w-4 ${iconColor}`} />
      </CardHeader>
      <CardContent>
        <div className={`text-2xl font-bold ${valueColor || ""}`}>{value}</div>
        <p className="text-xs text-muted-foreground flex items-center gap-1">
          {SubtitleIcon && <SubtitleIcon className={`h-3 w-3 ${iconColor}`} />}
          {subtitle}
        </p>
      </CardContent>
    </Card>
  )
})

export function Dashboard({
  totalSales,
  totalPurchases,
  totalReceivables,
  totalPayables,
  totalItems,
  lowStockItems,
  totalCustomers,
  totalSuppliers,
  recentInvoices,
  inventoryValue,
  monthlyData,
}: DashboardProps) {
  const grossProfit = totalSales - totalPurchases

  // Memoize chart data calculations
  const chartData = useMemo(() => {
    const months = ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"]
    const currentMonth = new Date().getMonth()
    const data = months.map((month, index) => {
      const monthInvoices = monthlyData.filter((inv) => {
        const invMonth = new Date(inv.date).getMonth()
        return invMonth === (index + 3) % 12
      })
      const sales = monthInvoices
        .filter((i) => i.type === "sale")
        .reduce((a, b) => a + b.total, 0)
      const purchases = monthInvoices
        .filter((i) => i.type === "purchase")
        .reduce((a, b) => a + b.total, 0)
      return { month, sales, purchases }
    })
    return data.slice(0, currentMonth >= 3 ? currentMonth - 2 : currentMonth + 10)
  }, [monthlyData])

  const pieData = useMemo(() => [
    { name: "Sales", value: totalSales, color: "#10b981" },
    { name: "Purchases", value: totalPurchases, color: "#f59e0b" },
    { name: "Receivables", value: totalReceivables, color: "#3b82f6" },
    { name: "Payables", value: totalPayables, color: "#ef4444" },
  ].filter((d) => d.value > 0), [totalSales, totalPurchases, totalReceivables, totalPayables])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Financial Overview</h2>
          <p className="text-muted-foreground text-sm">
            Charts and analytics for FY 2024-25
          </p>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Sales
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">
              ₹{totalSales.toLocaleString("en-IN")}
            </div>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <ArrowUpRight className="h-3 w-3 text-emerald-500" />
              All time revenue
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Purchases
            </CardTitle>
            <ShoppingCart className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">
              ₹{totalPurchases.toLocaleString("en-IN")}
            </div>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <ArrowDownRight className="h-3 w-3 text-amber-500" />
              All time purchases
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Receivables
            </CardTitle>
            <IndianRupee className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              ₹{totalReceivables.toLocaleString("en-IN")}
            </div>
            <p className="text-xs text-muted-foreground">Outstanding from customers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Payables
            </CardTitle>
            <TrendingDown className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              ₹{totalPayables.toLocaleString("en-IN")}
            </div>
            <p className="text-xs text-muted-foreground">Due to suppliers</p>
          </CardContent>
        </Card>
      </div>

      {/* Secondary Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Gross Profit
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${
                grossProfit >= 0 ? "text-emerald-600" : "text-red-600"
              }`}
            >
              ₹{grossProfit.toLocaleString("en-IN")}
            </div>
            <p className="text-xs text-muted-foreground">Sales - Purchases</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Inventory Value
            </CardTitle>
            <Package className="h-4 w-4 text-slate-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ₹{inventoryValue.toLocaleString("en-IN")}
            </div>
            <p className="text-xs text-muted-foreground">{totalItems} items in stock</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Customers
            </CardTitle>
            <Users className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCustomers}</div>
            <p className="text-xs text-muted-foreground">Active customers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Suppliers
            </CardTitle>
            <Truck className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalSuppliers}</div>
            <p className="text-xs text-muted-foreground">Active suppliers</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Sales vs Purchases</CardTitle>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip
                    formatter={(value: number) => `₹${value.toLocaleString("en-IN")}`}
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar dataKey="sales" fill="#10b981" name="Sales" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="purchases" fill="#f59e0b" name="Purchases" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No transaction data yet
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Financial Overview</CardTitle>
          </CardHeader>
          <CardContent>
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => `₹${value.toLocaleString("en-IN")}`}
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No financial data yet
              </div>
            )}
            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {pieData.map((item) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-sm text-muted-foreground">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts and Recent Transactions */}
      <div className="grid gap-6 lg:grid-cols-2">
        {lowStockItems > 0 && (
          <Card className="border-amber-500/50 bg-amber-500/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-600">
                <AlertTriangle className="h-5 w-5" />
                Low Stock Alert
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                {lowStockItems} item(s) are running low on stock. Check the Stock
                Report for details.
              </p>
            </CardContent>
          </Card>
        )}

        <Card className={lowStockItems === 0 ? "lg:col-span-2" : ""}>
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            {recentInvoices.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">
                No transactions yet. Create your first sale or purchase.
              </p>
            ) : (
              <div className="space-y-3">
                {recentInvoices.slice(0, 5).map((invoice) => (
                  <div
                    key={invoice.id}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-8 w-8 rounded-full flex items-center justify-center ${
                          invoice.type === "sale"
                            ? "bg-emerald-500/10 text-emerald-500"
                            : "bg-amber-500/10 text-amber-500"
                        }`}
                      >
                        {invoice.type === "sale" ? (
                          <TrendingUp className="h-4 w-4" />
                        ) : (
                          <ShoppingCart className="h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{invoice.partyName}</p>
                        <p className="text-xs text-muted-foreground">
                          {invoice.invoiceNo} • {invoice.date}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p
                        className={`font-semibold ${
                          invoice.type === "sale"
                            ? "text-emerald-600"
                            : "text-amber-600"
                        }`}
                      >
                        {invoice.type === "sale" ? "+" : "-"}₹
                        {invoice.total.toLocaleString("en-IN")}
                      </p>
                      <Badge
                        variant={
                          invoice.status === "paid"
                            ? "default"
                            : invoice.status === "partial"
                            ? "secondary"
                            : "destructive"
                        }
                        className="text-xs"
                      >
                        {invoice.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
