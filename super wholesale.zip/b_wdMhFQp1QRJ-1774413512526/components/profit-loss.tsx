"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { TrendingUp, TrendingDown, DollarSign } from "lucide-react"
import type { Invoice, Transaction, InventoryItem, CompanySettings } from "@/app/page"

interface ProfitLossProps {
  invoices: Invoice[]
  transactions: Transaction[]
  inventory: InventoryItem[]
  settings: CompanySettings
}

export function ProfitLoss({
  invoices,
  transactions,
  inventory,
  settings,
}: ProfitLossProps) {
  // Revenue
  const grossSales = invoices
    .filter((inv) => inv.type === "sale")
    .reduce((a, b) => a + b.subtotal, 0)

  const salesGst = invoices
    .filter((inv) => inv.type === "sale")
    .reduce((a, b) => a + b.gstAmount, 0)

  const salesDiscount = invoices
    .filter((inv) => inv.type === "sale")
    .reduce((a, b) => a + b.discount, 0)

  const netSales = grossSales - salesDiscount

  // Cost of Goods Sold
  const grossPurchases = invoices
    .filter((inv) => inv.type === "purchase")
    .reduce((a, b) => a + b.subtotal, 0)

  const purchaseGst = invoices
    .filter((inv) => inv.type === "purchase")
    .reduce((a, b) => a + b.gstAmount, 0)

  const purchaseDiscount = invoices
    .filter((inv) => inv.type === "purchase")
    .reduce((a, b) => a + b.discount, 0)

  const netPurchases = grossPurchases - purchaseDiscount

  // Closing Stock
  const closingStock = inventory.reduce(
    (a, b) => a + b.qty * b.purchasePrice,
    0
  )

  // Cost of Goods Sold = Opening Stock + Purchases - Closing Stock
  // Assuming no opening stock for simplicity
  const costOfGoodsSold = netPurchases - closingStock

  // Gross Profit
  const grossProfit = netSales - Math.max(costOfGoodsSold, 0)

  // Operating Expenses (from transactions marked as expense)
  const expenses = transactions
    .filter((txn) => txn.type === "expense")
    .reduce((a, b) => a + b.credit, 0)

  // Net Profit
  const netProfit = grossProfit - expenses

  // GST Summary
  const gstPayable = salesGst - purchaseGst

  const incomeItems = [
    { name: "Gross Sales", value: grossSales },
    { name: "Less: Sales Discount", value: -salesDiscount },
    { name: "Net Sales", value: netSales, isTotal: true },
  ]

  const costItems = [
    { name: "Gross Purchases", value: grossPurchases },
    { name: "Less: Purchase Discount", value: -purchaseDiscount },
    { name: "Net Purchases", value: netPurchases, isTotal: true },
    { name: "Less: Closing Stock", value: -closingStock },
    { name: "Cost of Goods Sold", value: Math.max(costOfGoodsSold, 0), isTotal: true },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">
          Profit & Loss Statement
        </h2>
        <p className="text-muted-foreground">
          {settings.name} - For the period{" "}
          {new Date(settings.financialYearStart).toLocaleDateString("en-IN")} to{" "}
          {new Date().toLocaleDateString("en-IN")}
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Net Sales</p>
                <p className="text-xl font-bold text-emerald-600">
                  ₹{netSales.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                <TrendingDown className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Net Purchases</p>
                <p className="text-xl font-bold text-amber-600">
                  ₹{netPurchases.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Gross Profit</p>
                <p
                  className={`text-xl font-bold ${
                    grossProfit >= 0 ? "text-blue-600" : "text-red-600"
                  }`}
                >
                  ₹{Math.abs(grossProfit).toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card
          className={netProfit >= 0 ? "border-emerald-500" : "border-red-500"}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div
                className={`h-10 w-10 rounded-full flex items-center justify-center ${
                  netProfit >= 0 ? "bg-emerald-500/10" : "bg-red-500/10"
                }`}
              >
                {netProfit >= 0 ? (
                  <TrendingUp className="h-5 w-5 text-emerald-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
              </div>
              <div>
                <p className="text-sm text-muted-foreground">
                  {netProfit >= 0 ? "Net Profit" : "Net Loss"}
                </p>
                <p
                  className={`text-xl font-bold ${
                    netProfit >= 0 ? "text-emerald-600" : "text-red-600"
                  }`}
                >
                  ₹{Math.abs(netProfit).toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* P&L Statement */}
      <Card>
        <CardHeader>
          <CardTitle>Trading and Profit & Loss Account</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Particulars</TableHead>
                <TableHead className="text-right">Amount (₹)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {/* Income Section */}
              <TableRow className="bg-emerald-500/5">
                <TableCell colSpan={2} className="font-semibold">
                  Income / Revenue
                </TableCell>
              </TableRow>
              {incomeItems.map((item) => (
                <TableRow key={item.name}>
                  <TableCell
                    className={item.isTotal ? "font-semibold" : "pl-6"}
                  >
                    {item.name}
                  </TableCell>
                  <TableCell
                    className={`text-right ${
                      item.value < 0
                        ? "text-red-600"
                        : item.isTotal
                        ? "font-semibold text-emerald-600"
                        : ""
                    }`}
                  >
                    {item.value < 0 ? "(" : ""}₹
                    {Math.abs(item.value).toLocaleString("en-IN")}
                    {item.value < 0 ? ")" : ""}
                  </TableCell>
                </TableRow>
              ))}

              {/* Cost Section */}
              <TableRow className="bg-amber-500/5">
                <TableCell colSpan={2} className="font-semibold">
                  Cost of Goods Sold
                </TableCell>
              </TableRow>
              {costItems.map((item) => (
                <TableRow key={item.name}>
                  <TableCell
                    className={item.isTotal ? "font-semibold" : "pl-6"}
                  >
                    {item.name}
                  </TableCell>
                  <TableCell
                    className={`text-right ${
                      item.value < 0
                        ? "text-emerald-600"
                        : item.isTotal
                        ? "font-semibold text-amber-600"
                        : ""
                    }`}
                  >
                    {item.value < 0 ? "(" : ""}₹
                    {Math.abs(item.value).toLocaleString("en-IN")}
                    {item.value < 0 ? ")" : ""}
                  </TableCell>
                </TableRow>
              ))}

              {/* Gross Profit */}
              <TableRow className="border-t-2 bg-blue-500/5">
                <TableCell className="font-bold">Gross Profit</TableCell>
                <TableCell
                  className={`text-right font-bold ${
                    grossProfit >= 0 ? "text-emerald-600" : "text-red-600"
                  }`}
                >
                  ₹{Math.abs(grossProfit).toLocaleString("en-IN")}
                  {grossProfit < 0 ? " (Loss)" : ""}
                </TableCell>
              </TableRow>

              {/* Expenses */}
              {expenses > 0 && (
                <>
                  <TableRow className="bg-red-500/5">
                    <TableCell colSpan={2} className="font-semibold">
                      Operating Expenses
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="pl-6">Total Expenses</TableCell>
                    <TableCell className="text-right text-red-600">
                      ₹{expenses.toLocaleString("en-IN")}
                    </TableCell>
                  </TableRow>
                </>
              )}

              {/* Net Profit */}
              <TableRow className="border-t-2">
                <TableCell className="font-bold text-lg">
                  {netProfit >= 0 ? "Net Profit" : "Net Loss"}
                </TableCell>
                <TableCell
                  className={`text-right font-bold text-lg ${
                    netProfit >= 0 ? "text-emerald-600" : "text-red-600"
                  }`}
                >
                  ₹{Math.abs(netProfit).toLocaleString("en-IN")}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* GST Summary */}
      <Card>
        <CardHeader>
          <CardTitle>GST Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-4 bg-emerald-500/5 rounded-lg">
              <p className="text-sm text-muted-foreground">Output GST (Sales)</p>
              <p className="text-xl font-bold text-emerald-600">
                ₹{salesGst.toLocaleString("en-IN")}
              </p>
            </div>
            <div className="p-4 bg-blue-500/5 rounded-lg">
              <p className="text-sm text-muted-foreground">
                Input GST (Purchases)
              </p>
              <p className="text-xl font-bold text-blue-600">
                ₹{purchaseGst.toLocaleString("en-IN")}
              </p>
            </div>
            <div
              className={`p-4 rounded-lg ${
                gstPayable >= 0 ? "bg-amber-500/5" : "bg-emerald-500/5"
              }`}
            >
              <p className="text-sm text-muted-foreground">
                {gstPayable >= 0 ? "GST Payable" : "GST Credit"}
              </p>
              <p
                className={`text-xl font-bold ${
                  gstPayable >= 0 ? "text-amber-600" : "text-emerald-600"
                }`}
              >
                ₹{Math.abs(gstPayable).toLocaleString("en-IN")}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profit Margin Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Profit Margin Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground">Gross Profit Margin</p>
              <p className="text-2xl font-bold">
                {netSales > 0
                  ? ((grossProfit / netSales) * 100).toFixed(2)
                  : "0"}
                %
              </p>
              <p className="text-xs text-muted-foreground">
                (Gross Profit / Net Sales) × 100
              </p>
            </div>
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm text-muted-foreground">Net Profit Margin</p>
              <p
                className={`text-2xl font-bold ${
                  netProfit >= 0 ? "text-emerald-600" : "text-red-600"
                }`}
              >
                {netSales > 0
                  ? ((netProfit / netSales) * 100).toFixed(2)
                  : "0"}
                %
              </p>
              <p className="text-xs text-muted-foreground">
                (Net Profit / Net Sales) × 100
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
