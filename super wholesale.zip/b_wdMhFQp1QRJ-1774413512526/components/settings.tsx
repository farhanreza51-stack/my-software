"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { 
  Building2, 
  CreditCard, 
  Calendar, 
  Tags, 
  Plus, 
  Trash2, 
  Save, 
  Database, 
  FileDown, 
  Upload,
  User,
  Lock,
  Eye,
  EyeOff,
  Shield,
  Check,
  Keyboard
} from "lucide-react"

type CompanySettings = {
  name: string
  address: string
  phone: string
  email: string
  gstin: string
  pan: string
  bankName: string
  accountNo: string
  ifsc: string
  financialYearStart: string
  financialYearEnd: string
}

type ExpenseCategory = {
  id: string
  name: string
}

type UserCredentials = {
  username: string
  password: string
}

interface SettingsProps {
  settings: CompanySettings
  onUpdateSettings: (settings: CompanySettings) => void
  expenseCategories: ExpenseCategory[]
  onUpdateCategories: (categories: ExpenseCategory[]) => void
}

const DEFAULT_CREDENTIALS: UserCredentials = {
  username: "admin",
  password: "admin123"
}

export function Settings({ settings, onUpdateSettings, expenseCategories, onUpdateCategories }: SettingsProps) {
  const [formData, setFormData] = useState<CompanySettings>(settings)
  const [newCategory, setNewCategory] = useState("")
  const [saved, setSaved] = useState(false)

  // User credentials state
  const [currentPassword, setCurrentPassword] = useState("")
  const [newUsername, setNewUsername] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [credentialError, setCredentialError] = useState("")
  const [credentialSuccess, setCredentialSuccess] = useState("")

  const handleSave = () => {
    onUpdateSettings(formData)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const handleAddCategory = () => {
    if (newCategory.trim()) {
      onUpdateCategories([
        ...expenseCategories,
        { id: Math.random().toString(36).substr(2, 9), name: newCategory.trim() }
      ])
      setNewCategory("")
    }
  }

  const handleDeleteCategory = (id: string) => {
    onUpdateCategories(expenseCategories.filter(c => c.id !== id))
  }

  const handleChangeCredentials = () => {
    setCredentialError("")
    setCredentialSuccess("")

    // Get current saved credentials
    const savedCreds = localStorage.getItem("erp_user_credentials")
    const currentCreds: UserCredentials = savedCreds 
      ? JSON.parse(savedCreds) 
      : DEFAULT_CREDENTIALS

    // Validate current password
    if (currentPassword !== currentCreds.password) {
      setCredentialError("Current password is incorrect")
      return
    }

    // Validate new password
    if (newPassword.length < 4) {
      setCredentialError("New password must be at least 4 characters")
      return
    }

    if (newPassword !== confirmPassword) {
      setCredentialError("New passwords do not match")
      return
    }

    // Validate username
    const finalUsername = newUsername.trim() || currentCreds.username
    if (finalUsername.length < 3) {
      setCredentialError("Username must be at least 3 characters")
      return
    }

    // Save new credentials
    const newCreds: UserCredentials = {
      username: finalUsername,
      password: newPassword
    }
    localStorage.setItem("erp_user_credentials", JSON.stringify(newCreds))

    setCredentialSuccess("Credentials updated successfully! Use new credentials on next login.")
    setCurrentPassword("")
    setNewUsername("")
    setNewPassword("")
    setConfirmPassword("")
  }

  const handleExportData = () => {
    const data = {
      settings,
      expenseCategories,
      inventory: JSON.parse(localStorage.getItem("erp_inventory") || "[]"),
      parties: JSON.parse(localStorage.getItem("erp_parties") || "[]"),
      invoices: JSON.parse(localStorage.getItem("erp_invoices") || "[]"),
      transactions: JSON.parse(localStorage.getItem("erp_transactions") || "[]"),
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `erp-backup-${new Date().toISOString().split("T")[0]}.json`
    a.click()
  }

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target?.result as string)
          if (data.settings) onUpdateSettings(data.settings)
          if (data.expenseCategories) onUpdateCategories(data.expenseCategories)
          if (data.inventory) localStorage.setItem("erp_inventory", JSON.stringify(data.inventory))
          if (data.parties) localStorage.setItem("erp_parties", JSON.stringify(data.parties))
          if (data.invoices) localStorage.setItem("erp_invoices", JSON.stringify(data.invoices))
          if (data.transactions) localStorage.setItem("erp_transactions", JSON.stringify(data.transactions))
          alert("Data imported successfully! Please refresh the page.")
        } catch {
          alert("Invalid file format")
        }
      }
      reader.readAsText(file)
    }
  }

  const shortcutGroups = [
    {
      title: "Navigation",
      shortcuts: [
        { keys: "F1", desc: "Dashboard" },
        { keys: "F2", desc: "Sales" },
        { keys: "F3", desc: "Purchase" },
        { keys: "F4", desc: "Voucher" },
        { keys: "F5", desc: "Expense" },
        { keys: "F6", desc: "Inventory" },
        { keys: "F7", desc: "Party" },
        { keys: "F8", desc: "Ledger" },
        { keys: "F9", desc: "Balance Sheet" },
        { keys: "F10", desc: "Profit & Loss" },
        { keys: "F11", desc: "GST Reports" },
        { keys: "F12", desc: "Settings" },
      ]
    },
    {
      title: "Quick Access",
      shortcuts: [
        { keys: "Alt+D", desc: "Day Book" },
        { keys: "Alt+C", desc: "Cash Book" },
        { keys: "Alt+B", desc: "Bank Book" },
        { keys: "Alt+T", desc: "Trial Balance" },
        { keys: "Alt+S", desc: "Stock Report" },
        { keys: "Alt+O", desc: "Outstanding" },
        { keys: "Alt+Q", desc: "Logout" },
      ]
    },
    {
      title: "Actions",
      shortcuts: [
        { keys: "Ctrl+S", desc: "Save" },
        { keys: "Ctrl+N", desc: "New Entry" },
        { keys: "Ctrl+P", desc: "Print" },
        { keys: "Ctrl+F", desc: "Search" },
        { keys: "Ctrl+K", desc: "Calculator" },
        { keys: "Ctrl+\\", desc: "Toggle Sidebar" },
        { keys: "?", desc: "Show Shortcuts" },
      ]
    }
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Settings</h1>
          <p className="text-muted-foreground">Manage your company and application settings</p>
        </div>
        <Button onClick={handleSave} className="gap-2">
          <Save className="h-4 w-4" />
          {saved ? "Saved!" : "Save Changes"}
        </Button>
      </div>

      <Tabs defaultValue="company" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="company" className="gap-2">
            <Building2 className="h-4 w-4" />
            <span className="hidden sm:inline">Company</span>
          </TabsTrigger>
          <TabsTrigger value="bank" className="gap-2">
            <CreditCard className="h-4 w-4" />
            <span className="hidden sm:inline">Bank</span>
          </TabsTrigger>
          <TabsTrigger value="financial" className="gap-2">
            <Calendar className="h-4 w-4" />
            <span className="hidden sm:inline">Financial</span>
          </TabsTrigger>
          <TabsTrigger value="categories" className="gap-2">
            <Tags className="h-4 w-4" />
            <span className="hidden sm:inline">Categories</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="shortcuts" className="gap-2">
            <Keyboard className="h-4 w-4" />
            <span className="hidden sm:inline">Shortcuts</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="company">
          <Card>
            <CardHeader>
              <CardTitle>Company Information</CardTitle>
              <CardDescription>Your business details used in invoices and reports</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Company Name</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Address</Label>
                <Input
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>GSTIN</Label>
                  <Input
                    value={formData.gstin}
                    onChange={(e) => setFormData({ ...formData, gstin: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>PAN</Label>
                <Input
                  value={formData.pan}
                  onChange={(e) => setFormData({ ...formData, pan: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bank">
          <Card>
            <CardHeader>
              <CardTitle>Bank Account Details</CardTitle>
              <CardDescription>Your primary bank account for transactions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Bank Name</Label>
                <Input
                  value={formData.bankName}
                  onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Account Number</Label>
                  <Input
                    value={formData.accountNo}
                    onChange={(e) => setFormData({ ...formData, accountNo: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>IFSC Code</Label>
                  <Input
                    value={formData.ifsc}
                    onChange={(e) => setFormData({ ...formData, ifsc: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financial">
          <Card>
            <CardHeader>
              <CardTitle>Financial Year Settings</CardTitle>
              <CardDescription>Define your accounting financial year period</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Financial Year Start</Label>
                  <Input
                    type="date"
                    value={formData.financialYearStart}
                    onChange={(e) => setFormData({ ...formData, financialYearStart: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Financial Year End</Label>
                  <Input
                    type="date"
                    value={formData.financialYearEnd}
                    onChange={(e) => setFormData({ ...formData, financialYearEnd: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories">
          <Card>
            <CardHeader>
              <CardTitle>Expense Categories</CardTitle>
              <CardDescription>Manage categories for expense tracking</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="New category name"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAddCategory()}
                />
                <Button onClick={handleAddCategory}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {expenseCategories.map((cat) => (
                  <div key={cat.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span>{cat.name}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteCategory(cat.id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Change Login Credentials
              </CardTitle>
              <CardDescription>Update your username and password for secure access</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {credentialError && (
                <Alert variant="destructive">
                  <AlertDescription>{credentialError}</AlertDescription>
                </Alert>
              )}
              {credentialSuccess && (
                <Alert className="border-green-500 bg-green-500/10">
                  <Check className="h-4 w-4 text-green-500" />
                  <AlertDescription className="text-green-500">{credentialSuccess}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label>Current Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type={showCurrentPassword ? "text" : "password"}
                    placeholder="Enter current password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="pl-10 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showCurrentPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label>New Username (leave blank to keep current)</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Enter new username"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>New Password *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type={showNewPassword ? "text" : "password"}
                      placeholder="Enter new password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="pl-10 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Confirm New Password *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="password"
                      placeholder="Confirm new password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </div>

              <Button onClick={handleChangeCredentials} className="w-full">
                <Shield className="h-4 w-4 mr-2" />
                Update Credentials
              </Button>

              <p className="text-xs text-muted-foreground text-center">
                Default credentials: admin / admin123
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shortcuts">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Keyboard className="h-5 w-5" />
                Keyboard Shortcuts
              </CardTitle>
              <CardDescription>
                Advanced keyboard shortcuts for faster navigation. Press <kbd className="px-1.5 py-0.5 bg-muted rounded text-xs font-mono">?</kbd> anywhere to show shortcuts.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {shortcutGroups.map((group) => (
                  <div key={group.title} className="space-y-3">
                    <h4 className="font-semibold text-amber-500">{group.title}</h4>
                    <div className="space-y-2">
                      {group.shortcuts.map((s, idx) => (
                        <div key={idx} className="flex items-center justify-between py-1">
                          <span className="text-sm text-muted-foreground">{s.desc}</span>
                          <kbd className="px-2 py-1 text-xs font-mono bg-slate-800 text-slate-300 rounded border border-slate-700">
                            {s.keys}
                          </kbd>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Data Management
          </CardTitle>
          <CardDescription>Backup and restore your business data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Button variant="outline" onClick={handleExportData} className="gap-2">
              <FileDown className="h-4 w-4" />
              Export All Data
            </Button>
            <div className="relative">
              <input
                type="file"
                accept=".json"
                onChange={handleImportData}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              <Button variant="outline" className="gap-2">
                <Upload className="h-4 w-4" />
                Import Data
              </Button>
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            Export your data as a backup or import previously exported data. Regular backups are recommended.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
