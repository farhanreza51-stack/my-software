"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Users, Search, Pencil, Trash2, Phone, Mail } from "lucide-react"
import type { Party } from "@/app/page"

interface PartyMasterProps {
  parties: Party[]
  onAddParty: (party: Omit<Party, "id">) => void
  onUpdateParty: (id: string, party: Partial<Party>) => void
  onDeleteParty: (id: string) => void
}

const emptyForm = {
  name: "",
  type: "customer" as const,
  phone: "",
  email: "",
  address: "",
  gstin: "",
  openingBalance: "",
  balanceType: "debit" as const,
}

export function PartyMaster({
  parties,
  onAddParty,
  onUpdateParty,
  onDeleteParty,
}: PartyMasterProps) {
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [search, setSearch] = useState("")
  const [activeTab, setActiveTab] = useState<"customer" | "supplier">("customer")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name) return

    const partyData = {
      name: form.name,
      type: form.type,
      phone: form.phone,
      email: form.email,
      address: form.address,
      gstin: form.gstin,
      openingBalance: Number(form.openingBalance) || 0,
      balanceType: form.balanceType,
    }

    if (editingId) {
      onUpdateParty(editingId, partyData)
    } else {
      onAddParty(partyData)
    }

    setForm(emptyForm)
    setEditingId(null)
    setDialogOpen(false)
  }

  const handleEdit = (party: Party) => {
    setForm({
      name: party.name,
      type: party.type,
      phone: party.phone,
      email: party.email,
      address: party.address,
      gstin: party.gstin,
      openingBalance: String(party.openingBalance),
      balanceType: party.balanceType,
    })
    setEditingId(party.id)
    setDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this party?")) {
      onDeleteParty(id)
    }
  }

  const filteredParties = parties
    .filter((p) => p.type === activeTab)
    .filter(
      (p) =>
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.phone.includes(search) ||
        p.gstin.toLowerCase().includes(search.toLowerCase())
    )

  const customers = parties.filter((p) => p.type === "customer")
  const suppliers = parties.filter((p) => p.type === "supplier")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Party Master</h2>
          <p className="text-muted-foreground">
            Manage your customers and suppliers
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button
              className="bg-amber-500 hover:bg-amber-600 text-slate-900"
              onClick={() => {
                setForm({ ...emptyForm, type: activeTab })
                setEditingId(null)
              }}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add {activeTab === "customer" ? "Customer" : "Supplier"}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>
                {editingId ? "Edit Party" : "Add New Party"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Party Type</label>
                <Select
                  value={form.type}
                  onValueChange={(v) =>
                    setForm({ ...form, type: v as "customer" | "supplier" })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="customer">Customer</SelectItem>
                    <SelectItem value="supplier">Supplier</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Party Name *</label>
                <Input
                  placeholder="Enter party name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Phone</label>
                  <Input
                    placeholder="Phone number"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input
                    type="email"
                    placeholder="Email address"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">GSTIN</label>
                <Input
                  placeholder="GST Number"
                  value={form.gstin}
                  onChange={(e) =>
                    setForm({ ...form, gstin: e.target.value.toUpperCase() })
                  }
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Address</label>
                <Textarea
                  placeholder="Full address"
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Opening Balance</label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={form.openingBalance}
                    onChange={(e) =>
                      setForm({ ...form, openingBalance: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Balance Type</label>
                  <Select
                    value={form.balanceType}
                    onValueChange={(v) =>
                      setForm({ ...form, balanceType: v as "debit" | "credit" })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="debit">
                        Debit (We will receive)
                      </SelectItem>
                      <SelectItem value="credit">
                        Credit (We will pay)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-600 text-slate-900"
                >
                  {editingId ? "Update" : "Add"} Party
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-blue-600">
                  {customers.length}
                </div>
                <p className="text-sm text-muted-foreground">Total Customers</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-amber-600">
                  {suppliers.length}
                </div>
                <p className="text-sm text-muted-foreground">Total Suppliers</p>
              </div>
              <Users className="h-8 w-8 text-amber-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs and Search */}
      <Tabs
        value={activeTab}
        onValueChange={(v) => setActiveTab(v as "customer" | "supplier")}
      >
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <TabsList>
            <TabsTrigger value="customer">
              Customers ({customers.length})
            </TabsTrigger>
            <TabsTrigger value="supplier">
              Suppliers ({suppliers.length})
            </TabsTrigger>
          </TabsList>

          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, phone, GSTIN..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>

        <TabsContent value="customer" className="mt-4">
          <PartyTable
            parties={filteredParties}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        </TabsContent>

        <TabsContent value="supplier" className="mt-4">
          <PartyTable
            parties={filteredParties}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function PartyTable({
  parties,
  onEdit,
  onDelete,
}: {
  parties: Party[]
  onEdit: (party: Party) => void
  onDelete: (id: string) => void
}) {
  return (
    <Card>
      <CardContent className="pt-6">
        {parties.length === 0 ? (
          <p className="text-muted-foreground text-center py-8">
            No parties found. Add your first party using the button above.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>GSTIN</TableHead>
                <TableHead className="text-right">Opening Bal.</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {parties.map((party, index) => (
                <TableRow key={party.id}>
                  <TableCell className="font-medium text-muted-foreground">
                    {index + 1}
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{party.name}</p>
                      {party.address && (
                        <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                          {party.address}
                        </p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      {party.phone && (
                        <p className="text-sm flex items-center gap-1">
                          <Phone className="h-3 w-3" /> {party.phone}
                        </p>
                      )}
                      {party.email && (
                        <p className="text-sm flex items-center gap-1 text-muted-foreground">
                          <Mail className="h-3 w-3" /> {party.email}
                        </p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    {party.gstin ? (
                      <code className="text-xs bg-muted px-2 py-1 rounded">
                        {party.gstin}
                      </code>
                    ) : (
                      <span className="text-muted-foreground text-sm">-</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {party.openingBalance > 0 ? (
                      <Badge
                        variant={
                          party.balanceType === "debit" ? "default" : "secondary"
                        }
                      >
                        ₹{party.openingBalance.toLocaleString("en-IN")}{" "}
                        {party.balanceType === "debit" ? "Dr" : "Cr"}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onEdit(party)}
                        className="h-8 w-8"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onDelete(party.id)}
                        className="h-8 w-8 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  )
}
