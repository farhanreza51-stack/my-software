"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Calendar, TrendingUp, TrendingDown, IndianRupee } from "lucide-react"
import type { Transaction, Invoice } from "@/app/page"

interface DayBookProps {
  transactions: Transaction[]
  invoices: Invoice[]
}

export function DayBook({ transactions, invoices }: DayBookProps) {
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  )

  // Combine all entries for the day
  const getDayEntries = () => {
    const entries: {
      id: string
      time: string
      type: string
      voucherNo: string
      party: string
      description: string
      debit: number
      credit: number
    }[] = []

    // Add invoices
    invoices
      .filter((inv) => inv.date === selectedDate)
      .forEach((inv) => {
        entries.push({
          id: inv.id,
          time: "00:00",
          type: inv.type === "sale" ? "Sales" : "Purchase",
          voucherNo: inv.invoiceNo,
          party: inv.partyName,
          description: `${inv.items.length} item(s)`,
          debit: inv.type === "sale" ? inv.total : 0,
          credit: inv.type === "purchase" ? inv.total : 0,
        })
      })

    // Add transactions (receipts, payments, expenses)
    transactions
      .filter(
        (txn) =>
          txn.date === selectedDate && !["sale", "purchase"].includes(txn.type)
      )
      .forEach((txn) => {
        entries.push({
          id: txn.id,
          time: "00:00",
          type: txn.type.charAt(0).toUpperCase() + txn.type.slice(1),
          voucherNo: txn.voucherNo,
          party: txn.partyName || "-",
          description: txn.description,
          debit: txn.debit,
          credit: txn.credit,
        })
      })

    return entries
  }

  const dayEntries = getDayEntries()
  const totalDebit = dayEntries.reduce((a, b) => a + b.debit, 0)
  const totalCredit = dayEntries.reduce((a, b) => a + b.credit, 0)

  // Calculate summary for the date
  const daySales = invoices
    .filter((inv) => inv.date === selectedDate && inv.type === "sale")
    .reduce((a, b) => a + b.total, 0)

  const dayPurchases = invoices
    .filter((inv) => inv.date === selectedDate && inv.type === "purchase")
    .reduce((a, b) => a + b.total, 0)

  const dayReceipts = transactions
    .filter((txn) => txn.date === selectedDate && txn.type === "receipt")
    .reduce((a, b) => a + b.debit, 0)

  const dayPayments = transactions
    .filter((txn) => txn.date === selectedDate && txn.type === "payment")
    .reduce((a, b) => a + b.credit, 0)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Day Book</h2>
        <p className="text-muted-foreground">
          View all transactions for a specific date
        </p>
      </div>

      {/* Date Selector */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <Calendar className="h-5 w-5 text-muted-foreground" />
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-48"
            />
            <span className="text-muted-foreground">
              {new Date(selectedDate).toLocaleDateString("en-IN", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Sales</p>
                <p className="text-xl font-bold text-emerald-600">
                  ₹{daySales.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                <TrendingDown className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Purchases</p>
                <p className="text-xl font-bold text-amber-600">
                  ₹{dayPurchases.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <IndianRupee className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Receipts</p>
                <p className="text-xl font-bold text-blue-600">
                  ₹{dayReceipts.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-red-500/10 flex items-center justify-center">
                <IndianRupee className="h-5 w-5 text-red-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Payments</p>
                <p className="text-xl font-bold text-red-600">
                  ₹{dayPayments.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Day Book Table */}
      <Card>
        <CardHeader>
          <CardTitle>Transactions for {selectedDate}</CardTitle>
        </CardHeader>
        <CardContent>
          {dayEntries.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              No transactions recorded for this date.
            </p>
          ) : (
            <>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Voucher No</TableHead>
                    <TableHead>Party</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Debit</TableHead>
                    <TableHead className="text-right">Credit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dayEntries.map((entry, index) => (
                    <TableRow key={entry.id}>
                      <TableCell className="text-muted-foreground">
                        {index + 1}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            entry.type === "Sales"
                              ? "default"
                              : entry.type === "Purchase"
                              ? "secondary"
                              : entry.type === "Receipt"
                              ? "outline"
                              : "destructive"
                          }
                        >
                          {entry.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {entry.voucherNo}
                      </TableCell>
                      <TableCell>{entry.party}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {entry.description}
                      </TableCell>
                      <TableCell className="text-right">
                        {entry.debit > 0
                          ? `₹${entry.debit.toLocaleString("en-IN")}`
                          : "-"}
                      </TableCell>
                      <TableCell className="text-right">
                        {entry.credit > 0
                          ? `₹${entry.credit.toLocaleString("en-IN")}`
                          : "-"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="mt-4 pt-4 border-t flex justify-end gap-8">
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Total Debit</p>
                  <p className="text-lg font-bold">
                    ₹{totalDebit.toLocaleString("en-IN")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Total Credit</p>
                  <p className="text-lg font-bold">
                    ₹{totalCredit.toLocaleString("en-IN")}
                  </p>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
