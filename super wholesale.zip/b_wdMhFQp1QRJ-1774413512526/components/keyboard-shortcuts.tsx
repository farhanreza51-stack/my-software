"use client"

import { useEffect, useCallback, useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Keyboard, Command, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from "lucide-react"
import type { PageType } from "@/app/page"

interface KeyboardShortcutsProps {
  onPageChange: (page: PageType) => void
  onLogout: () => void
  currentPage: PageType
  onToggleSidebar: () => void
  onOpenSearch?: () => void
  onOpenCalculator?: () => void
  onPrint?: () => void
  onSave?: () => void
  onNew?: () => void
}

type ShortcutCategory = {
  title: string
  shortcuts: {
    keys: string[]
    description: string
    action?: () => void
  }[]
}

export function KeyboardShortcuts({
  onPageChange,
  onLogout,
  currentPage,
  onToggleSidebar,
  onOpenSearch,
  onOpenCalculator,
  onPrint,
  onSave,
  onNew,
}: KeyboardShortcutsProps) {
  const [showHelp, setShowHelp] = useState(false)

  const shortcuts: ShortcutCategory[] = [
    {
      title: "Navigation (Function Keys)",
      shortcuts: [
        { keys: ["F1"], description: "Dashboard", action: () => onPageChange("dashboard") },
        { keys: ["F2"], description: "Sales / Billing", action: () => onPageChange("sales") },
        { keys: ["F3"], description: "Purchase Entry", action: () => onPageChange("purchase") },
        { keys: ["F4"], description: "Voucher Entry", action: () => onPageChange("voucher") },
        { keys: ["F5"], description: "Expense Manager", action: () => onPageChange("expense") },
        { keys: ["F6"], description: "Inventory Master", action: () => onPageChange("inventory") },
        { keys: ["F7"], description: "Party Master", action: () => onPageChange("party") },
        { keys: ["F8"], description: "Party Ledger", action: () => onPageChange("ledger") },
        { keys: ["F9"], description: "Balance Sheet", action: () => onPageChange("balancesheet") },
        { keys: ["F10"], description: "Profit & Loss", action: () => onPageChange("profitloss") },
        { keys: ["F11"], description: "GST Reports", action: () => onPageChange("gstreports") },
        { keys: ["F12"], description: "Settings", action: () => onPageChange("settings") },
      ],
    },
    {
      title: "Quick Actions (Alt + Key)",
      shortcuts: [
        { keys: ["Alt", "D"], description: "Day Book", action: () => onPageChange("daybook") },
        { keys: ["Alt", "C"], description: "Cash Book", action: () => onPageChange("cashbook") },
        { keys: ["Alt", "B"], description: "Bank Book", action: () => onPageChange("bankbook") },
        { keys: ["Alt", "T"], description: "Trial Balance", action: () => onPageChange("trialbalance") },
        { keys: ["Alt", "S"], description: "Stock Report", action: () => onPageChange("stockreport") },
        { keys: ["Alt", "O"], description: "Outstanding Report", action: () => onPageChange("outstanding") },
        { keys: ["Alt", "P"], description: "Payroll", action: () => onPageChange("payroll") },
        { keys: ["Alt", "X"], description: "Compliance", action: () => onPageChange("compliance") },
        { keys: ["Alt", "Q"], description: "Logout", action: onLogout },
      ],
    },
    {
      title: "Ctrl Shortcuts",
      shortcuts: [
        { keys: ["Ctrl", "S"], description: "Save current form", action: onSave },
        { keys: ["Ctrl", "N"], description: "New entry / Add new", action: onNew },
        { keys: ["Ctrl", "P"], description: "Print current view", action: onPrint },
        { keys: ["Ctrl", "F"], description: "Search / Find", action: onOpenSearch },
        { keys: ["Ctrl", "K"], description: "Command palette / Calculator", action: onOpenCalculator },
        { keys: ["Ctrl", "\\"], description: "Toggle sidebar", action: onToggleSidebar },
      ],
    },
    {
      title: "General",
      shortcuts: [
        { keys: ["Esc"], description: "Close dialog / Cancel" },
        { keys: ["?"], description: "Show this help dialog", action: () => setShowHelp(true) },
        { keys: ["Tab"], description: "Move to next field" },
        { keys: ["Shift", "Tab"], description: "Move to previous field" },
        { keys: ["Enter"], description: "Confirm / Submit" },
        { keys: ["Arrow Keys"], description: "Navigate in tables/lists" },
        { keys: ["Home"], description: "Go to first item" },
        { keys: ["End"], description: "Go to last item" },
        { keys: ["Page Up"], description: "Scroll up" },
        { keys: ["Page Down"], description: "Scroll down" },
      ],
    },
  ]

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Prevent shortcuts when typing in input fields (except for specific keys)
    const target = e.target as HTMLElement
    const isInputField = target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable
    
    // Function keys work everywhere
    if (e.key.startsWith("F") && !e.key.includes("Fn")) {
      const fKeyNum = parseInt(e.key.slice(1))
      if (fKeyNum >= 1 && fKeyNum <= 12) {
        e.preventDefault()
        switch (fKeyNum) {
          case 1: onPageChange("dashboard"); break
          case 2: onPageChange("sales"); break
          case 3: onPageChange("purchase"); break
          case 4: onPageChange("voucher"); break
          case 5: onPageChange("expense"); break
          case 6: onPageChange("inventory"); break
          case 7: onPageChange("party"); break
          case 8: onPageChange("ledger"); break
          case 9: onPageChange("balancesheet"); break
          case 10: onPageChange("profitloss"); break
          case 11: onPageChange("gstreports"); break
          case 12: onPageChange("settings"); break
        }
        return
      }
    }

    // Alt shortcuts
    if (e.altKey && !e.ctrlKey && !e.metaKey) {
      const key = e.key.toLowerCase()
      switch (key) {
        case "d":
          e.preventDefault()
          onPageChange("daybook")
          break
        case "c":
          e.preventDefault()
          onPageChange("cashbook")
          break
        case "b":
          e.preventDefault()
          onPageChange("bankbook")
          break
        case "t":
          e.preventDefault()
          onPageChange("trialbalance")
          break
        case "s":
          e.preventDefault()
          onPageChange("stockreport")
          break
        case "o":
          e.preventDefault()
          onPageChange("outstanding")
          break
        case "p":
          e.preventDefault()
          onPageChange("payroll")
          break
        case "x":
          e.preventDefault()
          onPageChange("compliance")
          break
        case "q":
          e.preventDefault()
          onLogout()
          break
      }
      return
    }

    // Ctrl shortcuts (only when not in input)
    if ((e.ctrlKey || e.metaKey) && !e.altKey) {
      const key = e.key.toLowerCase()
      switch (key) {
        case "s":
          e.preventDefault()
          onSave?.()
          break
        case "n":
          e.preventDefault()
          onNew?.()
          break
        case "p":
          e.preventDefault()
          onPrint?.()
          break
        case "f":
          if (!isInputField) {
            e.preventDefault()
            onOpenSearch?.()
          }
          break
        case "k":
          e.preventDefault()
          onOpenCalculator?.()
          break
        case "\\":
          e.preventDefault()
          onToggleSidebar()
          break
      }
      return
    }

    // ? key for help (not in input fields)
    if (e.key === "?" && !isInputField && !e.ctrlKey && !e.altKey && !e.metaKey && e.shiftKey) {
      e.preventDefault()
      setShowHelp(true)
    }

    // Escape to close help
    if (e.key === "Escape") {
      setShowHelp(false)
    }
  }, [onPageChange, onLogout, onToggleSidebar, onOpenSearch, onOpenCalculator, onPrint, onSave, onNew])

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [handleKeyDown])

  return (
    <Dialog open={showHelp} onOpenChange={setShowHelp}>
      <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Keyboard className="h-5 w-5" />
            Keyboard Shortcuts
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid md:grid-cols-2 gap-6 mt-4">
          {shortcuts.map((category) => (
            <div key={category.title} className="space-y-3">
              <h3 className="font-semibold text-amber-500 text-sm uppercase tracking-wider">
                {category.title}
              </h3>
              <div className="space-y-2">
                {category.shortcuts.map((shortcut, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between py-1.5 px-2 rounded hover:bg-muted/50 transition-colors"
                  >
                    <span className="text-sm text-muted-foreground">
                      {shortcut.description}
                    </span>
                    <div className="flex items-center gap-1">
                      {shortcut.keys.map((key, keyIdx) => (
                        <span key={keyIdx} className="flex items-center">
                          <kbd className="px-2 py-1 text-xs font-mono bg-slate-800 text-slate-300 rounded border border-slate-700">
                            {key}
                          </kbd>
                          {keyIdx < shortcut.keys.length - 1 && (
                            <span className="mx-1 text-slate-600">+</span>
                          )}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-border">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>Press <kbd className="px-1.5 py-0.5 bg-slate-800 rounded text-xs font-mono">?</kbd> anytime to show this help</span>
            <span>Press <kbd className="px-1.5 py-0.5 bg-slate-800 rounded text-xs font-mono">Esc</kbd> to close</span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// Shortcut indicator component for buttons
export function ShortcutBadge({ shortcut }: { shortcut: string }) {
  return (
    <Badge variant="outline" className="ml-auto text-[10px] font-mono px-1.5 py-0 h-5 bg-slate-800/50 border-slate-700 text-slate-400">
      {shortcut}
    </Badge>
  )
}
