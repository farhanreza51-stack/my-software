"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { FileSpreadsheet, TrendingUp, TrendingDown } from "lucide-react"
import type {
  InventoryItem,
  Invoice,
  Transaction,
  Party,
  CompanySettings,
} from "@/app/page"

interface BalanceSheetProps {
  inventory: InventoryItem[]
  invoices: Invoice[]
  transactions: Transaction[]
  parties: Party[]
  settings: CompanySettings
}

export function BalanceSheet({
  inventory,
  invoices,
  transactions,
  parties,
  settings,
}: BalanceSheetProps) {
  // Calculate Assets
  const inventoryValue = inventory.reduce(
    (a, b) => a + b.qty * b.purchasePrice,
    0
  )

  // Sundry Debtors (Receivables from customers)
  const sundryDebtors = invoices
    .filter((inv) => inv.type === "sale" && inv.status !== "paid")
    .reduce((a, b) => a + (b.total - b.paidAmount), 0)

  // Cash in hand (from cash transactions)
  const cashInHand = transactions
    .filter((txn) => txn.paymentMode === "cash")
    .reduce((a, b) => a + b.debit - b.credit, 0)

  // Bank balance
  const bankBalance = transactions
    .filter((txn) => txn.paymentMode === "bank")
    .reduce((a, b) => a + b.debit - b.credit, 0)

  // Calculate Liabilities
  // Sundry Creditors (Payables to suppliers)
  const sundryCreditors = invoices
    .filter((inv) => inv.type === "purchase" && inv.status !== "paid")
    .reduce((a, b) => a + (b.total - b.paidAmount), 0)

  // Calculate Profit/Loss
  const totalSales = invoices
    .filter((inv) => inv.type === "sale")
    .reduce((a, b) => a + b.total, 0)

  const totalPurchases = invoices
    .filter((inv) => inv.type === "purchase")
    .reduce((a, b) => a + b.total, 0)

  const grossProfit = totalSales - totalPurchases

  // Opening balances from parties
  const openingDebtors = parties
    .filter((p) => p.type === "customer" && p.balanceType === "debit")
    .reduce((a, b) => a + b.openingBalance, 0)

  const openingCreditors = parties
    .filter((p) => p.type === "supplier" && p.balanceType === "credit")
    .reduce((a, b) => a + b.openingBalance, 0)

  // Capital (calculated as balancing figure)
  const totalAssets =
    inventoryValue +
    sundryDebtors +
    openingDebtors +
    Math.max(cashInHand, 0) +
    Math.max(bankBalance, 0)
  const totalLiabilities = sundryCreditors + openingCreditors
  const capital = totalAssets - totalLiabilities - grossProfit

  const assets = [
    {
      category: "Current Assets",
      items: [
        { name: "Inventory (Closing Stock)", value: inventoryValue },
        { name: "Sundry Debtors", value: sundryDebtors + openingDebtors },
        { name: "Cash in Hand", value: Math.max(cashInHand, 0) },
        { name: "Bank Balance", value: Math.max(bankBalance, 0) },
      ],
    },
  ]

  const liabilities = [
    {
      category: "Capital & Reserves",
      items: [
        { name: "Capital Account", value: Math.max(capital, 0) },
        {
          name: grossProfit >= 0 ? "Net Profit" : "Net Loss",
          value: grossProfit,
          isProfit: true,
        },
      ],
    },
    {
      category: "Current Liabilities",
      items: [
        { name: "Sundry Creditors", value: sundryCreditors + openingCreditors },
      ],
    },
  ]

  const totalAssetsValue = assets.reduce(
    (a, cat) => a + cat.items.reduce((b, item) => b + item.value, 0),
    0
  )

  const totalLiabilitiesValue = liabilities.reduce(
    (a, cat) => a + cat.items.reduce((b, item) => b + Math.abs(item.value), 0),
    0
  )

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Balance Sheet</h2>
        <p className="text-muted-foreground">
          {settings.name} - As on {new Date().toLocaleDateString("en-IN")}
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Assets</p>
                <p className="text-xl font-bold">
                  ₹{totalAssetsValue.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                <TrendingDown className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">
                  Total Liabilities
                </p>
                <p className="text-xl font-bold">
                  ₹{totalLiabilitiesValue.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card
          className={grossProfit >= 0 ? "border-emerald-500" : "border-red-500"}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div
                className={`h-10 w-10 rounded-full flex items-center justify-center ${
                  grossProfit >= 0 ? "bg-emerald-500/10" : "bg-red-500/10"
                }`}
              >
                {grossProfit >= 0 ? (
                  <TrendingUp className="h-5 w-5 text-emerald-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
              </div>
              <div>
                <p className="text-sm text-muted-foreground">
                  {grossProfit >= 0 ? "Net Profit" : "Net Loss"}
                </p>
                <p
                  className={`text-xl font-bold ${
                    grossProfit >= 0 ? "text-emerald-600" : "text-red-600"
                  }`}
                >
                  ₹{Math.abs(grossProfit).toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Balance Sheet Table */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Liabilities Side */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5" />
              Liabilities & Capital
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Particulars</TableHead>
                  <TableHead className="text-right">Amount (₹)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {liabilities.map((category) => (
                  <>
                    <TableRow key={category.category} className="bg-muted/50">
                      <TableCell
                        colSpan={2}
                        className="font-semibold text-muted-foreground"
                      >
                        {category.category}
                      </TableCell>
                    </TableRow>
                    {category.items.map((item) => (
                      <TableRow key={item.name}>
                        <TableCell className="pl-6">{item.name}</TableCell>
                        <TableCell
                          className={`text-right font-medium ${
                            (item as { isProfit?: boolean }).isProfit && item.value < 0
                              ? "text-red-600"
                              : (item as { isProfit?: boolean }).isProfit
                              ? "text-emerald-600"
                              : ""
                          }`}
                        >
                          ₹{Math.abs(item.value).toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </>
                ))}
                <TableRow className="border-t-2">
                  <TableCell className="font-bold">Total</TableCell>
                  <TableCell className="text-right font-bold">
                    ₹{totalLiabilitiesValue.toLocaleString("en-IN")}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Assets Side */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5" />
              Assets
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Particulars</TableHead>
                  <TableHead className="text-right">Amount (₹)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assets.map((category) => (
                  <>
                    <TableRow key={category.category} className="bg-muted/50">
                      <TableCell
                        colSpan={2}
                        className="font-semibold text-muted-foreground"
                      >
                        {category.category}
                      </TableCell>
                    </TableRow>
                    {category.items.map((item) => (
                      <TableRow key={item.name}>
                        <TableCell className="pl-6">{item.name}</TableCell>
                        <TableCell className="text-right font-medium">
                          ₹{item.value.toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </>
                ))}
                <TableRow className="border-t-2">
                  <TableCell className="font-bold">Total</TableCell>
                  <TableCell className="text-right font-bold">
                    ₹{totalAssetsValue.toLocaleString("en-IN")}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Notes */}
      <Card>
        <CardContent className="pt-6">
          <p className="text-sm text-muted-foreground">
            <strong>Note:</strong> This is a simplified Balance Sheet for
            business management purposes. For statutory compliance and audit
            requirements, please consult a chartered accountant.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
