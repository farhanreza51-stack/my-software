"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { FileText } from "lucide-react"
import type { Invoice, Party, CompanySettings } from "@/app/page"

interface GSTReportsProps {
  invoices: Invoice[]
  parties: Party[]
  settings: CompanySettings
}

const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

export function GSTReports({ invoices, parties, settings }: GSTReportsProps) {
  const currentDate = new Date()
  const [selectedMonth, setSelectedMonth] = useState(
    String(currentDate.getMonth())
  )
  const [selectedYear, setSelectedYear] = useState(
    String(currentDate.getFullYear())
  )

  const filterByMonth = (date: string) => {
    const d = new Date(date)
    return (
      d.getMonth() === Number(selectedMonth) &&
      d.getFullYear() === Number(selectedYear)
    )
  }

  const salesInvoices = invoices.filter(
    (inv) => inv.type === "sale" && filterByMonth(inv.date)
  )
  const purchaseInvoices = invoices.filter(
    (inv) => inv.type === "purchase" && filterByMonth(inv.date)
  )

  // GSTR-1 (Outward Supplies / Sales)
  const gstr1Summary = {
    b2b: salesInvoices.filter((inv) => {
      const party = parties.find((p) => p.id === inv.partyId)
      return party?.gstin
    }),
    b2c: salesInvoices.filter((inv) => {
      const party = parties.find((p) => p.id === inv.partyId)
      return !party?.gstin
    }),
  }

  // GSTR-2 (Inward Supplies / Purchases)
  const gstr2Summary = purchaseInvoices

  // Calculate GST breakup
  const calculateGstBreakup = (inv: Invoice) => {
    const cgst = inv.gstAmount / 2
    const sgst = inv.gstAmount / 2
    return { cgst, sgst, igst: 0 }
  }

  const totalOutputGst = salesInvoices.reduce((a, b) => a + b.gstAmount, 0)
  const totalInputGst = purchaseInvoices.reduce((a, b) => a + b.gstAmount, 0)
  const gstPayable = totalOutputGst - totalInputGst

  const years = Array.from({ length: 5 }, (_, i) =>
    String(currentDate.getFullYear() - i)
  )

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">GST Reports</h2>
        <p className="text-muted-foreground">
          Generate GST compliant reports for filing
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Month:</span>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-36">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {months.map((month, index) => (
                    <SelectItem key={month} value={String(index)}>
                      {month}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Year:</span>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((year) => (
                    <SelectItem key={year} value={year}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* GST Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Output GST (Sales)</p>
            <p className="text-2xl font-bold text-emerald-600">
              ₹{totalOutputGst.toLocaleString("en-IN")}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {salesInvoices.length} invoices
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">
              Input GST (Purchases)
            </p>
            <p className="text-2xl font-bold text-blue-600">
              ₹{totalInputGst.toLocaleString("en-IN")}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {purchaseInvoices.length} invoices
            </p>
          </CardContent>
        </Card>
        <Card
          className={gstPayable >= 0 ? "border-amber-500" : "border-emerald-500"}
        >
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">
              {gstPayable >= 0 ? "GST Payable" : "ITC Carry Forward"}
            </p>
            <p
              className={`text-2xl font-bold ${
                gstPayable >= 0 ? "text-amber-600" : "text-emerald-600"
              }`}
            >
              ₹{Math.abs(gstPayable).toLocaleString("en-IN")}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Company GSTIN</p>
            <p className="text-lg font-mono font-bold">{settings.gstin}</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Reports */}
      <Tabs defaultValue="gstr1">
        <TabsList>
          <TabsTrigger value="gstr1">GSTR-1 (Sales)</TabsTrigger>
          <TabsTrigger value="gstr2">GSTR-2A (Purchases)</TabsTrigger>
          <TabsTrigger value="gstr3b">GSTR-3B Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="gstr1" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                B2B Invoices (Registered Parties)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {gstr1Summary.b2b.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No B2B invoices for this period.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Party</TableHead>
                      <TableHead>GSTIN</TableHead>
                      <TableHead className="text-right">Taxable</TableHead>
                      <TableHead className="text-right">CGST</TableHead>
                      <TableHead className="text-right">SGST</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gstr1Summary.b2b.map((inv) => {
                      const party = parties.find((p) => p.id === inv.partyId)
                      const gst = calculateGstBreakup(inv)
                      return (
                        <TableRow key={inv.id}>
                          <TableCell className="font-mono">
                            {inv.invoiceNo}
                          </TableCell>
                          <TableCell>{inv.date}</TableCell>
                          <TableCell>{inv.partyName}</TableCell>
                          <TableCell className="font-mono text-xs">
                            {party?.gstin}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{inv.subtotal.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{gst.cgst.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{gst.sgst.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            ₹{inv.total.toLocaleString("en-IN")}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                B2C Invoices (Unregistered Parties)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {gstr1Summary.b2c.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No B2C invoices for this period.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Party</TableHead>
                      <TableHead className="text-right">Taxable</TableHead>
                      <TableHead className="text-right">GST</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gstr1Summary.b2c.map((inv) => (
                      <TableRow key={inv.id}>
                        <TableCell className="font-mono">
                          {inv.invoiceNo}
                        </TableCell>
                        <TableCell>{inv.date}</TableCell>
                        <TableCell>{inv.partyName}</TableCell>
                        <TableCell className="text-right">
                          ₹{inv.subtotal.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹{inv.gstAmount.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right font-medium">
                          ₹{inv.total.toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gstr2" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Inward Supplies (Purchases)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {gstr2Summary.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No purchase invoices for this period.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Voucher No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Supplier</TableHead>
                      <TableHead>GSTIN</TableHead>
                      <TableHead className="text-right">Taxable</TableHead>
                      <TableHead className="text-right">CGST</TableHead>
                      <TableHead className="text-right">SGST</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gstr2Summary.map((inv) => {
                      const party = parties.find((p) => p.id === inv.partyId)
                      const gst = calculateGstBreakup(inv)
                      return (
                        <TableRow key={inv.id}>
                          <TableCell className="font-mono">
                            {inv.invoiceNo}
                          </TableCell>
                          <TableCell>{inv.date}</TableCell>
                          <TableCell>{inv.partyName}</TableCell>
                          <TableCell className="font-mono text-xs">
                            {party?.gstin || "-"}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{inv.subtotal.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{gst.cgst.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{gst.sgst.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            ₹{inv.total.toLocaleString("en-IN")}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gstr3b">
          <Card>
            <CardHeader>
              <CardTitle>GSTR-3B Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* 3.1 Outward Supplies */}
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold mb-4">
                    3.1 Details of Outward Supplies
                  </h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nature of Supplies</TableHead>
                        <TableHead className="text-right">Taxable Value</TableHead>
                        <TableHead className="text-right">CGST</TableHead>
                        <TableHead className="text-right">SGST</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>B2B (Taxable)</TableCell>
                        <TableCell className="text-right">
                          ₹
                          {gstr1Summary.b2b
                            .reduce((a, b) => a + b.subtotal, 0)
                            .toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹
                          {(
                            gstr1Summary.b2b.reduce((a, b) => a + b.gstAmount, 0) /
                            2
                          ).toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹
                          {(
                            gstr1Summary.b2b.reduce((a, b) => a + b.gstAmount, 0) /
                            2
                          ).toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>B2C (Taxable)</TableCell>
                        <TableCell className="text-right">
                          ₹
                          {gstr1Summary.b2c
                            .reduce((a, b) => a + b.subtotal, 0)
                            .toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹
                          {(
                            gstr1Summary.b2c.reduce((a, b) => a + b.gstAmount, 0) /
                            2
                          ).toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹
                          {(
                            gstr1Summary.b2c.reduce((a, b) => a + b.gstAmount, 0) /
                            2
                          ).toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                      <TableRow className="border-t-2 font-semibold">
                        <TableCell>Total</TableCell>
                        <TableCell className="text-right">
                          ₹
                          {salesInvoices
                            .reduce((a, b) => a + b.subtotal, 0)
                            .toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹{(totalOutputGst / 2).toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹{(totalOutputGst / 2).toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                {/* 4 Eligible ITC */}
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold mb-4">4. Eligible ITC</h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Details</TableHead>
                        <TableHead className="text-right">CGST</TableHead>
                        <TableHead className="text-right">SGST</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>Input Tax Credit</TableCell>
                        <TableCell className="text-right">
                          ₹{(totalInputGst / 2).toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹{(totalInputGst / 2).toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                {/* 6 Payment of Tax */}
                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold mb-4">6. Payment of Tax</h4>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="p-3 bg-muted/50 rounded">
                      <p className="text-sm text-muted-foreground">
                        Output Tax (CGST)
                      </p>
                      <p className="text-lg font-bold">
                        ₹{(totalOutputGst / 2).toLocaleString("en-IN")}
                      </p>
                    </div>
                    <div className="p-3 bg-muted/50 rounded">
                      <p className="text-sm text-muted-foreground">
                        Less: ITC (CGST)
                      </p>
                      <p className="text-lg font-bold text-emerald-600">
                        -₹{(totalInputGst / 2).toLocaleString("en-IN")}
                      </p>
                    </div>
                    <div
                      className={`p-3 rounded ${
                        gstPayable >= 0 ? "bg-amber-500/10" : "bg-emerald-500/10"
                      }`}
                    >
                      <p className="text-sm text-muted-foreground">
                        {gstPayable >= 0 ? "Tax Payable" : "ITC Balance"}
                      </p>
                      <p
                        className={`text-lg font-bold ${
                          gstPayable >= 0 ? "text-amber-600" : "text-emerald-600"
                        }`}
                      >
                        ₹{Math.abs(gstPayable / 2).toLocaleString("en-IN")} x 2
                      </p>
                    </div>
                  </div>
                </div>

                {/* Final Summary */}
                <div className="border-2 border-amber-500 rounded-lg p-4 bg-amber-500/5">
                  <h4 className="font-semibold mb-2">Total Tax Liability</h4>
                  <div className="flex items-center justify-between">
                    <span className="text-lg">
                      {gstPayable >= 0 ? "Amount Payable" : "ITC Carry Forward"}
                    </span>
                    <Badge
                      variant={gstPayable >= 0 ? "destructive" : "default"}
                      className="text-lg px-4 py-1"
                    >
                      ₹{Math.abs(gstPayable).toLocaleString("en-IN")}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
