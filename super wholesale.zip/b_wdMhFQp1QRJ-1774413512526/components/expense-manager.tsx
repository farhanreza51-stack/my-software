"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { 
  Receipt, 
  Plus, 
  Search, 
  Filter,
  TrendingUp,
  TrendingDown,
  Calendar,
  DollarSign,
  PieChart,
  BarChart3,
  Trash2,
  Edit
} from "lucide-react"
import type { Transaction } from "@/app/page"

type ExpenseCategory = {
  id: string
  name: string
}

type Expense = {
  id: string
  date: string
  category: string
  description: string
  amount: number
  paymentMode: "cash" | "bank"
  reference?: string
  vendor?: string
}

interface ExpenseManagerProps {
  transactions: Transaction[]
  expenseCategories: ExpenseCategory[]
  onAddTransaction: (txn: Omit<Transaction, "id" | "balance">) => void
}

export function ExpenseManager({ transactions, expenseCategories, onAddTransaction }: ExpenseManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterCategory, setFilterCategory] = useState<string>("all")
  const [filterMonth, setFilterMonth] = useState<string>("all")
  const [newExpense, setNewExpense] = useState<Partial<Expense>>({
    date: new Date().toISOString().split("T")[0],
    category: "",
    description: "",
    amount: 0,
    paymentMode: "cash",
    reference: "",
    vendor: ""
  })

  // Extract expenses from transactions
  const expenses = useMemo(() => {
    return transactions
      .filter(t => t.type === "expense")
      .map(t => ({
        id: t.id,
        date: t.date,
        category: t.reference || "Other",
        description: t.description,
        amount: t.credit,
        paymentMode: t.paymentMode,
        reference: t.voucherNo
      }))
  }, [transactions])

  // Filter expenses
  const filteredExpenses = useMemo(() => {
    return expenses.filter(exp => {
      const matchesSearch = 
        exp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        exp.category.toLowerCase().includes(searchTerm.toLowerCase())
      
      const matchesCategory = filterCategory === "all" || exp.category === filterCategory
      
      const matchesMonth = filterMonth === "all" || 
        exp.date.substring(0, 7) === filterMonth

      return matchesSearch && matchesCategory && matchesMonth
    })
  }, [expenses, searchTerm, filterCategory, filterMonth])

  // Calculate statistics
  const stats = useMemo(() => {
    const currentMonth = new Date().toISOString().substring(0, 7)
    const lastMonth = new Date(new Date().setMonth(new Date().getMonth() - 1)).toISOString().substring(0, 7)

    const currentMonthExpenses = expenses.filter(e => e.date.substring(0, 7) === currentMonth)
    const lastMonthExpenses = expenses.filter(e => e.date.substring(0, 7) === lastMonth)

    const totalCurrentMonth = currentMonthExpenses.reduce((a, b) => a + b.amount, 0)
    const totalLastMonth = lastMonthExpenses.reduce((a, b) => a + b.amount, 0)
    const percentChange = totalLastMonth > 0 
      ? ((totalCurrentMonth - totalLastMonth) / totalLastMonth) * 100 
      : 0

    // Category breakdown
    const categoryBreakdown: { [key: string]: number } = {}
    currentMonthExpenses.forEach(exp => {
      categoryBreakdown[exp.category] = (categoryBreakdown[exp.category] || 0) + exp.amount
    })

    return {
      totalCurrentMonth,
      totalLastMonth,
      percentChange,
      categoryBreakdown,
      totalExpenses: expenses.reduce((a, b) => a + b.amount, 0),
      averageExpense: expenses.length > 0 ? expenses.reduce((a, b) => a + b.amount, 0) / expenses.length : 0
    }
  }, [expenses])

  // Get unique months for filter
  const months = useMemo(() => {
    const monthSet = new Set(expenses.map(e => e.date.substring(0, 7)))
    return Array.from(monthSet).sort().reverse()
  }, [expenses])

  const handleAddExpense = () => {
    if (!newExpense.amount || !newExpense.description) {
      alert("Please fill in all required fields")
      return
    }

    const voucherNo = `EXP-${String(expenses.length + 1).padStart(5, "0")}`

    onAddTransaction({
      date: newExpense.date || new Date().toISOString().split("T")[0],
      type: "expense",
      voucherNo,
      description: `${newExpense.category}: ${newExpense.description}`,
      debit: 0,
      credit: newExpense.amount || 0,
      paymentMode: newExpense.paymentMode || "cash",
      reference: newExpense.category
    })

    setNewExpense({
      date: new Date().toISOString().split("T")[0],
      category: "",
      description: "",
      amount: 0,
      paymentMode: "cash",
      reference: "",
      vendor: ""
    })
    setIsDialogOpen(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Receipt className="h-6 w-6" />
          Expense Manager
        </h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Add Expense
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Add New Expense</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={newExpense.date}
                    onChange={(e) => setNewExpense({ ...newExpense, date: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select
                    value={newExpense.category}
                    onValueChange={(v) => setNewExpense({ ...newExpense, category: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {expenseCategories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  placeholder="Enter expense description"
                  value={newExpense.description}
                  onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Amount</Label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={newExpense.amount || ""}
                    onChange={(e) => setNewExpense({ ...newExpense, amount: parseFloat(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Payment Mode</Label>
                  <Select
                    value={newExpense.paymentMode}
                    onValueChange={(v) => setNewExpense({ ...newExpense, paymentMode: v as "cash" | "bank" })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="bank">Bank</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Vendor / Paid To</Label>
                <Input
                  placeholder="Vendor name"
                  value={newExpense.vendor}
                  onChange={(e) => setNewExpense({ ...newExpense, vendor: e.target.value })}
                />
              </div>
              <Button onClick={handleAddExpense} className="w-full">
                Save Expense
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">This Month</p>
                <p className="text-2xl font-bold">
                  {stats.totalCurrentMonth.toLocaleString("en-IN", {
                    style: "currency",
                    currency: "INR",
                    maximumFractionDigits: 0
                  })}
                </p>
              </div>
              <div className={`p-2 rounded-full ${stats.percentChange > 0 ? "bg-red-100" : "bg-green-100"}`}>
                {stats.percentChange > 0 ? (
                  <TrendingUp className="h-5 w-5 text-red-600" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-green-600" />
                )}
              </div>
            </div>
            <p className={`text-xs mt-2 ${stats.percentChange > 0 ? "text-red-600" : "text-green-600"}`}>
              {stats.percentChange > 0 ? "+" : ""}{stats.percentChange.toFixed(1)}% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Last Month</p>
                <p className="text-2xl font-bold">
                  {stats.totalLastMonth.toLocaleString("en-IN", {
                    style: "currency",
                    currency: "INR",
                    maximumFractionDigits: 0
                  })}
                </p>
              </div>
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Expenses</p>
                <p className="text-2xl font-bold">
                  {stats.totalExpenses.toLocaleString("en-IN", {
                    style: "currency",
                    currency: "INR",
                    maximumFractionDigits: 0
                  })}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Average Expense</p>
                <p className="text-2xl font-bold">
                  {stats.averageExpense.toLocaleString("en-IN", {
                    style: "currency",
                    currency: "INR",
                    maximumFractionDigits: 0
                  })}
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Expense List */}
        <div className="col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Expense List</CardTitle>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search expenses..."
                      className="pl-8 w-64"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-40">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {expenseCategories.map((cat) => (
                        <SelectItem key={cat.id} value={cat.name}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={filterMonth} onValueChange={setFilterMonth}>
                    <SelectTrigger className="w-40">
                      <Calendar className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Month" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Months</SelectItem>
                      {months.map((month) => (
                        <SelectItem key={month} value={month}>
                          {new Date(month + "-01").toLocaleDateString("en-IN", {
                            month: "long",
                            year: "numeric"
                          })}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="max-h-96 overflow-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Mode</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredExpenses.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No expenses found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredExpenses.map((expense) => (
                        <TableRow key={expense.id}>
                          <TableCell>{new Date(expense.date).toLocaleDateString("en-IN")}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{expense.category}</Badge>
                          </TableCell>
                          <TableCell className="max-w-48 truncate">{expense.description}</TableCell>
                          <TableCell>
                            <Badge variant={expense.paymentMode === "cash" ? "secondary" : "default"}>
                              {expense.paymentMode}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            {expense.amount.toLocaleString("en-IN", {
                              style: "currency",
                              currency: "INR"
                            })}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
              <div className="flex justify-between items-center mt-4 pt-4 border-t">
                <span className="text-sm text-muted-foreground">
                  Showing {filteredExpenses.length} of {expenses.length} expenses
                </span>
                <span className="font-semibold">
                  Total: {filteredExpenses.reduce((a, b) => a + b.amount, 0).toLocaleString("en-IN", {
                    style: "currency",
                    currency: "INR"
                  })}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Category Breakdown */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm">
                <PieChart className="h-4 w-4" />
                Category Breakdown (This Month)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(stats.categoryBreakdown).length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No expenses this month
                </p>
              ) : (
                Object.entries(stats.categoryBreakdown)
                  .sort((a, b) => b[1] - a[1])
                  .map(([category, amount]) => {
                    const percentage = (amount / stats.totalCurrentMonth) * 100
                    return (
                      <div key={category} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>{category}</span>
                          <span className="font-medium">
                            {amount.toLocaleString("en-IN", {
                              style: "currency",
                              currency: "INR",
                              maximumFractionDigits: 0
                            })}
                          </span>
                        </div>
                        <div className="h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full transition-all"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <p className="text-xs text-muted-foreground text-right">
                          {percentage.toFixed(1)}%
                        </p>
                      </div>
                    )
                  })
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Quick Add</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {expenseCategories.slice(0, 5).map((cat) => (
                <Button
                  key={cat.id}
                  variant="outline"
                  className="w-full justify-start"
                  onClick={() => {
                    setNewExpense({ ...newExpense, category: cat.name })
                    setIsDialogOpen(true)
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  {cat.name}
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
