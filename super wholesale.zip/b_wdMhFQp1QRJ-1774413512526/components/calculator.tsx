"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Calculator as CalcIcon, Delete, Equal, Divide, X, Minus, Plus, Percent } from "lucide-react"

interface CalculatorProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function Calculator({ open, onOpenChange }: CalculatorProps) {
  const [display, setDisplay] = useState("0")
  const [previousValue, setPreviousValue] = useState<number | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)
  const [history, setHistory] = useState<string[]>([])
  const displayRef = useRef<HTMLDivElement>(null)

  const clear = useCallback(() => {
    setDisplay("0")
    setPreviousValue(null)
    setOperation(null)
    setWaitingForOperand(false)
  }, [])

  const clearAll = useCallback(() => {
    clear()
    setHistory([])
  }, [clear])

  const inputDigit = useCallback((digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit)
      setWaitingForOperand(false)
    } else {
      setDisplay(display === "0" ? digit : display + digit)
    }
  }, [display, waitingForOperand])

  const inputDecimal = useCallback(() => {
    if (waitingForOperand) {
      setDisplay("0.")
      setWaitingForOperand(false)
    } else if (!display.includes(".")) {
      setDisplay(display + ".")
    }
  }, [display, waitingForOperand])

  const backspace = useCallback(() => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1))
    } else {
      setDisplay("0")
    }
  }, [display])

  const toggleSign = useCallback(() => {
    const value = parseFloat(display)
    if (value !== 0) {
      setDisplay(String(-value))
    }
  }, [display])

  const inputPercent = useCallback(() => {
    const value = parseFloat(display)
    setDisplay(String(value / 100))
  }, [display])

  const performOperation = useCallback((nextOperation: string) => {
    const inputValue = parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operation) {
      const currentValue = previousValue
      let result: number

      switch (operation) {
        case "+":
          result = currentValue + inputValue
          break
        case "-":
          result = currentValue - inputValue
          break
        case "*":
          result = currentValue * inputValue
          break
        case "/":
          result = currentValue / inputValue
          break
        default:
          result = inputValue
      }

      setHistory(prev => [...prev, `${currentValue} ${operation} ${inputValue} = ${result}`].slice(-5))
      setDisplay(String(result))
      setPreviousValue(result)
    }

    setWaitingForOperand(true)
    setOperation(nextOperation)
  }, [display, operation, previousValue])

  const calculate = useCallback(() => {
    if (operation && previousValue !== null) {
      const inputValue = parseFloat(display)
      let result: number

      switch (operation) {
        case "+":
          result = previousValue + inputValue
          break
        case "-":
          result = previousValue - inputValue
          break
        case "*":
          result = previousValue * inputValue
          break
        case "/":
          result = previousValue / inputValue
          break
        default:
          result = inputValue
      }

      setHistory(prev => [...prev, `${previousValue} ${operation} ${inputValue} = ${result}`].slice(-5))
      setDisplay(String(result))
      setPreviousValue(null)
      setOperation(null)
      setWaitingForOperand(true)
    }
  }, [display, operation, previousValue])

  // Keyboard support
  useEffect(() => {
    if (!open) return

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= "0" && e.key <= "9") {
        inputDigit(e.key)
      } else if (e.key === ".") {
        inputDecimal()
      } else if (e.key === "Backspace") {
        backspace()
      } else if (e.key === "Escape") {
        clear()
      } else if (e.key === "Enter" || e.key === "=") {
        calculate()
      } else if (e.key === "+") {
        performOperation("+")
      } else if (e.key === "-") {
        performOperation("-")
      } else if (e.key === "*") {
        performOperation("*")
      } else if (e.key === "/") {
        e.preventDefault()
        performOperation("/")
      } else if (e.key === "%") {
        inputPercent()
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [open, inputDigit, inputDecimal, backspace, clear, calculate, performOperation, inputPercent])

  const buttons = [
    { label: "C", action: clear, className: "bg-red-500/10 text-red-400 hover:bg-red-500/20" },
    { label: "AC", action: clearAll, className: "bg-red-500/10 text-red-400 hover:bg-red-500/20" },
    { label: "%", action: inputPercent, className: "bg-slate-700" },
    { label: "/", action: () => performOperation("/"), className: "bg-amber-500/20 text-amber-500", icon: Divide },
    
    { label: "7", action: () => inputDigit("7") },
    { label: "8", action: () => inputDigit("8") },
    { label: "9", action: () => inputDigit("9") },
    { label: "*", action: () => performOperation("*"), className: "bg-amber-500/20 text-amber-500", icon: X },
    
    { label: "4", action: () => inputDigit("4") },
    { label: "5", action: () => inputDigit("5") },
    { label: "6", action: () => inputDigit("6") },
    { label: "-", action: () => performOperation("-"), className: "bg-amber-500/20 text-amber-500", icon: Minus },
    
    { label: "1", action: () => inputDigit("1") },
    { label: "2", action: () => inputDigit("2") },
    { label: "3", action: () => inputDigit("3") },
    { label: "+", action: () => performOperation("+"), className: "bg-amber-500/20 text-amber-500", icon: Plus },
    
    { label: "±", action: toggleSign },
    { label: "0", action: () => inputDigit("0") },
    { label: ".", action: inputDecimal },
    { label: "=", action: calculate, className: "bg-amber-500 text-slate-900 hover:bg-amber-400", icon: Equal },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[320px] p-0 overflow-hidden">
        <DialogHeader className="p-4 pb-2">
          <DialogTitle className="flex items-center gap-2">
            <CalcIcon className="h-5 w-5" />
            Calculator
          </DialogTitle>
        </DialogHeader>

        <div className="p-4 pt-0">
          {/* History */}
          {history.length > 0 && (
            <div className="mb-2 p-2 bg-slate-800/50 rounded text-xs text-slate-500 max-h-16 overflow-y-auto">
              {history.map((h, i) => (
                <div key={i}>{h}</div>
              ))}
            </div>
          )}

          {/* Display */}
          <div
            ref={displayRef}
            className="bg-slate-800 rounded-lg p-4 mb-4 text-right"
          >
            <div className="text-xs text-slate-500 h-4">
              {previousValue !== null && operation && `${previousValue} ${operation}`}
            </div>
            <div className="text-3xl font-mono text-white truncate">
              {parseFloat(display).toLocaleString("en-IN", { maximumFractionDigits: 10 })}
            </div>
          </div>

          {/* Buttons */}
          <div className="grid grid-cols-4 gap-2">
            {buttons.map((btn, idx) => (
              <Button
                key={idx}
                variant="ghost"
                onClick={btn.action}
                className={`h-12 text-lg font-medium ${btn.className || "bg-slate-800 hover:bg-slate-700"}`}
              >
                {btn.icon ? <btn.icon className="h-4 w-4" /> : btn.label}
              </Button>
            ))}
          </div>

          {/* Backspace */}
          <Button
            variant="ghost"
            onClick={backspace}
            className="w-full mt-2 bg-slate-800 hover:bg-slate-700"
          >
            <Delete className="h-4 w-4 mr-2" />
            Backspace
          </Button>

          <div className="mt-3 text-xs text-slate-600 text-center">
            Use keyboard for quick input
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
