"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  LayoutDashboard,
  Package,
  Receipt,
  ShoppingCart,
  Users,
  BookOpen,
  Calendar,
  Wallet,
  Landmark,
  CreditCard,
  IndianRupee,
  Scale,
  FileSpreadsheet,
  TrendingUp,
  FileText,
  BarChart3,
  AlertCircle,
  Settings,
  ArrowRight,
} from "lucide-react"
import type { PageType, InventoryItem, Party, Invoice } from "@/app/page"

interface GlobalSearchProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onPageChange: (page: PageType) => void
  inventory: InventoryItem[]
  parties: Party[]
  invoices: Invoice[]
}

type SearchResult = {
  type: "page" | "inventory" | "party" | "invoice"
  title: string
  subtitle?: string
  icon: React.ComponentType<{ className?: string }>
  action: () => void
  shortcut?: string
}

const pages: { key: PageType; label: string; icon: React.ComponentType<{ className?: string }>; shortcut: string }[] = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, shortcut: "F1" },
  { key: "sales", label: "Sales / Billing", icon: Receipt, shortcut: "F2" },
  { key: "purchase", label: "Purchase Entry", icon: ShoppingCart, shortcut: "F3" },
  { key: "voucher", label: "Voucher Entry", icon: CreditCard, shortcut: "F4" },
  { key: "expense", label: "Expense Manager", icon: IndianRupee, shortcut: "F5" },
  { key: "inventory", label: "Inventory Master", icon: Package, shortcut: "F6" },
  { key: "party", label: "Party Master", icon: Users, shortcut: "F7" },
  { key: "ledger", label: "Party Ledger", icon: BookOpen, shortcut: "F8" },
  { key: "daybook", label: "Day Book", icon: Calendar, shortcut: "Alt+D" },
  { key: "cashbook", label: "Cash Book", icon: Wallet, shortcut: "Alt+C" },
  { key: "bankbook", label: "Bank Book", icon: Landmark, shortcut: "Alt+B" },
  { key: "trialbalance", label: "Trial Balance", icon: Scale, shortcut: "Alt+T" },
  { key: "balancesheet", label: "Balance Sheet", icon: FileSpreadsheet, shortcut: "F9" },
  { key: "profitloss", label: "Profit & Loss", icon: TrendingUp, shortcut: "F10" },
  { key: "gstreports", label: "GST Reports", icon: FileText, shortcut: "F11" },
  { key: "stockreport", label: "Stock Report", icon: BarChart3, shortcut: "Alt+S" },
  { key: "outstanding", label: "Outstanding Report", icon: AlertCircle, shortcut: "Alt+O" },
  { key: "settings", label: "Settings", icon: Settings, shortcut: "F12" },
]

export function GlobalSearch({
  open,
  onOpenChange,
  onPageChange,
  inventory,
  parties,
  invoices,
}: GlobalSearchProps) {
  const [query, setQuery] = useState("")
  const [selectedIndex, setSelectedIndex] = useState(0)

  // Reset state when dialog opens
  useEffect(() => {
    if (open) {
      setQuery("")
      setSelectedIndex(0)
    }
  }, [open])

  const results = useMemo<SearchResult[]>(() => {
    const q = query.toLowerCase().trim()
    if (!q) {
      // Show popular pages when no query
      return pages.slice(0, 8).map(p => ({
        type: "page" as const,
        title: p.label,
        icon: p.icon,
        action: () => { onPageChange(p.key); onOpenChange(false) },
        shortcut: p.shortcut,
      }))
    }

    const pageResults: SearchResult[] = pages
      .filter(p => p.label.toLowerCase().includes(q) || p.key.includes(q))
      .map(p => ({
        type: "page" as const,
        title: p.label,
        icon: p.icon,
        action: () => { onPageChange(p.key); onOpenChange(false) },
        shortcut: p.shortcut,
      }))

    const inventoryResults: SearchResult[] = inventory
      .filter(i => i.name.toLowerCase().includes(q) || i.hsn.toLowerCase().includes(q))
      .slice(0, 5)
      .map(i => ({
        type: "inventory" as const,
        title: i.name,
        subtitle: `Stock: ${i.qty} ${i.unit} | Price: Rs.${i.price}`,
        icon: Package,
        action: () => { onPageChange("inventory"); onOpenChange(false) },
      }))

    const partyResults: SearchResult[] = parties
      .filter(p => p.name.toLowerCase().includes(q) || p.phone.includes(q))
      .slice(0, 5)
      .map(p => ({
        type: "party" as const,
        title: p.name,
        subtitle: `${p.type === "customer" ? "Customer" : "Supplier"} | ${p.phone}`,
        icon: Users,
        action: () => { onPageChange("party"); onOpenChange(false) },
      }))

    const invoiceResults: SearchResult[] = invoices
      .filter(i => i.invoiceNo.toLowerCase().includes(q) || i.partyName.toLowerCase().includes(q))
      .slice(0, 5)
      .map(i => ({
        type: "invoice" as const,
        title: i.invoiceNo,
        subtitle: `${i.partyName} | Rs.${i.total.toLocaleString("en-IN")}`,
        icon: Receipt,
        action: () => { onPageChange(i.type === "sale" ? "sales" : "purchase"); onOpenChange(false) },
      }))

    return [...pageResults, ...inventoryResults, ...partyResults, ...invoiceResults].slice(0, 12)
  }, [query, inventory, parties, invoices, onPageChange, onOpenChange])

  // Keyboard navigation
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault()
      setSelectedIndex(i => Math.min(i + 1, results.length - 1))
    } else if (e.key === "ArrowUp") {
      e.preventDefault()
      setSelectedIndex(i => Math.max(i - 1, 0))
    } else if (e.key === "Enter" && results[selectedIndex]) {
      e.preventDefault()
      results[selectedIndex].action()
    }
  }, [results, selectedIndex])

  // Reset selection when results change
  useEffect(() => {
    setSelectedIndex(0)
  }, [results.length])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] p-0 gap-0 overflow-hidden">
        <div className="flex items-center border-b border-border px-4">
          <Search className="h-5 w-5 text-muted-foreground shrink-0" />
          <Input
            placeholder="Search pages, inventory, parties, invoices..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 h-14 text-base"
            autoFocus
          />
          <kbd className="hidden sm:inline-flex px-2 py-1 text-xs font-mono bg-slate-800 text-slate-400 rounded">
            Esc
          </kbd>
        </div>

        <div className="max-h-[400px] overflow-y-auto">
          {results.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              No results found for "{query}"
            </div>
          ) : (
            <div className="p-2">
              {!query && (
                <div className="px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Quick Navigation
                </div>
              )}
              {results.map((result, index) => (
                <button
                  key={`${result.type}-${result.title}-${index}`}
                  onClick={result.action}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-colors ${
                    selectedIndex === index
                      ? "bg-amber-500/10 text-amber-500"
                      : "hover:bg-muted/50"
                  }`}
                >
                  <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 ${
                    selectedIndex === index ? "bg-amber-500/20" : "bg-muted"
                  }`}>
                    <result.icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{result.title}</div>
                    {result.subtitle && (
                      <div className="text-xs text-muted-foreground truncate">
                        {result.subtitle}
                      </div>
                    )}
                  </div>
                  {result.shortcut && (
                    <kbd className="hidden sm:inline-flex px-2 py-1 text-[10px] font-mono bg-slate-800 text-slate-500 rounded">
                      {result.shortcut}
                    </kbd>
                  )}
                  {selectedIndex === index && (
                    <ArrowRight className="h-4 w-4 shrink-0" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between px-4 py-2 border-t border-border bg-muted/30 text-xs text-muted-foreground">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-slate-800 rounded text-[10px] font-mono">↑↓</kbd>
              Navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-slate-800 rounded text-[10px] font-mono">Enter</kbd>
              Select
            </span>
          </div>
          <span>Ctrl+F to search</span>
        </div>
      </DialogContent>
    </Dialog>
  )
}
