"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { 
  Building2, 
  Lock, 
  User, 
  Eye, 
  EyeOff,
  BarChart3,
  Package,
  Users,
  FileText,
  Keyboard,
  IndianRupee,
  TrendingUp,
  Shield,
  Zap
} from "lucide-react"

interface LoginScreenProps {
  onLogin: (username: string) => void
}

export type UserCredentials = {
  username: string
  password: string
}

const DEFAULT_CREDENTIALS: UserCredentials = {
  username: "admin",
  password: "admin123"
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [credentials, setCredentials] = useState<UserCredentials>(DEFAULT_CREDENTIALS)

  // Load saved credentials from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("erp_user_credentials")
    if (saved) {
      try {
        setCredentials(JSON.parse(saved))
      } catch {
        setCredentials(DEFAULT_CREDENTIALS)
      }
    }
  }, [])

  const handleLogin = useCallback(async () => {
    if (!username.trim() || !password.trim()) {
      setError("Please enter username and password")
      return
    }

    setIsLoading(true)
    setError("")
    
    // Simulate loading
    await new Promise(resolve => setTimeout(resolve, 300))
    
    if (username === credentials.username && password === credentials.password) {
      onLogin(username)
    } else {
      setError("Invalid username or password")
    }
    setIsLoading(false)
  }, [username, password, credentials, onLogin])

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleLogin()
    }
  }, [handleLogin])

  // Global keyboard shortcuts
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // Alt+L to focus username
      if (e.altKey && e.key === "l") {
        e.preventDefault()
        document.getElementById("login-username")?.focus()
      }
    }

    window.addEventListener("keydown", handleGlobalKeyDown)
    return () => window.removeEventListener("keydown", handleGlobalKeyDown)
  }, [])

  const features = [
    { icon: BarChart3, label: "Financial Reports", desc: "Balance Sheet, P&L, Trial Balance" },
    { icon: Package, label: "Inventory Management", desc: "Stock items, HSN codes, GST rates" },
    { icon: Users, label: "Party Master", desc: "Customers, Suppliers, Ledgers" },
    { icon: FileText, label: "GST Compliant", desc: "GSTR-1, 2A, 3B ready" },
    { icon: IndianRupee, label: "Voucher Entry", desc: "Receipt, Payment, Journal, Contra" },
    { icon: TrendingUp, label: "Day Book", desc: "Cash Book, Bank Book" },
  ]

  const stats = [
    { value: "10,000+", label: "Businesses" },
    { value: "50L+", label: "Invoices" },
    { value: "99.9%", label: "Uptime" },
  ]

  return (
    <div className="min-h-screen flex">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-[55%] bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800 p-12 flex-col justify-between relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 -left-20 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-20 -right-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/5 rounded-full blur-3xl" />
          
          {/* Grid Pattern */}
          <div className="absolute inset-0 opacity-[0.02]" style={{
            backgroundImage: 'linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)',
            backgroundSize: '60px 60px'
          }} />
        </div>
        
        {/* Header */}
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-2">
            <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Building2 className="h-8 w-8 text-slate-900" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white tracking-tight">
                Vyapar<span className="text-amber-400">ERP</span>
              </h1>
              <p className="text-slate-400 text-sm font-medium">Smart Business Management</p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="relative z-10 space-y-10">
          <div>
            <h2 className="text-5xl font-bold text-white leading-tight tracking-tight">
              Powerful
              <br />
              <span className="bg-gradient-to-r from-amber-400 to-amber-500 bg-clip-text text-transparent">
                Business Accounting
              </span>
            </h2>
            <p className="mt-6 text-slate-400 text-lg max-w-lg leading-relaxed">
              Tally-like ERP with complete accounting, inventory, GST compliance, 
              payroll, and financial management. Keyboard-driven interface for 
              maximum productivity. Built for Indian businesses.
            </p>
          </div>

          {/* Feature Grid */}
          <div className="grid grid-cols-3 gap-3">
            {features.map((feature, idx) => (
              <div
                key={idx}
                className="group p-4 rounded-xl bg-slate-800/40 border border-slate-700/50 hover:border-amber-500/30 hover:bg-slate-800/60 transition-all duration-300"
              >
                <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-amber-500/20 to-amber-600/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <feature.icon className="h-5 w-5 text-amber-400" />
                </div>
                <span className="text-white font-semibold text-sm block">{feature.label}</span>
                <span className="text-slate-500 text-xs">{feature.desc}</span>
              </div>
            ))}
          </div>

          {/* Stats */}
          <div className="flex gap-8 pt-4">
            {stats.map((stat, idx) => (
              <div key={idx} className="text-center">
                <div className="text-2xl font-bold text-amber-400">{stat.value}</div>
                <div className="text-xs text-slate-500 uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Keyboard Shortcut Hint */}
          <div className="flex items-center gap-3 text-slate-500 text-sm">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/50 border border-slate-700/50">
              <Keyboard className="h-4 w-4" />
              <span>Press <kbd className="px-1.5 py-0.5 bg-slate-700 rounded text-xs font-mono text-amber-400">Alt+L</kbd> to focus login</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="relative z-10 flex items-center justify-between">
          <p className="text-slate-600 text-sm flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Trusted by 10,000+ businesses across India
          </p>
          <div className="flex items-center gap-2 text-slate-600 text-sm">
            <Zap className="h-4 w-4 text-amber-500" />
            <span>Made in India</span>
          </div>
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-slate-950 relative">
        {/* Subtle gradient background */}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-slate-950 to-slate-900" />
        
        <Card className="w-full max-w-md bg-slate-900/80 backdrop-blur-sm border-slate-800 shadow-2xl relative z-10">
          <CardHeader className="space-y-4 pb-2">
            {/* Mobile Logo */}
            <div className="lg:hidden flex items-center justify-center gap-3 mb-4">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg">
                <Building2 className="h-7 w-7 text-slate-900" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">
                  Vyapar<span className="text-amber-400">ERP</span>
                </h1>
                <p className="text-slate-400 text-xs">Smart Business Management</p>
              </div>
            </div>

            <div className="text-center lg:text-left">
              <h2 className="text-2xl font-bold text-white">Welcome Back</h2>
              <p className="text-slate-400 mt-1">
                Sign in to access your business dashboard
              </p>
            </div>
          </CardHeader>

          <CardContent className="space-y-5 pt-4">
            <div className="space-y-2">
              <Label className="text-slate-300 text-sm font-medium">Username</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                <Input
                  id="login-username"
                  placeholder="Enter username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onKeyDown={handleKeyDown}
                  autoFocus
                  className="pl-10 h-11 bg-slate-800/80 border-slate-700 text-white placeholder:text-slate-500 focus:border-amber-500 focus:ring-amber-500/20 transition-colors"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-slate-300 text-sm font-medium">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="pl-10 pr-10 h-11 bg-slate-800/80 border-slate-700 text-white placeholder:text-slate-500 focus:border-amber-500 focus:ring-amber-500/20 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-red-900/20 border border-red-900/50 animate-in slide-in-from-top-2">
                <p className="text-sm text-red-400 text-center">{error}</p>
              </div>
            )}

            <Button
              onClick={handleLogin}
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-900 font-semibold h-12 text-base shadow-lg shadow-amber-500/20 transition-all hover:shadow-amber-500/30"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                      fill="none"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                  Signing in...
                </span>
              ) : (
                "Sign In"
              )}
            </Button>

            <div className="pt-4 border-t border-slate-800">
              <div className="text-xs text-slate-500 text-center space-y-1.5">
                <p className="flex items-center justify-center gap-2">
                  <span className="h-1 w-1 rounded-full bg-amber-500" />
                  First time? Default: admin / admin123
                </p>
                <p className="text-slate-600">Change password in Settings after login</p>
              </div>
            </div>

            <div className="flex items-center justify-center gap-2 pt-2">
              <div className="h-6 w-6 rounded-full bg-amber-500/10 flex items-center justify-center">
                <Shield className="h-3 w-3 text-amber-500" />
              </div>
              <p className="text-xs text-slate-600">
                VyaparERP v2.0 | Secure & Fast
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
