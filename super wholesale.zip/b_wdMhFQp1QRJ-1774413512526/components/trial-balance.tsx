"use client"

import { useMemo, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { 
  FileText, 
  Printer, 
  Download, 
  Calendar,
  CheckCircle2,
  XCircle,
  Scale
} from "lucide-react"
import type { Party, Invoice, Transaction, InventoryItem, CompanySettings } from "@/app/page"

interface TrialBalanceProps {
  parties: Party[]
  invoices: Invoice[]
  transactions: Transaction[]
  inventory: InventoryItem[]
  settings: CompanySettings
}

type AccountEntry = {
  name: string
  group: string
  debit: number
  credit: number
}

export function TrialBalance({ parties, invoices, transactions, inventory, settings }: TrialBalanceProps) {
  const [fromDate, setFromDate] = useState(settings.financialYearStart)
  const [toDate, setToDate] = useState(new Date().toISOString().split("T")[0])

  const trialBalanceData = useMemo(() => {
    const accounts: AccountEntry[] = []

    // Filter transactions by date
    const filteredTxns = transactions.filter(t => t.date >= fromDate && t.date <= toDate)
    const filteredInvoices = invoices.filter(i => i.date >= fromDate && i.date <= toDate)

    // Cash Account
    const cashReceipts = filteredTxns
      .filter(t => t.paymentMode === "cash" && t.debit > 0)
      .reduce((a, b) => a + b.debit, 0)
    const cashPayments = filteredTxns
      .filter(t => t.paymentMode === "cash" && t.credit > 0)
      .reduce((a, b) => a + b.credit, 0)
    
    if (cashReceipts > 0 || cashPayments > 0) {
      accounts.push({
        name: "Cash Account",
        group: "Assets",
        debit: cashReceipts,
        credit: cashPayments
      })
    }

    // Bank Account
    const bankReceipts = filteredTxns
      .filter(t => t.paymentMode === "bank" && t.debit > 0)
      .reduce((a, b) => a + b.debit, 0)
    const bankPayments = filteredTxns
      .filter(t => t.paymentMode === "bank" && t.credit > 0)
      .reduce((a, b) => a + b.credit, 0)
    
    if (bankReceipts > 0 || bankPayments > 0) {
      accounts.push({
        name: "Bank Account",
        group: "Assets",
        debit: bankReceipts,
        credit: bankPayments
      })
    }

    // Inventory / Stock
    const inventoryValue = inventory.reduce((a, b) => a + (b.qty * b.purchasePrice), 0)
    if (inventoryValue > 0) {
      accounts.push({
        name: "Inventory / Stock",
        group: "Assets",
        debit: inventoryValue,
        credit: 0
      })
    }

    // Sundry Debtors (Customers who owe money)
    const salesInvoices = filteredInvoices.filter(i => i.type === "sale")
    const totalReceivables = salesInvoices.reduce((a, b) => a + (b.total - b.paidAmount), 0)
    if (totalReceivables > 0) {
      accounts.push({
        name: "Sundry Debtors",
        group: "Assets",
        debit: totalReceivables,
        credit: 0
      })
    }

    // Sundry Creditors (Suppliers we owe money to)
    const purchaseInvoices = filteredInvoices.filter(i => i.type === "purchase")
    const totalPayables = purchaseInvoices.reduce((a, b) => a + (b.total - b.paidAmount), 0)
    if (totalPayables > 0) {
      accounts.push({
        name: "Sundry Creditors",
        group: "Liabilities",
        debit: 0,
        credit: totalPayables
      })
    }

    // Sales Account
    const totalSales = salesInvoices.reduce((a, b) => a + b.subtotal, 0)
    if (totalSales > 0) {
      accounts.push({
        name: "Sales Account",
        group: "Income",
        debit: 0,
        credit: totalSales
      })
    }

    // Purchase Account
    const totalPurchases = purchaseInvoices.reduce((a, b) => a + b.subtotal, 0)
    if (totalPurchases > 0) {
      accounts.push({
        name: "Purchase Account",
        group: "Expenses",
        debit: totalPurchases,
        credit: 0
      })
    }

    // GST Input (Tax Credit)
    const gstInput = purchaseInvoices.reduce((a, b) => a + b.gstAmount, 0)
    if (gstInput > 0) {
      accounts.push({
        name: "GST Input Credit",
        group: "Assets",
        debit: gstInput,
        credit: 0
      })
    }

    // GST Output (Tax Liability)
    const gstOutput = salesInvoices.reduce((a, b) => a + b.gstAmount, 0)
    if (gstOutput > 0) {
      accounts.push({
        name: "GST Output Liability",
        group: "Liabilities",
        debit: 0,
        credit: gstOutput
      })
    }

    // Expenses
    const expenses = filteredTxns.filter(t => t.type === "expense")
    const expensesByCategory: { [key: string]: number } = {}
    expenses.forEach(exp => {
      const category = exp.reference || "Other Expenses"
      expensesByCategory[category] = (expensesByCategory[category] || 0) + exp.credit
    })

    Object.entries(expensesByCategory).forEach(([category, amount]) => {
      accounts.push({
        name: category,
        group: "Expenses",
        debit: amount,
        credit: 0
      })
    })

    // Discount Given
    const discountGiven = salesInvoices.reduce((a, b) => a + b.discount, 0)
    if (discountGiven > 0) {
      accounts.push({
        name: "Discount Allowed",
        group: "Expenses",
        debit: discountGiven,
        credit: 0
      })
    }

    // Discount Received
    const discountReceived = purchaseInvoices.reduce((a, b) => a + b.discount, 0)
    if (discountReceived > 0) {
      accounts.push({
        name: "Discount Received",
        group: "Income",
        debit: 0,
        credit: discountReceived
      })
    }

    // Capital Account (balancing figure)
    const totalDebit = accounts.reduce((a, b) => a + b.debit, 0)
    const totalCredit = accounts.reduce((a, b) => a + b.credit, 0)
    const difference = totalCredit - totalDebit

    if (difference !== 0) {
      accounts.push({
        name: "Capital Account",
        group: "Capital",
        debit: difference < 0 ? Math.abs(difference) : 0,
        credit: difference > 0 ? difference : 0
      })
    }

    return accounts.sort((a, b) => {
      const groupOrder = ["Assets", "Liabilities", "Capital", "Income", "Expenses"]
      return groupOrder.indexOf(a.group) - groupOrder.indexOf(b.group)
    })
  }, [parties, invoices, transactions, inventory, fromDate, toDate])

  const totalDebit = trialBalanceData.reduce((a, b) => a + b.debit, 0)
  const totalCredit = trialBalanceData.reduce((a, b) => a + b.credit, 0)
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01

  const handlePrint = () => {
    window.print()
  }

  const groupedData = useMemo(() => {
    const groups: { [key: string]: AccountEntry[] } = {}
    trialBalanceData.forEach(account => {
      if (!groups[account.group]) {
        groups[account.group] = []
      }
      groups[account.group].push(account)
    })
    return groups
  }, [trialBalanceData])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between no-print">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Scale className="h-6 w-6" />
          Trial Balance
        </h1>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={handlePrint}>
            <Printer className="h-4 w-4" />
            Print
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Date Range Filter */}
      <Card className="no-print">
        <CardContent className="pt-6">
          <div className="flex items-end gap-4">
            <div className="space-y-2">
              <Label>From Date</Label>
              <Input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>To Date</Label>
              <Input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
              />
            </div>
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              This Month
            </Button>
            <Button variant="outline">
              This Quarter
            </Button>
            <Button variant="outline">
              This Year
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Balance Status */}
      <Card className={isBalanced ? "border-green-500" : "border-red-500"}>
        <CardContent className="py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {isBalanced ? (
                <>
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                  <span className="font-medium text-green-600">Trial Balance is Balanced</span>
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-red-500" />
                  <span className="font-medium text-red-600">Trial Balance has Discrepancy</span>
                </>
              )}
            </div>
            <div className="flex gap-8">
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Total Debit</p>
                <p className="text-lg font-bold">
                  {totalDebit.toLocaleString("en-IN", { style: "currency", currency: "INR" })}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Total Credit</p>
                <p className="text-lg font-bold">
                  {totalCredit.toLocaleString("en-IN", { style: "currency", currency: "INR" })}
                </p>
              </div>
              {!isBalanced && (
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Difference</p>
                  <p className="text-lg font-bold text-red-600">
                    {Math.abs(totalDebit - totalCredit).toLocaleString("en-IN", { style: "currency", currency: "INR" })}
                  </p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trial Balance Table */}
      <Card>
        <CardHeader className="text-center border-b">
          <CardTitle className="text-xl">{settings.name}</CardTitle>
          <p className="text-sm text-muted-foreground">
            Trial Balance as on {new Date(toDate).toLocaleDateString("en-IN", {
              day: "numeric",
              month: "long",
              year: "numeric"
            })}
          </p>
          <p className="text-xs text-muted-foreground">
            Period: {new Date(fromDate).toLocaleDateString("en-IN")} to {new Date(toDate).toLocaleDateString("en-IN")}
          </p>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="font-semibold">Particulars</TableHead>
                <TableHead className="text-right font-semibold">Debit (Dr.)</TableHead>
                <TableHead className="text-right font-semibold">Credit (Cr.)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {Object.entries(groupedData).map(([group, accounts]) => (
                <>
                  <TableRow key={group} className="bg-muted/30">
                    <TableCell colSpan={3} className="font-semibold text-primary">
                      {group}
                    </TableCell>
                  </TableRow>
                  {accounts.map((account, idx) => (
                    <TableRow key={`${group}-${idx}`}>
                      <TableCell className="pl-8">{account.name}</TableCell>
                      <TableCell className="text-right font-mono">
                        {account.debit > 0 
                          ? account.debit.toLocaleString("en-IN", { style: "currency", currency: "INR" })
                          : "-"
                        }
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        {account.credit > 0 
                          ? account.credit.toLocaleString("en-IN", { style: "currency", currency: "INR" })
                          : "-"
                        }
                      </TableCell>
                    </TableRow>
                  ))}
                </>
              ))}
              <TableRow className="bg-primary/10 font-bold">
                <TableCell>Total</TableCell>
                <TableCell className="text-right font-mono">
                  {totalDebit.toLocaleString("en-IN", { style: "currency", currency: "INR" })}
                </TableCell>
                <TableCell className="text-right font-mono">
                  {totalCredit.toLocaleString("en-IN", { style: "currency", currency: "INR" })}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Account Summary Cards */}
      <div className="grid grid-cols-5 gap-4 no-print">
        {["Assets", "Liabilities", "Capital", "Income", "Expenses"].map((group) => {
          const groupAccounts = groupedData[group] || []
          const groupDebit = groupAccounts.reduce((a, b) => a + b.debit, 0)
          const groupCredit = groupAccounts.reduce((a, b) => a + b.credit, 0)
          
          return (
            <Card key={group}>
              <CardContent className="pt-4">
                <p className="text-sm font-medium text-muted-foreground">{group}</p>
                <p className="text-lg font-bold">
                  {(groupDebit - groupCredit).toLocaleString("en-IN", {
                    style: "currency",
                    currency: "INR",
                    maximumFractionDigits: 0
                  })}
                </p>
                <p className="text-xs text-muted-foreground">
                  {groupAccounts.length} accounts
                </p>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
