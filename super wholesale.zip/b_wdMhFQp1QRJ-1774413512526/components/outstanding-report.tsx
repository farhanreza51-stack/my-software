"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  AlertCircle,
  IndianRupee,
  Clock,
  CheckCircle,
  CreditCard,
} from "lucide-react"
import type { Invoice, Party } from "@/app/page"

interface OutstandingReportProps {
  invoices: Invoice[]
  parties: Party[]
  onReceivePayment: (invoiceId: string, amount: number, paymentMode: "cash" | "bank") => void
}

export function OutstandingReport({
  invoices,
  parties,
  onReceivePayment,
}: OutstandingReportProps) {
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null)
  const [paymentAmount, setPaymentAmount] = useState("")
  const [paymentMode, setPaymentMode] = useState<"cash" | "bank">("cash")

  const receivables = invoices
    .filter((inv) => inv.type === "sale" && inv.status !== "paid")
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  const payables = invoices
    .filter((inv) => inv.type === "purchase" && inv.status !== "paid")
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  const totalReceivables = receivables.reduce(
    (a, b) => a + (b.total - b.paidAmount),
    0
  )
  const totalPayables = payables.reduce(
    (a, b) => a + (b.total - b.paidAmount),
    0
  )

  // Age analysis
  const getAgeBracket = (date: string) => {
    const days = Math.floor(
      (Date.now() - new Date(date).getTime()) / (1000 * 60 * 60 * 24)
    )
    if (days <= 30) return "0-30 days"
    if (days <= 60) return "31-60 days"
    if (days <= 90) return "61-90 days"
    return "90+ days"
  }

  const receivablesAging = {
    "0-30 days": receivables
      .filter((inv) => getAgeBracket(inv.date) === "0-30 days")
      .reduce((a, b) => a + (b.total - b.paidAmount), 0),
    "31-60 days": receivables
      .filter((inv) => getAgeBracket(inv.date) === "31-60 days")
      .reduce((a, b) => a + (b.total - b.paidAmount), 0),
    "61-90 days": receivables
      .filter((inv) => getAgeBracket(inv.date) === "61-90 days")
      .reduce((a, b) => a + (b.total - b.paidAmount), 0),
    "90+ days": receivables
      .filter((inv) => getAgeBracket(inv.date) === "90+ days")
      .reduce((a, b) => a + (b.total - b.paidAmount), 0),
  }

  const handleReceivePayment = () => {
    if (!selectedInvoice || !paymentAmount) return
    const amount = Number(paymentAmount)
    if (amount <= 0 || amount > selectedInvoice.total - selectedInvoice.paidAmount) return

    onReceivePayment(selectedInvoice.id, amount, paymentMode)
    setSelectedInvoice(null)
    setPaymentAmount("")
  }

  // Group by party
  const receivablesByParty = parties
    .filter((p) => p.type === "customer")
    .map((party) => {
      const partyInvoices = receivables.filter((inv) => inv.partyId === party.id)
      const totalOutstanding = partyInvoices.reduce(
        (a, b) => a + (b.total - b.paidAmount),
        0
      )
      return { ...party, invoices: partyInvoices, totalOutstanding }
    })
    .filter((p) => p.totalOutstanding > 0)
    .sort((a, b) => b.totalOutstanding - a.totalOutstanding)

  const payablesByParty = parties
    .filter((p) => p.type === "supplier")
    .map((party) => {
      const partyInvoices = payables.filter((inv) => inv.partyId === party.id)
      const totalOutstanding = partyInvoices.reduce(
        (a, b) => a + (b.total - b.paidAmount),
        0
      )
      return { ...party, invoices: partyInvoices, totalOutstanding }
    })
    .filter((p) => p.totalOutstanding > 0)
    .sort((a, b) => b.totalOutstanding - a.totalOutstanding)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">
          Outstanding Report
        </h2>
        <p className="text-muted-foreground">
          Track receivables and payables with aging analysis
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-emerald-500">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <IndianRupee className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">
                  Total Receivables
                </p>
                <p className="text-xl font-bold text-emerald-600">
                  ₹{totalReceivables.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-red-500">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-red-500/10 flex items-center justify-center">
                <IndianRupee className="h-5 w-5 text-red-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Payables</p>
                <p className="text-xl font-bold text-red-600">
                  ₹{totalPayables.toLocaleString("en-IN")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Clock className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">
                  Pending Invoices
                </p>
                <p className="text-xl font-bold">
                  {receivables.length + payables.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card
          className={
            totalReceivables - totalPayables >= 0
              ? "border-emerald-500"
              : "border-red-500"
          }
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div
                className={`h-10 w-10 rounded-full flex items-center justify-center ${
                  totalReceivables - totalPayables >= 0
                    ? "bg-emerald-500/10"
                    : "bg-red-500/10"
                }`}
              >
                <CheckCircle
                  className={`h-5 w-5 ${
                    totalReceivables - totalPayables >= 0
                      ? "text-emerald-500"
                      : "text-red-500"
                  }`}
                />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Net Position</p>
                <p
                  className={`text-xl font-bold ${
                    totalReceivables - totalPayables >= 0
                      ? "text-emerald-600"
                      : "text-red-600"
                  }`}
                >
                  ₹
                  {Math.abs(totalReceivables - totalPayables).toLocaleString(
                    "en-IN"
                  )}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Aging Analysis */}
      <Card>
        <CardHeader>
          <CardTitle>Receivables Aging Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            {Object.entries(receivablesAging).map(([bracket, amount]) => (
              <div
                key={bracket}
                className={`p-4 rounded-lg ${
                  bracket === "90+ days"
                    ? "bg-red-500/10"
                    : bracket === "61-90 days"
                    ? "bg-amber-500/10"
                    : bracket === "31-60 days"
                    ? "bg-blue-500/10"
                    : "bg-emerald-500/10"
                }`}
              >
                <p className="text-sm text-muted-foreground">{bracket}</p>
                <p
                  className={`text-xl font-bold ${
                    bracket === "90+ days"
                      ? "text-red-600"
                      : bracket === "61-90 days"
                      ? "text-amber-600"
                      : bracket === "31-60 days"
                      ? "text-blue-600"
                      : "text-emerald-600"
                  }`}
                >
                  ₹{amount.toLocaleString("en-IN")}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="receivables">
        <TabsList>
          <TabsTrigger value="receivables">
            Receivables ({receivables.length})
          </TabsTrigger>
          <TabsTrigger value="payables">
            Payables ({payables.length})
          </TabsTrigger>
          <TabsTrigger value="partywise">Party-wise Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="receivables">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-emerald-600">
                <AlertCircle className="h-5 w-5" />
                Outstanding Receivables
              </CardTitle>
            </CardHeader>
            <CardContent>
              {receivables.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No outstanding receivables. All invoices are paid!
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead className="text-right">Invoice Amt</TableHead>
                      <TableHead className="text-right">Paid</TableHead>
                      <TableHead className="text-right">Outstanding</TableHead>
                      <TableHead>Age</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-center">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {receivables.map((inv) => (
                      <TableRow key={inv.id}>
                        <TableCell className="font-mono">
                          {inv.invoiceNo}
                        </TableCell>
                        <TableCell>{inv.date}</TableCell>
                        <TableCell>{inv.partyName}</TableCell>
                        <TableCell className="text-right">
                          ₹{inv.total.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹{inv.paidAmount.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-emerald-600">
                          ₹{(inv.total - inv.paidAmount).toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              getAgeBracket(inv.date) === "90+ days"
                                ? "destructive"
                                : getAgeBracket(inv.date) === "61-90 days"
                                ? "secondary"
                                : "outline"
                            }
                          >
                            {getAgeBracket(inv.date)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              inv.status === "partial" ? "secondary" : "destructive"
                            }
                          >
                            {inv.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedInvoice(inv)
                              setPaymentAmount(String(inv.total - inv.paidAmount))
                            }}
                          >
                            <CreditCard className="h-4 w-4 mr-1" />
                            Receive
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payables">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <AlertCircle className="h-5 w-5" />
                Outstanding Payables
              </CardTitle>
            </CardHeader>
            <CardContent>
              {payables.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No outstanding payables. All purchases are paid!
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Voucher No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Supplier</TableHead>
                      <TableHead className="text-right">Invoice Amt</TableHead>
                      <TableHead className="text-right">Paid</TableHead>
                      <TableHead className="text-right">Outstanding</TableHead>
                      <TableHead>Age</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payables.map((inv) => (
                      <TableRow key={inv.id}>
                        <TableCell className="font-mono">
                          {inv.invoiceNo}
                        </TableCell>
                        <TableCell>{inv.date}</TableCell>
                        <TableCell>{inv.partyName}</TableCell>
                        <TableCell className="text-right">
                          ₹{inv.total.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right">
                          ₹{inv.paidAmount.toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-red-600">
                          ₹{(inv.total - inv.paidAmount).toLocaleString("en-IN")}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              getAgeBracket(inv.date) === "90+ days"
                                ? "destructive"
                                : "outline"
                            }
                          >
                            {getAgeBracket(inv.date)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              inv.status === "partial" ? "secondary" : "destructive"
                            }
                          >
                            {inv.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="partywise" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-emerald-600">
                Receivables by Customer
              </CardTitle>
            </CardHeader>
            <CardContent>
              {receivablesByParty.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No outstanding receivables.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Customer</TableHead>
                      <TableHead className="text-right">
                        Pending Invoices
                      </TableHead>
                      <TableHead className="text-right">
                        Total Outstanding
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {receivablesByParty.map((party) => (
                      <TableRow key={party.id}>
                        <TableCell className="font-medium">
                          {party.name}
                        </TableCell>
                        <TableCell className="text-right">
                          {party.invoices.length}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-emerald-600">
                          ₹{party.totalOutstanding.toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-red-600">
                Payables by Supplier
              </CardTitle>
            </CardHeader>
            <CardContent>
              {payablesByParty.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No outstanding payables.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Supplier</TableHead>
                      <TableHead className="text-right">
                        Pending Invoices
                      </TableHead>
                      <TableHead className="text-right">
                        Total Outstanding
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payablesByParty.map((party) => (
                      <TableRow key={party.id}>
                        <TableCell className="font-medium">
                          {party.name}
                        </TableCell>
                        <TableCell className="text-right">
                          {party.invoices.length}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-red-600">
                          ₹{party.totalOutstanding.toLocaleString("en-IN")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Payment Dialog */}
      <Dialog
        open={!!selectedInvoice}
        onOpenChange={() => setSelectedInvoice(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Receive Payment</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-4">
              <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Invoice No:</span>
                  <span className="font-mono">{selectedInvoice.invoiceNo}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Customer:</span>
                  <span>{selectedInvoice.partyName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Invoice Amount:</span>
                  <span>₹{selectedInvoice.total.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Already Paid:</span>
                  <span>
                    ₹{selectedInvoice.paidAmount.toLocaleString("en-IN")}
                  </span>
                </div>
                <div className="flex justify-between font-semibold border-t pt-2">
                  <span>Outstanding:</span>
                  <span className="text-emerald-600">
                    ₹
                    {(
                      selectedInvoice.total - selectedInvoice.paidAmount
                    ).toLocaleString("en-IN")}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Payment Amount</label>
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  max={selectedInvoice.total - selectedInvoice.paidAmount}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Payment Mode</label>
                <Select
                  value={paymentMode}
                  onValueChange={(v) => setPaymentMode(v as "cash" | "bank")}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="bank">Bank</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setSelectedInvoice(null)}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-amber-500 hover:bg-amber-600 text-slate-900"
                  onClick={handleReceivePayment}
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  Receive Payment
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
