"use client"

import { useState, useEffect, useCallback, useMemo, Suspense, lazy } from "react"
import { LoginScreen } from "@/components/login-screen"
import { Sidebar } from "@/components/sidebar"
import { Dashboard } from "@/components/dashboard"
import { KeyboardShortcuts } from "@/components/keyboard-shortcuts"
import { Calculator } from "@/components/calculator"
import { GlobalSearch } from "@/components/global-search"
import { FunctionBar } from "@/components/function-bar"
import { TopBar } from "@/components/top-bar"
import { Gateway } from "@/components/gateway"

// Lazy load heavy components for better performance
const Inventory = lazy(() => import("@/components/inventory").then(m => ({ default: m.Inventory })))
const Billing = lazy(() => import("@/components/billing").then(m => ({ default: m.Billing })))
const Purchase = lazy(() => import("@/components/purchase").then(m => ({ default: m.Purchase })))
const PartyMaster = lazy(() => import("@/components/party-master").then(m => ({ default: m.PartyMaster })))
const Ledger = lazy(() => import("@/components/ledger").then(m => ({ default: m.Ledger })))
const DayBook = lazy(() => import("@/components/day-book").then(m => ({ default: m.DayBook })))
const BalanceSheet = lazy(() => import("@/components/balance-sheet").then(m => ({ default: m.BalanceSheet })))
const ProfitLoss = lazy(() => import("@/components/profit-loss").then(m => ({ default: m.ProfitLoss })))
const GSTReports = lazy(() => import("@/components/gst-reports").then(m => ({ default: m.GSTReports })))
const StockReport = lazy(() => import("@/components/stock-report").then(m => ({ default: m.StockReport })))
const OutstandingReport = lazy(() => import("@/components/outstanding-report").then(m => ({ default: m.OutstandingReport })))
const Settings = lazy(() => import("@/components/settings").then(m => ({ default: m.Settings })))
const BankBook = lazy(() => import("@/components/bank-book").then(m => ({ default: m.BankBook })))
const CashBook = lazy(() => import("@/components/cash-book").then(m => ({ default: m.CashBook })))
const VoucherEntry = lazy(() => import("@/components/voucher-entry").then(m => ({ default: m.VoucherEntry })))
const ExpenseManager = lazy(() => import("@/components/expense-manager").then(m => ({ default: m.ExpenseManager })))
const TrialBalance = lazy(() => import("@/components/trial-balance").then(m => ({ default: m.TrialBalance })))
const Payroll = lazy(() => import("@/components/payroll").then(m => ({ default: m.Payroll })))
const Compliance = lazy(() => import("@/components/compliance").then(m => ({ default: m.Compliance })))

// Loading component
function PageLoader() {
  return (
    <div className="flex items-center justify-center h-64">
      <div className="flex flex-col items-center gap-3">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-amber-500 border-t-transparent" />
        <span className="text-sm text-muted-foreground">Loading...</span>
      </div>
    </div>
  )
}

export type InventoryItem = {
  id: string
  name: string
  hsn: string
  category: string
  qty: number
  price: number
  purchasePrice: number
  gstRate: number
  unit: string
  minStock: number
  location: string
}

export type Party = {
  id: string
  name: string
  type: "customer" | "supplier"
  phone: string
  email: string
  address: string
  gstin: string
  openingBalance: number
  balanceType: "debit" | "credit"
  currentBalance: number
}

export type BillItem = {
  itemId: string
  name: string
  hsn: string
  qty: number
  price: number
  discount: number
  gstRate: number
  amount: number
}

export type Invoice = {
  id: string
  invoiceNo: string
  type: "sale" | "purchase"
  partyId: string
  partyName: string
  items: BillItem[]
  subtotal: number
  discount: number
  gstAmount: number
  total: number
  paidAmount: number
  paymentMode: "cash" | "bank" | "credit"
  date: string
  dueDate: string
  status: "paid" | "partial" | "unpaid"
  notes: string
}

export type Transaction = {
  id: string
  date: string
  type: "receipt" | "payment" | "sale" | "purchase" | "expense" | "journal" | "contra"
  voucherNo: string
  partyId?: string
  partyName?: string
  description: string
  debit: number
  credit: number
  balance: number
  paymentMode: "cash" | "bank"
  reference?: string
}

export type ExpenseCategory = {
  id: string
  name: string
}

export type CompanySettings = {
  name: string
  address: string
  phone: string
  email: string
  gstin: string
  pan: string
  bankName: string
  accountNo: string
  ifsc: string
  financialYearStart: string
  financialYearEnd: string
}

export type Employee = {
  id: string
  employeeCode: string
  name: string
  department: string
  designation: string
  dateOfJoining: string
  basicSalary: number
  hra: number
  da: number
  ta: number
  otherAllowances: number
  pf: number
  esi: number
  tds: number
  bankAccount: string
  bankName: string
  ifsc: string
  pan: string
  aadhaar: string
  phone: string
  email: string
  address: string
  status: "active" | "inactive"
}

export type SalarySlip = {
  id: string
  employeeId: string
  employeeName: string
  month: string
  year: number
  workingDays: number
  presentDays: number
  basicSalary: number
  hra: number
  da: number
  ta: number
  otherAllowances: number
  grossSalary: number
  pf: number
  esi: number
  tds: number
  otherDeductions: number
  totalDeductions: number
  netSalary: number
  status: "draft" | "processed" | "paid"
  paymentDate?: string
}

export type PageType = 
  | "dashboard" 
  | "inventory" 
  | "sales" 
  | "purchase"
  | "party"
  | "ledger" 
  | "daybook"
  | "cashbook"
  | "bankbook"
  | "voucher"
  | "expense"
  | "trialbalance"
  | "balancesheet"
  | "profitloss"
  | "gstreports"
  | "stockreport"
  | "outstanding"
  | "payroll"
  | "compliance"
  | "settings"

const defaultSettings: CompanySettings = {
  name: "Super Wholesale Traders",
  address: "123 Market Street, New Delhi - 110001",
  phone: "9876543210",
  email: "contact@superwholesale.com",
  gstin: "07AABCU9603R1ZM",
  pan: "AABCU9603R",
  bankName: "State Bank of India",
  accountNo: "1234567890",
  ifsc: "SBIN0001234",
  financialYearStart: "2024-04-01",
  financialYearEnd: "2025-03-31",
}

const defaultExpenseCategories: ExpenseCategory[] = [
  { id: "1", name: "Rent" },
  { id: "2", name: "Electricity" },
  { id: "3", name: "Salary" },
  { id: "4", name: "Transport" },
  { id: "5", name: "Office Supplies" },
  { id: "6", name: "Telephone" },
  { id: "7", name: "Internet" },
  { id: "8", name: "Repairs & Maintenance" },
  { id: "9", name: "Advertising" },
  { id: "10", name: "Insurance" },
]

export default function WholesaleApp() {
  const [user, setUser] = useState<string | null>(null)
  const [page, setPage] = useState<PageType>("dashboard")
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [showCalculator, setShowCalculator] = useState(false)
  const [showSearch, setShowSearch] = useState(false)

  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [parties, setParties] = useState<Party[]>([])
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [settings, setSettings] = useState<CompanySettings>(defaultSettings)
  const [expenseCategories, setExpenseCategories] = useState<ExpenseCategory[]>(defaultExpenseCategories)
  const [employees, setEmployees] = useState<Employee[]>([])
  const [salarySlips, setSalarySlips] = useState<SalarySlip[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Load data from localStorage on mount
  useEffect(() => {
    const loadData = () => {
      try {
        const savedInventory = localStorage.getItem("erp_inventory")
        const savedParties = localStorage.getItem("erp_parties")
        const savedInvoices = localStorage.getItem("erp_invoices")
        const savedTransactions = localStorage.getItem("erp_transactions")
        const savedSettings = localStorage.getItem("erp_settings")
        const savedCategories = localStorage.getItem("erp_expense_categories")
        const savedEmployees = localStorage.getItem("erp_employees")
        const savedSalarySlips = localStorage.getItem("erp_salary_slips")
        
        if (savedInventory) setInventory(JSON.parse(savedInventory))
        if (savedParties) {
          const partiesData = JSON.parse(savedParties)
          // Ensure currentBalance is set
          const updatedParties = partiesData.map((p: any) => ({
            ...p,
            currentBalance: p.currentBalance ?? (p.balanceType === "debit" ? p.openingBalance : -p.openingBalance)
          }))
          setParties(updatedParties)
        }
        if (savedInvoices) setInvoices(JSON.parse(savedInvoices))
        if (savedTransactions) setTransactions(JSON.parse(savedTransactions))
        if (savedSettings) setSettings(JSON.parse(savedSettings))
        if (savedCategories) setExpenseCategories(JSON.parse(savedCategories))
        if (savedEmployees) setEmployees(JSON.parse(savedEmployees))
        if (savedSalarySlips) setSalarySlips(JSON.parse(savedSalarySlips))
      } catch (error) {
        console.error("Error loading data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  // Debounced save to localStorage
  useEffect(() => {
    if (isLoading) return
    const timeout = setTimeout(() => {
      localStorage.setItem("erp_inventory", JSON.stringify(inventory))
    }, 300)
    return () => clearTimeout(timeout)
  }, [inventory, isLoading])

  useEffect(() => {
    if (isLoading) return
    const timeout = setTimeout(() => {
      localStorage.setItem("erp_parties", JSON.stringify(parties))
    }, 300)
    return () => clearTimeout(timeout)
  }, [parties, isLoading])

  useEffect(() => {
    if (isLoading) return
    const timeout = setTimeout(() => {
      localStorage.setItem("erp_invoices", JSON.stringify(invoices))
    }, 300)
    return () => clearTimeout(timeout)
  }, [invoices, isLoading])

  useEffect(() => {
    if (isLoading) return
    const timeout = setTimeout(() => {
      localStorage.setItem("erp_transactions", JSON.stringify(transactions))
    }, 300)
    return () => clearTimeout(timeout)
  }, [transactions, isLoading])

  useEffect(() => {
    if (isLoading) return
    const timeout = setTimeout(() => {
      localStorage.setItem("erp_settings", JSON.stringify(settings))
    }, 300)
    return () => clearTimeout(timeout)
  }, [settings, isLoading])

  useEffect(() => {
    if (isLoading) return
    const timeout = setTimeout(() => {
      localStorage.setItem("erp_expense_categories", JSON.stringify(expenseCategories))
    }, 300)
    return () => clearTimeout(timeout)
  }, [expenseCategories, isLoading])

  useEffect(() => {
    if (isLoading) return
    const timeout = setTimeout(() => {
      localStorage.setItem("erp_employees", JSON.stringify(employees))
    }, 300)
    return () => clearTimeout(timeout)
  }, [employees, isLoading])

  useEffect(() => {
    if (isLoading) return
    const timeout = setTimeout(() => {
      localStorage.setItem("erp_salary_slips", JSON.stringify(salarySlips))
    }, 300)
    return () => clearTimeout(timeout)
  }, [salarySlips, isLoading])

  const generateId = useCallback(() => Math.random().toString(36).substr(2, 9), [])

  const handleLogin = useCallback((username: string) => {
    setUser(username)
  }, [])

  const handleLogout = useCallback(() => {
    setUser(null)
    setPage("dashboard")
  }, [])

  // Inventory functions
  const addInventoryItem = useCallback((item: Omit<InventoryItem, "id">) => {
    setInventory(prev => [...prev, { ...item, id: generateId() }])
  }, [generateId])

  const updateInventoryItem = useCallback((id: string, item: Partial<InventoryItem>) => {
    setInventory(prev => prev.map((i) => (i.id === id ? { ...i, ...item } : i)))
  }, [])

  const deleteInventoryItem = useCallback((id: string) => {
    setInventory(prev => prev.filter((i) => i.id !== id))
  }, [])

  // Party functions
  const addParty = useCallback((party: Omit<Party, "id">) => {
    setParties(prev => [...prev, { 
      ...party, 
      id: generateId(),
      currentBalance: party.balanceType === "debit" ? party.openingBalance : -party.openingBalance
    }])
  }, [generateId])

  const updateParty = useCallback((id: string, party: Partial<Party>) => {
    setParties(prev => prev.map((p) => (p.id === id ? { ...p, ...party } : p)))
  }, [])

  const deleteParty = useCallback((id: string) => {
    setParties(prev => prev.filter((p) => p.id !== id))
  }, [])

  const updatePartyBalance = useCallback((partyId: string, amount: number, type: 'debit' | 'credit') => {
    setParties(prev => prev.map(p => {
      if (p.id === partyId) {
        const newBalance = type === 'debit' ? p.currentBalance + amount : p.currentBalance - amount
        return { ...p, currentBalance: newBalance }
      }
      return p
    }))
  }, [])

  // Invoice functions
  const generateInvoiceNo = useCallback((type: "sale" | "purchase") => {
    const prefix = type === "sale" ? "INV" : "PUR"
    const count = invoices.filter((i) => i.type === type).length + 1
    return `${prefix}-${String(count).padStart(5, "0")}`
  }, [invoices])

  const createInvoice = useCallback((invoice: Omit<Invoice, "id" | "invoiceNo">) => {
    const newInvoice: Invoice = {
      ...invoice,
      id: generateId(),
      invoiceNo: generateInvoiceNo(invoice.type),
    }
    setInvoices((prev) => [...prev, newInvoice])

    // Update inventory
    if (invoice.type === "sale") {
      setInventory((prev) =>
        prev.map((inv) => {
          const sold = invoice.items.find((b) => b.itemId === inv.id)
          if (sold) return { ...inv, qty: inv.qty - sold.qty }
          return inv
        })
      )
    } else {
      setInventory((prev) =>
        prev.map((inv) => {
          const purchased = invoice.items.find((b) => b.itemId === inv.id)
          if (purchased) return { ...inv, qty: inv.qty + purchased.qty }
          return inv
        })
      )
    }

    // Add transaction
    const txn: Transaction = {
      id: generateId(),
      date: invoice.date,
      type: invoice.type,
      voucherNo: newInvoice.invoiceNo,
      partyId: invoice.partyId,
      partyName: invoice.partyName,
      description: `${invoice.type === "sale" ? "Sale" : "Purchase"} to ${invoice.partyName}`,
      debit: invoice.type === "sale" ? invoice.total : 0,
      credit: invoice.type === "purchase" ? invoice.total : 0,
      balance: 0,
      paymentMode: invoice.paymentMode === "credit" ? "cash" : invoice.paymentMode,
    }
    setTransactions((prev) => [...prev, txn])

    // Update party balance
    updatePartyBalance(invoice.partyId, invoice.total, invoice.type === "sale" ? 'debit' : 'credit')

    return newInvoice
  }, [generateId, generateInvoiceNo, updatePartyBalance])

  const deleteInvoice = useCallback((id: string) => {
    const invoice = invoices.find(i => i.id === id)
    if (!invoice) return

    // Reverse inventory
    if (invoice.type === "sale") {
      setInventory(prev => prev.map(inv => {
        const sold = invoice.items.find(b => b.itemId === inv.id)
        if (sold) return { ...inv, qty: inv.qty + sold.qty }
        return inv
      }))
    } else {
      setInventory(prev => prev.map(inv => {
        const purchased = invoice.items.find(b => b.itemId === inv.id)
        if (purchased) return { ...inv, qty: inv.qty - purchased.qty }
        return inv
      }))
    }

    // Remove transaction
    setTransactions(prev => prev.filter(t => t.voucherNo === invoice.invoiceNo))

    // Reverse party balance
    updatePartyBalance(invoice.partyId, -invoice.total, invoice.type === "sale" ? 'debit' : 'credit')

    setInvoices(prev => prev.filter(i => i.id !== id))
  }, [invoices, updatePartyBalance])

  // Transaction functions
  const addTransaction = useCallback((txn: Omit<Transaction, "id" | "balance">) => {
    const newTxn: Transaction = { ...txn, id: generateId(), balance: 0 }
    setTransactions(prev => [...prev, newTxn])

    // Update party balance if applicable
    if (txn.partyId) {
      if (txn.type === 'payment') {
        updatePartyBalance(txn.partyId, txn.debit, 'debit')
      } else if (txn.type === 'receipt') {
        updatePartyBalance(txn.partyId, txn.credit, 'credit')
      }
    }
  const deleteTransaction = useCallback((id: string) => {
    const txn = transactions.find(t => t.id === id)
    if (!txn) return

    if (txn.partyId) {
      if (txn.type === 'payment') {
        updatePartyBalance(txn.partyId, -txn.debit, 'debit')
      } else if (txn.type === 'receipt') {
        updatePartyBalance(txn.partyId, -txn.credit, 'credit')
      }
    }

    setTransactions(prev => prev.filter(t => t.id !== id))
  }, [transactions, updatePartyBalance])

  // Employee functions
  const addEmployee = useCallback((employee: Omit<Employee, "id">) => {
    setEmployees(prev => [...prev, { ...employee, id: generateId() }])
  }, [generateId])

  const updateEmployee = useCallback((id: string, employee: Partial<Employee>) => {
    setEmployees(prev => prev.map((e) => (e.id === id ? { ...e, ...employee } : e)))
  }, [])

  const deleteEmployee = useCallback((id: string) => {
    setEmployees(prev => prev.filter((e) => e.id !== id))
  }, [])

  // Salary slip functions
  const processSalary = useCallback((slip: Omit<SalarySlip, "id">) => {
    setSalarySlips(prev => [...prev, { ...slip, id: generateId() }])
  }, [generateId])

  const updateSalarySlip = useCallback((id: string, slip: Partial<SalarySlip>) => {
    setSalarySlips(prev => prev.map((s) => (s.id === id ? { ...s, ...slip } : s)))
  }, [])

  const updateInvoicePayment = useCallback((invoiceId: string, amount: number, paymentMode: "cash" | "bank") => {
    let invoice: Invoice | undefined

    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === invoiceId) {
          const newPaidAmount = inv.paidAmount + amount
          const status = newPaidAmount >= inv.total ? "paid" : newPaidAmount > 0 ? "partial" : "unpaid"
          invoice = inv
          return { ...inv, paidAmount: newPaidAmount, status }
        }
        return inv
      })
    )

    if (invoice) {
      addTransaction({
        date: new Date().toISOString().split("T")[0],
        type: "receipt",
        voucherNo: `RCP-${String(transactions.length + 1).padStart(5, "0")}`,
        partyId: invoice.partyId,
        partyName: invoice.partyName,
        description: `Payment received for ${invoice.invoiceNo}`,
        debit: amount,
        credit: 0,
        paymentMode,
      })

      // Update party balance for receipt
      updatePartyBalance(invoice.partyId, amount, 'credit')
    }
  }, [addTransaction, transactions.length])

  // Calculate totals using useMemo for performance
  const totals = useMemo(() => {
    const totalSales = invoices.filter((i) => i.type === "sale").reduce((a, b) => a + b.total, 0)
    const totalPurchases = invoices.filter((i) => i.type === "purchase").reduce((a, b) => a + b.total, 0)
    const totalReceivables = invoices
      .filter((i) => i.type === "sale" && i.status !== "paid")
      .reduce((a, b) => a + (b.total - b.paidAmount), 0)
    const totalPayables = invoices
      .filter((i) => i.type === "purchase" && i.status !== "paid")
      .reduce((a, b) => a + (b.total - b.paidAmount), 0)
    const inventoryValue = inventory.reduce((a, b) => a + b.qty * b.purchasePrice, 0)
    
    // Calculate cash and bank balances from transactions
    const cashBalance = transactions
      .filter((t) => t.paymentMode === "cash")
      .reduce((acc, t) => acc + t.debit - t.credit, 0)
    const bankBalance = transactions
      .filter((t) => t.paymentMode === "bank")
      .reduce((acc, t) => acc + t.debit - t.credit, 0)

    return { totalSales, totalPurchases, totalReceivables, totalPayables, inventoryValue, cashBalance, bankBalance }
  }, [invoices, inventory, transactions])

  // Filtered data using useMemo
  const customers = useMemo(() => parties.filter((p) => p.type === "customer"), [parties])
  const suppliers = useMemo(() => parties.filter((p) => p.type === "supplier"), [parties])
  const salesInvoices = useMemo(() => invoices.filter((i) => i.type === "sale"), [invoices])
  const purchaseInvoices = useMemo(() => invoices.filter((i) => i.type === "purchase"), [invoices])
  const lowStockItems = useMemo(() => inventory.filter((i) => i.qty <= i.minStock), [inventory])
  const pendingInvoices = useMemo(() => invoices.filter((i) => i.status !== "paid"), [invoices])

  // Keyboard shortcut handlers
  const handlePrint = useCallback(() => {
    window.print()
  }, [])

  const handleSave = useCallback(() => {
    // Trigger save animation or action
    console.log("Save triggered via shortcut")
  }, [])

  const handleNew = useCallback(() => {
    // Could be used to trigger new entry dialog
    console.log("New entry triggered via shortcut")
  }, [])

  if (!user) {
    return <LoginScreen onLogin={handleLogin} />
  }

  const renderPage = () => {
    switch (page) {
      case "dashboard":
        return (
          <div className="space-y-8">
            {/* Gateway - Tally-like quick access menu */}
            <Gateway
              onPageChange={setPage}
              stats={{
                totalSales: totals.totalSales,
                totalPurchases: totals.totalPurchases,
                totalReceivables: totals.totalReceivables,
                totalPayables: totals.totalPayables,
                cashBalance: totals.cashBalance,
                bankBalance: totals.bankBalance,
                inventoryValue: totals.inventoryValue,
                lowStockCount: lowStockItems.length,
                pendingInvoices: pendingInvoices.length,
              }}
            />
            
            {/* Dashboard Charts and Details */}
            <Dashboard
              totalSales={totals.totalSales}
              totalPurchases={totals.totalPurchases}
              totalReceivables={totals.totalReceivables}
              totalPayables={totals.totalPayables}
              totalItems={inventory.length}
              lowStockItems={lowStockItems.length}
              totalCustomers={customers.length}
              totalSuppliers={suppliers.length}
              recentInvoices={invoices.slice(-10).reverse()}
              inventoryValue={totals.inventoryValue}
              monthlyData={invoices}
            />
          </div>
        )
      case "inventory":
        return (
          <Suspense fallback={<PageLoader />}>
            <Inventory
              inventory={inventory}
              onAddItem={addInventoryItem}
              onUpdateItem={updateInventoryItem}
              onDeleteItem={deleteInventoryItem}
            />
          </Suspense>
        )
      case "sales":
        return (
          <Suspense fallback={<PageLoader />}>
            <Billing
              inventory={inventory}
              parties={customers}
              invoices={salesInvoices}
              onCreateInvoice={(data) => createInvoice({ ...data, type: "sale" })}
              companySettings={settings}
              onDeleteInvoice={deleteInvoice}
            />
          </Suspense>
        )
      case "purchase":
        return (
          <Suspense fallback={<PageLoader />}>
            <Purchase
              inventory={inventory}
              parties={suppliers}
              invoices={purchaseInvoices}
              onCreateInvoice={(data) => createInvoice({ ...data, type: "purchase" })}
              onAddInventoryItem={addInventoryItem}
              onDeleteInvoice={deleteInvoice}
            />
          </Suspense>
        )
      case "party":
        return (
          <Suspense fallback={<PageLoader />}>
            <PartyMaster
              parties={parties}
              onAddParty={addParty}
              onUpdateParty={updateParty}
              onDeleteParty={deleteParty}
            />
          </Suspense>
        )
      case "ledger":
        return (
          <Suspense fallback={<PageLoader />}>
            <Ledger
              parties={parties}
              invoices={invoices}
              transactions={transactions}
            />
          </Suspense>
        )
      case "daybook":
        return (
          <Suspense fallback={<PageLoader />}>
            <DayBook transactions={transactions} invoices={invoices} />
          </Suspense>
        )
      case "cashbook":
        return (
          <Suspense fallback={<PageLoader />}>
            <CashBook transactions={transactions} />
          </Suspense>
        )
      case "bankbook":
        return (
          <Suspense fallback={<PageLoader />}>
            <BankBook transactions={transactions} />
          </Suspense>
        )
      case "voucher":
        return (
          <Suspense fallback={<PageLoader />}>
            <VoucherEntry
              parties={parties}
              transactions={transactions}
              onAddTransaction={addTransaction}
              onDeleteTransaction={deleteTransaction}
            />
          </Suspense>
        )
      case "expense":
        return (
          <Suspense fallback={<PageLoader />}>
            <ExpenseManager
              transactions={transactions}
              expenseCategories={expenseCategories}
              onAddTransaction={addTransaction}
            />
          </Suspense>
        )
      case "trialbalance":
        return (
          <Suspense fallback={<PageLoader />}>
            <TrialBalance
              parties={parties}
              invoices={invoices}
              transactions={transactions}
              inventory={inventory}
              settings={settings}
            />
          </Suspense>
        )
      case "balancesheet":
        return (
          <Suspense fallback={<PageLoader />}>
            <BalanceSheet
              inventory={inventory}
              invoices={invoices}
              transactions={transactions}
              parties={parties}
              settings={settings}
            />
          </Suspense>
        )
      case "profitloss":
        return (
          <Suspense fallback={<PageLoader />}>
            <ProfitLoss
              invoices={invoices}
              transactions={transactions}
              inventory={inventory}
              settings={settings}
            />
          </Suspense>
        )
      case "gstreports":
        return (
          <Suspense fallback={<PageLoader />}>
            <GSTReports invoices={invoices} parties={parties} settings={settings} />
          </Suspense>
        )
      case "stockreport":
        return (
          <Suspense fallback={<PageLoader />}>
            <StockReport inventory={inventory} invoices={invoices} />
          </Suspense>
        )
      case "outstanding":
        return (
          <Suspense fallback={<PageLoader />}>
            <OutstandingReport
              invoices={invoices}
              parties={parties}
              onReceivePayment={updateInvoicePayment}
            />
          </Suspense>
        )
      case "payroll":
        return (
          <Suspense fallback={<PageLoader />}>
            <Payroll
              employees={employees}
              salarySlips={salarySlips}
              onAddEmployee={addEmployee}
              onUpdateEmployee={updateEmployee}
              onDeleteEmployee={deleteEmployee}
              onProcessSalary={processSalary}
              onUpdateSalarySlip={updateSalarySlip}
            />
          </Suspense>
        )
      case "compliance":
        return (
          <Suspense fallback={<PageLoader />}>
            <Compliance
              invoices={invoices}
              settings={settings}
              salarySlips={salarySlips}
            />
          </Suspense>
        )
      case "settings":
        return (
          <Suspense fallback={<PageLoader />}>
            <Settings
              settings={settings}
              onUpdateSettings={setSettings}
              expenseCategories={expenseCategories}
              onUpdateCategories={setExpenseCategories}
            />
          </Suspense>
        )
      default:
        return null
    }
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar
        currentPage={page}
        onPageChange={setPage}
        onLogout={handleLogout}
        user={user}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        companyName={settings.name}
        onOpenSearch={() => setShowSearch(true)}
        onOpenCalculator={() => setShowCalculator(true)}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar with company info and quick stats */}
        <TopBar
          companySettings={settings}
          currentPage={page}
          user={user}
          cashBalance={totals.cashBalance}
          bankBalance={totals.bankBalance}
        />
        
        {/* Main Content Area */}
        <main className="flex-1 overflow-auto pb-16">
          <div className="p-6">{renderPage()}</div>
        </main>
      </div>
      
      {/* Bottom Function Bar like Tally */}
      <FunctionBar
        currentPage={page}
        onPageChange={setPage}
        onOpenSearch={() => setShowSearch(true)}
        onOpenCalculator={() => setShowCalculator(true)}
        onLogout={handleLogout}
      />

      {/* Keyboard Shortcuts Handler */}
      <KeyboardShortcuts
        onPageChange={setPage}
        onLogout={handleLogout}
        currentPage={page}
        onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
        onOpenSearch={() => setShowSearch(true)}
        onOpenCalculator={() => setShowCalculator(true)}
        onPrint={handlePrint}
        onSave={handleSave}
        onNew={handleNew}
      />

      {/* Calculator Modal */}
      <Calculator open={showCalculator} onOpenChange={setShowCalculator} />

      {/* Global Search Modal */}
      <GlobalSearch
        open={showSearch}
        onOpenChange={setShowSearch}
        onPageChange={setPage}
        inventory={inventory}
        parties={parties}
        invoices={invoices}
      />
    </div>
  )
}
