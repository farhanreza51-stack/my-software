"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Plus,
  ShoppingCart,
  Save,
  Trash2,
  FileText,
  Eye,
  Package,
} from "lucide-react"
import type { BillItem, InventoryItem, Party, Invoice } from "@/app/page"

interface PurchaseProps {
  inventory: InventoryItem[]
  parties: Party[]
  invoices: Invoice[]
  onCreateInvoice: (invoice: Omit<Invoice, "id" | "invoiceNo" | "type">) => Invoice
  onAddInventoryItem: (item: Omit<InventoryItem, "id">) => void
}

export function Purchase({
  inventory,
  parties,
  invoices,
  onCreateInvoice,
  onAddInventoryItem,
}: PurchaseProps) {
  const [selectedParty, setSelectedParty] = useState<string>("")
  const [billItems, setBillItems] = useState<BillItem[]>([])
  const [currentItem, setCurrentItem] = useState({
    itemId: "",
    name: "",
    hsn: "",
    qty: "",
    price: "",
    discount: "0",
    gstRate: "18",
    isNew: false,
  })
  const [paymentMode, setPaymentMode] = useState<"cash" | "bank" | "credit">("credit")
  const [notes, setNotes] = useState("")
  const [invoiceNo, setInvoiceNo] = useState("")
  const [invoiceDate, setInvoiceDate] = useState(
    new Date().toISOString().split("T")[0]
  )
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null)

  const party = parties.find((p) => p.id === selectedParty)

  const addToBill = () => {
    if (!currentItem.name || !currentItem.qty || !currentItem.price) return

    const qty = Number(currentItem.qty)
    const price = Number(currentItem.price)
    const discount = Number(currentItem.discount) || 0
    const gstRate = Number(currentItem.gstRate)

    const baseAmount = qty * price
    const discountAmount = (baseAmount * discount) / 100
    const taxableAmount = baseAmount - discountAmount
    const gstAmount = (taxableAmount * gstRate) / 100
    const amount = taxableAmount + gstAmount

    // If it's a new item, add to inventory
    if (currentItem.isNew) {
      onAddInventoryItem({
        name: currentItem.name,
        hsn: currentItem.hsn,
        category: "",
        qty: 0, // Will be updated when purchase is saved
        price: Math.round(price * 1.2), // Default sale price 20% margin
        purchasePrice: price,
        gstRate,
        unit: "Pcs",
        minStock: 10,
        location: "",
      })
    }

    setBillItems([
      ...billItems,
      {
        itemId: currentItem.itemId || `new-${Date.now()}`,
        name: currentItem.name,
        hsn: currentItem.hsn,
        qty,
        price,
        discount,
        gstRate,
        amount,
      },
    ])
    setCurrentItem({
      itemId: "",
      name: "",
      hsn: "",
      qty: "",
      price: "",
      discount: "0",
      gstRate: "18",
      isNew: false,
    })
  }

  const removeItem = (index: number) => {
    setBillItems(billItems.filter((_, i) => i !== index))
  }

  const handleSelectItem = (itemId: string) => {
    if (itemId === "new") {
      setCurrentItem({
        itemId: "",
        name: "",
        hsn: "",
        qty: "",
        price: "",
        discount: "0",
        gstRate: "18",
        isNew: true,
      })
      return
    }

    const item = inventory.find((i) => i.id === itemId)
    if (item) {
      setCurrentItem({
        itemId: item.id,
        name: item.name,
        hsn: item.hsn,
        qty: "1",
        price: String(item.purchasePrice),
        discount: "0",
        gstRate: String(item.gstRate),
        isNew: false,
      })
    }
  }

  const subtotal = billItems.reduce((a, b) => a + b.qty * b.price, 0)
  const totalDiscount = billItems.reduce(
    (a, b) => a + (b.qty * b.price * b.discount) / 100,
    0
  )
  const totalGst = billItems.reduce(
    (a, b) =>
      a + ((b.qty * b.price - (b.qty * b.price * b.discount) / 100) * b.gstRate) / 100,
    0
  )
  const grandTotal = subtotal - totalDiscount + totalGst

  const savePurchase = () => {
    if (!selectedParty || billItems.length === 0) return

    onCreateInvoice({
      partyId: selectedParty,
      partyName: party?.name || "",
      items: billItems,
      subtotal,
      discount: totalDiscount,
      gstAmount: totalGst,
      total: Math.round(grandTotal),
      paidAmount: paymentMode === "credit" ? 0 : Math.round(grandTotal),
      paymentMode,
      date: invoiceDate,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0],
      status: paymentMode === "credit" ? "unpaid" : "paid",
      notes: `Supplier Invoice: ${invoiceNo}\n${notes}`,
    })

    setSelectedParty("")
    setBillItems([])
    setNotes("")
    setInvoiceNo("")
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Purchase Entry</h2>
        <p className="text-muted-foreground">
          Record purchases from suppliers
        </p>
      </div>

      <Tabs defaultValue="create">
        <TabsList>
          <TabsTrigger value="create">New Purchase</TabsTrigger>
          <TabsTrigger value="history">
            Purchase History ({invoices.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-5">
            {/* Left Panel */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  Purchase Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Select Supplier *</label>
                  <Select value={selectedParty} onValueChange={setSelectedParty}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select supplier..." />
                    </SelectTrigger>
                    <SelectContent>
                      {parties.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name} {p.gstin && `(${p.gstin})`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Supplier Invoice No</label>
                    <Input
                      placeholder="Invoice No"
                      value={invoiceNo}
                      onChange={(e) => setInvoiceNo(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Invoice Date</label>
                    <Input
                      type="date"
                      value={invoiceDate}
                      onChange={(e) => setInvoiceDate(e.target.value)}
                    />
                  </div>
                </div>

                <div className="border-t pt-4 space-y-3">
                  <label className="text-sm font-medium">Select/Add Item</label>
                  <Select onValueChange={handleSelectItem} value={currentItem.itemId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select item..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">
                        <span className="flex items-center gap-2">
                          <Package className="h-4 w-4" />
                          Add New Item
                        </span>
                      </SelectItem>
                      {inventory.map((item) => (
                        <SelectItem key={item.id} value={item.id}>
                          {item.name} (Stock: {item.qty})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {currentItem.isNew && (
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        placeholder="Item Name *"
                        value={currentItem.name}
                        onChange={(e) =>
                          setCurrentItem({ ...currentItem, name: e.target.value })
                        }
                      />
                      <Input
                        placeholder="HSN Code"
                        value={currentItem.hsn}
                        onChange={(e) =>
                          setCurrentItem({ ...currentItem, hsn: e.target.value })
                        }
                      />
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="number"
                      placeholder="Qty"
                      value={currentItem.qty}
                      onChange={(e) =>
                        setCurrentItem({ ...currentItem, qty: e.target.value })
                      }
                    />
                    <Input
                      type="number"
                      placeholder="Rate (₹)"
                      value={currentItem.price}
                      onChange={(e) =>
                        setCurrentItem({ ...currentItem, price: e.target.value })
                      }
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      type="number"
                      placeholder="Discount %"
                      value={currentItem.discount}
                      onChange={(e) =>
                        setCurrentItem({ ...currentItem, discount: e.target.value })
                      }
                    />
                    <Select
                      value={currentItem.gstRate}
                      onValueChange={(v) =>
                        setCurrentItem({ ...currentItem, gstRate: v })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="GST %" />
                      </SelectTrigger>
                      <SelectContent>
                        {[0, 5, 12, 18, 28].map((rate) => (
                          <SelectItem key={rate} value={String(rate)}>
                            {rate}% GST
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button onClick={addToBill} className="w-full" variant="secondary">
                    <Plus className="h-4 w-4 mr-2" />
                    Add to Purchase
                  </Button>
                </div>

                <div className="border-t pt-4 space-y-3">
                  <label className="text-sm font-medium">Payment Mode</label>
                  <Select
                    value={paymentMode}
                    onValueChange={(v) =>
                      setPaymentMode(v as "cash" | "bank" | "credit")
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="bank">Bank Transfer</SelectItem>
                      <SelectItem value="credit">Credit (On Account)</SelectItem>
                    </SelectContent>
                  </Select>

                  <Textarea
                    placeholder="Notes (optional)"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={2}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Right Panel - Purchase Preview */}
            <Card className="lg:col-span-3">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Purchase Items
                </CardTitle>
                {party && (
                  <div className="text-right text-sm">
                    <p className="font-medium">{party.name}</p>
                    {party.gstin && (
                      <p className="text-muted-foreground">GSTIN: {party.gstin}</p>
                    )}
                  </div>
                )}
              </CardHeader>
              <CardContent>
                {billItems.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    No items added. Select items from the left panel.
                  </p>
                ) : (
                  <>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Item</TableHead>
                          <TableHead>HSN</TableHead>
                          <TableHead className="text-right">Qty</TableHead>
                          <TableHead className="text-right">Rate</TableHead>
                          <TableHead className="text-right">GST</TableHead>
                          <TableHead className="text-right">Amount</TableHead>
                          <TableHead className="w-10"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {billItems.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell className="text-muted-foreground">
                              {item.hsn || "-"}
                            </TableCell>
                            <TableCell className="text-right">{item.qty}</TableCell>
                            <TableCell className="text-right">₹{item.price}</TableCell>
                            <TableCell className="text-right">{item.gstRate}%</TableCell>
                            <TableCell className="text-right font-medium">
                              ₹{item.amount.toLocaleString("en-IN", {
                                maximumFractionDigits: 2,
                              })}
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeItem(index)}
                                className="h-8 w-8 text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>

                    <div className="mt-4 pt-4 border-t border-border space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Subtotal</span>
                        <span>₹{subtotal.toLocaleString("en-IN")}</span>
                      </div>
                      {totalDiscount > 0 && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Discount</span>
                          <span className="text-red-500">
                            -₹{totalDiscount.toLocaleString("en-IN")}
                          </span>
                        </div>
                      )}
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">GST</span>
                        <span>
                          ₹{totalGst.toLocaleString("en-IN", {
                            maximumFractionDigits: 2,
                          })}
                        </span>
                      </div>
                      <div className="flex justify-between text-lg font-bold pt-2 border-t">
                        <span>Grand Total</span>
                        <span className="text-amber-600">
                          ₹{Math.round(grandTotal).toLocaleString("en-IN")}
                        </span>
                      </div>
                    </div>

                    <div className="mt-6">
                      <Button
                        onClick={savePurchase}
                        disabled={!selectedParty}
                        className="w-full bg-amber-500 hover:bg-amber-600 text-slate-900"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Save Purchase
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Purchase History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {invoices.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No purchases recorded yet.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Voucher No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Supplier</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead className="text-right">Paid</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invoices
                      .slice()
                      .reverse()
                      .map((invoice) => (
                        <TableRow key={invoice.id}>
                          <TableCell className="font-mono font-medium">
                            {invoice.invoiceNo}
                          </TableCell>
                          <TableCell>{invoice.date}</TableCell>
                          <TableCell>{invoice.partyName}</TableCell>
                          <TableCell className="text-right font-medium">
                            ₹{invoice.total.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-right">
                            ₹{invoice.paidAmount.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                invoice.status === "paid"
                                  ? "default"
                                  : invoice.status === "partial"
                                  ? "secondary"
                                  : "destructive"
                              }
                            >
                              {invoice.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setViewInvoice(invoice)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Invoice View Dialog */}
      <Dialog open={!!viewInvoice} onOpenChange={() => setViewInvoice(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Purchase {viewInvoice?.invoiceNo}</DialogTitle>
          </DialogHeader>
          {viewInvoice && (
            <div className="space-y-4">
              <div className="flex justify-between border-b pb-4">
                <div>
                  <p className="text-sm text-muted-foreground">Supplier:</p>
                  <p className="font-medium">{viewInvoice.partyName}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Date:</p>
                  <p className="font-medium">{viewInvoice.date}</p>
                </div>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Rate</TableHead>
                    <TableHead className="text-right">GST</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {viewInvoice.items.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>{item.name}</TableCell>
                      <TableCell className="text-right">{item.qty}</TableCell>
                      <TableCell className="text-right">₹{item.price}</TableCell>
                      <TableCell className="text-right">{item.gstRate}%</TableCell>
                      <TableCell className="text-right">
                        ₹{item.amount.toLocaleString("en-IN")}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              <div className="border-t pt-4 flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>₹{viewInvoice.total.toLocaleString("en-IN")}</span>
              </div>

              {viewInvoice.notes && (
                <div className="bg-muted/50 p-3 rounded">
                  <p className="text-sm text-muted-foreground">{viewInvoice.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
